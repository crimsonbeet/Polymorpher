#include <DOS.H>
long coreleft(void)
{
return farcorelft();
}
