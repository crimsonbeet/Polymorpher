  #define M_CONV_MODULE
  /**/
  #include<DOS.H>
  #include<MATH.H>
  #include<STDIO.H>
  /**/
  #ifdef __BORLANDC__
  #include<DIR.H>
  #include<ALLOC.H>
  #endif
  /**/
  #include<STDLIB.H>
  #include<CTYPE.H>
  /**/
  #include<STRING.H>
  #ifndef stricmp
  #define stricmp strcmp
  #endif
  /**/
  #ifdef __BORLANDC__
  #include<VALUES.H>
  #else
  #include<FLOAT.H>
  #endif
  /**/
  #include<LIMITS.H>
  #include<PROCESS.H>
  /**/
  #include"F0EVAL.C"
