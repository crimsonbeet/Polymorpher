  #include<DOS.H>
  #include<MATH.H>
  #include<IO.H>
  #include<STDIO.H>
  /**/
  #ifdef __BORLANDC__
  #include<DIR.H>
  #include<fcntl.h>
  #include<ALLOC.H>
  #endif
  /**/
  #include<STDLIB.H>
  #include<CTYPE.H>
  #include<STRING.H>
  /**/
  #ifdef __BORLANDC__
  #include<VALUES.H>
  #else
  #include<FLOAT.H>
  #endif
  /**/
  #include<LIMITS.H>
  #include<PROCESS.H>

long PASS = 1;
long SORT_STRIP;

long total_exposures;
long EMS_SIZE;
long EMS_MEM;

#ifndef __BORLANDC__
#define far
#define huge
#define farfree free
#define farmalloc malloc
#define maxbufsize 1024000L
long Coreleft(void) {return EMS_MEM;}
#else
#ifdef Huge_Pointer_not_allowed
#define maxbufsize 0XFFFFL
#else
#define maxbufsize 512000L
#endif
long Coreleft(void) {return coreleft();}
#endif

  static unsigned char tab_ebcdic[] =
  {
  0x00,0x01,0x02,0x03,0x37,0x2d,0x2e,0x2f,
  0x16,0x05,0x15,0x0b,0x0c,0x0d,0x0e,0x0f,

  0x10,0x11,0x12,0x00,0x3c,0x3d,0x32,0x26,
  0x18,0x19,0x3f,0x27,0x1c,0x1d,0x1e,0x1f,

  0x40,0x5a,0x7f,0x7b,0x5b,0x6c,0x50,0x7d,
  0x4d,0x5d,0x5c,0x4e,0x6b,0x60,0x4b,0x61,

  0xf0,0xf1,0xf2,0xf3,0xf4,0xf5,0xf6,0xf7,
  0xf8,0xf9,0x7a,0x5e,0x4c,0x7e,0x6e,0x6f,

  0x7c,0xc1,0xc2,0xc3,0xc4,0xc5,0xc6,0xc7,
  0xc8,0xc9,0xd1,0xd2,0xd3,0xd4,0xd5,0xd6,

  0xd7,0xd8,0xd9,0xe2,0xe3,0xe4,0xe5,0xe6,
  0xe7,0xe8,0xe9,0x00,0xe0,0x00,0x5f,0x6d,

  0x79,0x81,0x82,0x83,0x84,0x85,0x86,0x87,
  0x88,0x89,0x91,0x92,0x93,0x94,0x95,0x96,

  0x97,0x98,0x99,0xa2,0xa3,0xa4,0xa5,0xa6,
  0xa7,0xa8,0xa9,0xc0,0x6a,0xd0,0xa1,0x07
   };


unsigned char ASCII_to_EBCDIC (unsigned char c)
{
  return tab_ebcdic[c];
}

void Message(char * S)
{
fputs(S, stderr);
}

#define N 3
#define fmi f[a[mi]]
#define ftn f[t[N]]

#define swab_(n,m,w) ((w)=chnl[(n)], chnl[(n)]=chnl[(m)], chnl[(m)]=(w))

#define gt(l,r) (\
     (l).an > (r).an ? 0<1: \
     (l).an < (r).an ? 0>1: \
   PASS == 0 ? ( \
     (l).yl < (r).yl ? 0>1: \
     (l).yl > (r).yl ? 0<1: 0>1): \
   PASS == 1 ? ( \
     sub = (l).yl - (r).yl, \
     sub < -SORT_STRIP ? 0>1: \
     sub > +SORT_STRIP ? 0<1: \
     (l).xl < (r).xl ? 0>1: \
     (l).xl > (r).xl ? 0<1: 0>1): \
   ( \
     sub = (l).yl - (r).yl, \
     sub < -SORT_STRIP ? 0>1: \
     sub > +SORT_STRIP ? 0<1: \
     (l).xl > (r).xl ? 0>1: \
     (l).xl < (r).xl ? 0<1: 0>1) \
   )
/*
#define gt(l,r) (\
   PASS == 0 ? ( \
     (l).yl < (r).yl ? 0>1: \
     (l).yl > (r).yl ? 0<1: 0>1): \
   PASS == 1 ? ( \
     sub = (l).yl - (r).yl, \
     sub < -SORT_STRIP ? 0>1: \
     sub > +SORT_STRIP ? 0<1: \
     (l).xl < (r).xl ? 0>1: \
     (l).xl > (r).xl ? 0<1: 0>1): \
   ( \
     sub = (l).yl - (r).yl, \
     sub < -SORT_STRIP ? 0>1: \
     sub > +SORT_STRIP ? 0<1: \
     (l).xl > (r).xl ? 0>1: \
     (l).xl < (r).xl ? 0<1: 0>1) \
   )
*/
struct box
  {
long xl, yl;
long xm, ym;
short an;
  } huge * fhnl, huge * bhnl;
long huge * chnl;
/**/
long
    xl =0,
    yl =1,
    xm =2,
    ym =3,
    an =4;
/**/
struct sequence
  {
long ef, lb, lm, fa, fd, rn, cp;
long el;
char fn[50];
FILE *fi;
struct box huge * bf;
  };

FILE *fie = NULL;
FILE *fib = NULL;
FILE *fip = NULL;

struct sequence f[N+3], f0, f1;

long sub;
/*
typedef long compare
(struct box,
 struct box);

compare *gt;

unsigned char ASCII_to_EBCDIC (unsigned char);

compare gt0;
gt0
(struct box l,
 struct box r)
{
  return
  l.yl < r.yl ? 0>1:
  l.yl > r.yl ? 0<1: 0>1;
}
compare gt1;
gt1
(struct box l,
 struct box r)
{
   sub = l.yl - r.yl;
   return
   sub < -SORT_STRIP ? 0>1:
   sub > +SORT_STRIP ? 0<1:
   l.xl < r.xl ? 0>1:
   l.xl > r.xl ? 0<1: 0>1;
}
compare gt2;
gt2
(struct box l,
 struct box r)
{
   sub = l.yl - r.yl;
   return
   sub < -SORT_STRIP ? 0>1:
   sub > +SORT_STRIP ? 0<1:
   l.xl > r.xl ? 0>1:
   l.xl < r.xl ? 0<1: 0>1;
}
*/
void zabort (void)
{
  long i;
  if (f0.fi != NULL)fclose (f0.fi);
  unlink (f0.fn);
  for (i = 0; i <= N +2; ++i)
  {
  if (f[i].fi != NULL)fclose (f[i].fi);
  unlink (f[i].fn);
  }
  fclose (fip);
  fprintf(stderr, "\nEXITING DUE TO ERROR");
  exit(1);
}

void zfclose
(struct sequence *s)
{
  if (++s->cp > 0)
  {
  long i = s->bf != NULL,
      j = s->fi != NULL;
    if (i && j)
    s->lb = fwrite (s->bf, sizeof (struct box), s->cp, s->fi);
    else zabort ();
    if (s->lb < s->cp)
    {
	zabort ();
    }
  }
  s->cp = -1;
  if (s->fi != NULL)
  {
	fclose (s->fi);
	s->fi = NULL;
	s->ef = 1;
  }
}

void zsclose
(struct sequence *s)
{
  zfclose(s);
  if(s->bf != NULL)
  {
  farfree (s->bf);
  s->bf = NULL;
  s->lm = s->lb = 0;
  }
}

void zsread
(struct sequence *s)
{
  s->cp++;
  if (s->cp  >= s->lb)
  {
    s->lb =  fread (s->bf,
	    sizeof (struct box), s->lm, s->fi);
    if (s->lb <= 0) s->ef = 0<1;
    s->cp = 0;
  }
}

void zsmove
(struct sequence *d,
 struct sequence *s)
{
  if (++d->cp >= d->lm)
  {
    d->lb = fwrite (d->bf,
	    sizeof (struct box), d->cp, d->fi);
    if (d->lb < d->cp)
	zabort ();
    d->cp = 0;
  }
  d->bf[d->cp] = s->bf[s->cp++];
  /* --s->el; */
  /* ++d->el; */
  if (s->cp  >= s->lb)
  {
    s->lb =  fread (s->bf,
	    sizeof (struct box), s->lm, s->fi);
    if (s->lb <= 0) s->ef = 0<1;
    s->cp = 0;
  }
}

void startread
(struct sequence *s)
{
  zfclose (s);
  s->fi = fopen (s->fn, "r+b");
  if (s->fi == NULL)
  {
    Message ("UNABLE OPEN FOR READ A WORK FILE");
    zabort ();
  }
  s->lb = fread (s->bf,
	sizeof (struct box), s->lm, s->fi);
  s->ef = s->lb > 0 ? 0>1 :0<1;
  s->cp = 0;
}

void startwrite
( struct sequence *s)
{
  if (s->fi != NULL)
    fclose (s->fi);
  s->fi = fopen (s->fn, "w+b");
  if (s->fi == NULL)
  {
    Message ("UNABLE OPEN FOR WRITE A WORK FILE");
    zabort ();
  }
  s->ef = 0<1;
  s->rn = s->el = 0;
  s->cp = -1;
}

  void
  quicksort (long sl, long sr)
    { long k, j, w, x;
  if( sr-sl < 11 )
    {
  while( sl<sr )
    {
  for( j=sr, k=sr; sl<j; j-- )
  if( gt (fhnl[chnl[j-1]], fhnl[chnl[j]]) )
    {
  x = chnl[j] ;
  do
    {
  chnl[j] = chnl[j-1] ;
  j-- ;
    }
  while( sl <j && gt (fhnl[chnl[j-1]], fhnl[x]) ) ;
  chnl[j] = x ;
  k = j;
    }
  sl = k+1;
  for( j =sl; j <sr; j++ )
  if( gt (fhnl[chnl[j]], fhnl[chnl[j+1]]) )
    {
  x = chnl[j] ;
  do
    {
  chnl[j] = chnl[j+1] ;
  j++ ;
    }
  while( j <sr && gt (fhnl[x], fhnl[chnl[j+1]]) );
  chnl[j] = x;
  k = j;
    }
  sr = k-1;
    }
    }
  else
    {
  x = (sl + sr)/2 ;
  if( gt (fhnl[chnl[sl]], fhnl[chnl[x]]) ) swab_ (sl, x, w) ;
  if( gt (fhnl[chnl[x]], fhnl[chnl[sr]]) ) swab_ (sr, x, w) ;
  if( gt (fhnl[chnl[sl]], fhnl[chnl[x]]) ) swab_ (sl, x, w) ;
  x = chnl [x];
  for( k =sl+1, j =sr-1; k < j ; )
    {
  while( gt (fhnl[x], fhnl[chnl[k]]) )
    k += 1;
  while( gt (fhnl[chnl[j]], fhnl[x]) )
    j -= 1;
  if (k < j)
    {
  swab_( k, j, w ) ;
  k += 1;
  j -= 1;
    }
    }
  if( sl<j ) quicksort( sl, j ) ;
  if( k<sr ) quicksort( k, sr ) ;
    }
    }

  void
  quicksorting ( long sl, long sr )
    { long i =-1;
  while (++i <= sr) chnl[i] = i;
  quicksort (sl, sr);
    }

void copyrun
(struct sequence *f)
{
long
    k =0, j =0;
  while (j < f0.lb)
  {
  k = 0;
  while (k < f->lm && j < f0.lb)
  {
    f->bf[k] = f0.bf[chnl[j]];
    k++, j++;
  }
  f->lb = fwrite (f->bf, sizeof (struct box),
			k, f->fi);
  /* f->el += k; */
  if (f->lb < k)
    zabort ();
  }
  f0.el += j;
  f0.lb = fread (f0.bf, sizeof (struct box),
			f0.lm, f0.fi);
  if (f0.lb > 0)
    quicksorting (0, f0.lb -1);
  f0.ef = f0.lb > 0 ? 0 :1;
}

long polysort ()
    {
long level =1, i, j;

fprintf(stderr, "\nPoly/sort on %ld files started\r", (long)N);
  for (i = 0; i <= N; ++i)
  {
  f[i].fa = 1;
  f[i].fd = 1;
  }
  f[N].fa = 0;
  f[N].fd = 0;
/* MAKE A WORK BUFFERS; LABEL SIMS */
  { /* +SIMS */
long memx =0, memb = maxbufsize /sizeof (struct box);
	      /* SET UP BUFFERS */
  memx = 512L;
  memx /= sizeof (struct box);
  memx = memb < memx ? memb : memx -1;
  for (i = 0; i <N; ++i)
  {
    f[i].bf = farmalloc (memx *sizeof (struct box));
    if (f[i].bf == NULL)
    {
      Message ("FAILED TO SET UP WORK BUFFER");
      zabort ();
    }
    f[i].lm = memx;
  }
  memx = Coreleft()-7000;
  memx /= sizeof (struct box) +sizeof (long);
  memx = memb < memx ? memb : memx -1;
  fhnl = farmalloc (memx *sizeof (struct box));
  chnl = farmalloc (memx *sizeof (long));
  f0.bf = fhnl;
  f0.lm = memx;
  f0.cp = -1;
  f0.rn = f0.el = 0;
/* A START READ */
  startread (&f0);
  if (!f0.ef)
    quicksorting (0, f0.lb -1);
  for (i = 0; i <N; ++i) startwrite (&f[i]);
  } /* -SIMS */
/* READ AN INPUT AND DISTRIBUTE IT ON SEQUENCES; LABEL NY */
/* +NY */
/* A START INIT SEQUENCES */
  for (i = 0; i < N && !f0.ef; ++i)
    {
  copyrun (&f[i]);
  while (!f0.ef && gt (f0.bf[chnl[0]], f[i].bf[f[i].lb -1]))
    copyrun (&f[i]);
  f0.rn += 1;
  f[i].fd -= 1;
  f[i].rn += 1;
    }
  if (!f0.ef)
    {  /* +A */
  level += 1;
  for (i = 0; i < N; ++i)
    {
  f[i].fd = 1;
  f[i].fa = 2;
    }
  f[N-1].fd -= 1;
  f[N-1].fa -= 1;
    }  /* -A */
/* FILL UP SEQUENCES */
  for (j = 0; !f0.ef;) /* A DISTRIBUTER; LABEL MLNY */
  { /* +MLNY */
  /* COMPUTE FIB */
  if (f[j].fd < f[j+1].fd) ++j;
  else
  {
  if (f[j].fd == 0)
  {
  long z = f[0].fa;
    level += 1;
    for (i = 0; i < N; ++i)
    {
    f[i].fd = z + f[i+1].fa - f[i].fa;
    f[i].fa = z + f[i+1].fa;
    }
  }
  j = 0;
  }
  /* PUT A RUN */
  if (!gt (f[j].bf[f[j].lb -1], f0.bf[chnl[0]]))
  {
    copyrun (&f[j]);
    while (!f0.ef && gt (f0.bf[chnl[0]], f[j].bf[f[j].lb -1]))
    copyrun (&f[j]);
  }
  if (!f0.ef)
  {
    copyrun (&f[j]);
    while (!f0.ef && gt (f0.bf[chnl[0]], f[j].bf[f[j].lb -1]))
    copyrun (&f[j]);
    f[j].fd -= 1;
    f[j].rn += 1;
    f0.rn += 1;
  }
  } /* -MLNY */
  farfree (chnl);
  farfree (fhnl);
  f0.bf = NULL;
  f0.lm = f0.lb = 0, f0.cp = -1;
  fclose (f0.fi), f0.fi = NULL;
  for (i = 0; i <N; ++i)
  {
    farfree (f[i].bf);
    f[i].bf = NULL;
    f[i].lm = f[i].lb = 0, f[i].cp = -1;
  }
/* -NY */
/* MERGE RUNS FROM SEQUENCES; LABEL SDNLM */
    { /* +SDLNM */
long t[N+1], a[N+1];
    { /* MAKE BUFFERS */
long memx, memb;
  memx = Coreleft()-7000;
  memx /= N + 1;
  memx /= sizeof (struct box) + 1;
  memb = maxbufsize /sizeof (struct box);
  memx = memb < memx ? memb : memx -1;
  for (i = 0; i <= N; ++i)
    {
  t[i] = i;
  f[i].bf = farmalloc (memx *sizeof (struct box));
  if (f[i].bf == NULL)
  {
    Message ("FAILED TO SET UP WORK BUFFER");
    zabort ();
  }
  f[i].lm = memx;
  f[i].cp = -1;
    }
  for (i = 0; i <N; ++i) startread (&f[i]);
    } /* END */
/* KERNEL */
  if (f0.rn > 1)
  while (level != 0)
    { /* +A */
long k = -1; long z = f[t[N-1]].fa;
  f[t[N]].fd = 0;
  startwrite (&f[t[N]]);
  while (z != 0)
    { /* +B */
  for (i = 0; i < N; ++i)
    if (f[t[i]].fd > 0) --f[t[i]].fd;
    else a[++k] = t[i];
  if (k == -1)
    ++f[t[N]].fd;
  else
    { /* +C */
long mi = 0;
  while (k != -1)
    { /* +D */
  for (i = 1, mi = 0; i <= k; ++i)
  if (gt (f[a[mi]].bf[f[a[mi]].cp], f[a[i]].bf[f[a[i]].cp]))
      mi = i;
  zsmove (&ftn, &fmi);
  if (fmi.ef || gt (ftn.bf[ftn.cp], fmi.bf[fmi.cp]))
    { /* +E */
  f[a[mi]].rn -= 1;
  a[mi] = a[k];
  k -= 1;
    } /* -E */
    } /* -D */
  f[t[N]].rn += 1;
    } /* -C */
  z -= 1;
    } /* -B */
  startread (&f[t[N]]);
    { /* +B */
long tn = t[N], dn = f[t[N]].fd;
  for (i = N, z = f[t[N-1]].fa; i > 0; --i)
    { /* +C */
  t[i] = t[i-1];
  f[t[i]].fa -= z;
    } /* -C */
  t[0] = tn;
  f[tn].fd = dn;
  f[tn].fa = z;
    } /* -B */
  level -= 1;
    } /* -A */
  for (i = 0; i <= N; i++)
  {
    f[i].cp = -1;
    zsclose (&f[i]);
  }
  f[t[0]].ef = 0;
  return t[0];
    } /* -SDNLM */
    }

void clabort()
{
  zabort();
}

long scanfname
( char *s0
, char *s1
, char *s2 ) {
  while (*s0 != '.' && *s0 != 0) *s1++ = *s0++; *s1 = '\0';
  if (*s0 == '\0') return (0>1);
  else {
    while (*s0 != '\0') *s2++ = *s0++; *s2 = '\0'; }
  return (0<1); }


void zpmove
(FILE *fip,
 struct box *s)
{
long h = 0, i;
static long
      ANGL = LONG_MAX,
      CORX = LONG_MAX,
      CORY = LONG_MAX,
      DSTX = LONG_MAX,
      DSTY = LONG_MAX;
char str[80], str1[20];

  str[0] = 0;
  if (CORX != s->xl)
    sprintf (str1, "X%ld", CORX = s->xl), h = 1, strcat(str, str1);
  if (CORY != s->yl)
    sprintf (str1, "Y%ld", CORY = s->yl), h = 1, strcat(str, str1);
  if (DSTX != s->xm)
    sprintf (str1, "W%ld", DSTX = s->xm), h = 1, strcat(str, str1);
  if (DSTY != s->ym)
    sprintf (str1, "H%ld", DSTY = s->ym), h = 1, strcat(str, str1);
  if (ANGL != s->an)
    sprintf (str1, "A%ld", ANGL = s->an), h = 1, strcat(str, str1);
  if (h) strcat(str,";"), total_exposures++;

  for(i = 0; str[i]; i++)
  fputc((str[i] = ASCII_to_EBCDIC(str[i])), fip);
}

#define ZSPAWNMODE 1

#ifdef __ZTC__
void
zz_dos_date(char * d, char * t)
{
  struct dos_date_t zdate;
  struct dos_time_t ztime;
  dos_getdate (&zdate);
  sprintf (d, "%ld-%02ld-%02ld", (long)zdate.year,
				 (long)zdate.month,
				 (long)zdate.day);
  dos_gettime (&ztime);
  sprintf (t, "%ld:%02ld", (long)ztime.hour,
			   (long)ztime.minute);
}
#else
void
zz_dos_date(char * d, char * t)
{
  struct date zdate;
  struct time ztime;
  getdate (&zdate);
  sprintf (d, "%ld-%02ld-%02ld", (long)zdate.da_year,
				 (long)zdate.da_mon,
				 (long)zdate.da_day);
  gettime (&ztime);
  sprintf (t, "%ld:%02ld", (long)ztime.ti_hour,
			   (long)ztime.ti_min);
}
#endif
void main
(short nline, char *line[])
{
long
    y = LONG_MIN,
    memx = 0,
    memb = 0;
char
    strDATE[20],
    strTIME[20],
    pat[99],
    str[99],
    inp[99];
long
    h = 0,
    z = 0,
    i = 0;
  if (nline < 5) clabort ();

  strncpy (pat, line[1], 20);

  tmpnam(f0.fn);

  if(rename (pat, f0.fn)==0)
  {
  fprintf(stderr, "\nMESSAGE! %s RENAMED TO %s\n", pat, f0.fn);
  }
  else zabort();
  strncpy (inp, line[2], 20);

  sscanf (line[3], "%ld", &SORT_STRIP);
  sscanf (line[4], "%ld", &EMS_SIZE);

  EMS_MEM = EMS_SIZE*1024 + 250000;

  fie = stderr;

  zz_dos_date(strDATE, strTIME);

  fprintf (fie, "INPUT FILE %s, OUTPUT FILE %s\r\n", f0.fn, pat);
  f0.fi = NULL;
  f0.bf = NULL;
  for (i = 0; i <= N +2; ++i)
  {
    sprintf (f[i].fn, "%ld.000", i);
    f[i].bf = NULL;
    f[i].fi = NULL;
  }
  if (SORT_STRIP < 0) SORT_STRIP = 0;
  PASS = 0;/* gt = gt0; */
  h = polysort ();
fprintf(stderr, "PASS-1 COMPLETED\n");
  total_exposures = f0.el;
  f1 = f0;
  memx = Coreleft()-3000;
  memx /= 3;
  memx /= sizeof (struct box);
  memb = maxbufsize /sizeof (struct box);
  memx = memb < memx ? memb : memx -1;
  for (i = N +1; i <= N +2; ++i)
  {
    f[i].bf = farmalloc (memx *sizeof (struct box));
    if (f[i].bf == NULL)
    {
      Message ("FAILED TO SET UP WORK BUFFER");
      zabort ();
    }
    f[i].lm = memx;
    startwrite (&f[i]);
  }
  f[h].bf = farmalloc (memx *sizeof (struct box));
  f[h].lm = memx;
  f[h].cp = -1;
  i = N +2, y = LONG_MIN;
  startread (&f[h]);
  while (!f[h].ef)
  {
    if (y < f[h].bf[f[h].cp].yl)
    {
      y = f[h].bf[f[h].cp].yl +SORT_STRIP;
      i = i == N +1 ? N +2 : N +1;
    }
    zsmove (&f[i], &f[h]);
  }
  f[h].cp = -1;
  zsclose(&f[h]);
  for (i = N +1; i <= N +2; i++) zsclose (&f[i]);
  PASS = 1;/* gt = gt1; */
  f0 = f[N +1];
  h = polysort ();
fprintf(stderr, "PASS-2 COMPLETED\n");
  f[N +1] = f[h];
  f[h] = f0;
  PASS = 2;/* gt = gt2; */
  f0 = f[N +2];
  h = polysort ();
fprintf(stderr, "PASS-3 COMPLETED\n");
  f[N +2] = f[h];
  f[h] = f0;
  f0 = f1;
  memx = Coreleft()-3000;
  memx /= 3;
  memx /= sizeof (struct box) + 1;
  memb = maxbufsize /sizeof (struct box);
  memx = memb < memx ? memb : memx -1;
  for (i = N +1; i <= N +2; ++i)
  {
    f[i].bf = farmalloc (memx *sizeof (struct box));
    if (f[i].bf == NULL)
    {
      Message ("FAILED TO SET UP WORK BUFFER");
      zabort ();
    }
    f[i].lm = memx;
    f[i].cp = -1;
    startread (&f[i]);
  }
  fip = fopen (pat, "wb");
  if (fip == NULL)
  {
    Message ("UNABLE OPEN FOR WRITE A WORK FILE");
    zabort ();
  }
  zz_dos_date(strDATE, strTIME);

  sprintf (str, "%cMAN3000 MASCOT %s FLASHES %ld", '"', strDATE, (long)total_exposures);
  for (i = 0; str[i]; i++) fputc (ASCII_to_EBCDIC(str[i]), fip);
  fputc ('\x15', fip);

  i = N +2, y = LONG_MIN;
  total_exposures = 0;
  while (!(f[N +1].ef && f[N +2].ef))
  {
    if (y < f[i].bf[f[i].cp].yl)
    {
      if (!(f[N +1].ef || f[N +2].ef))
	i = i == N +1 ? N +2 : N +1;
      y = f[i].bf[f[i].cp].yl +SORT_STRIP;
    }
    zpmove (fip, (struct box far *)f[i].bf+f[i].cp);
    zsread (&f[i]);
    if (f[i].ef)
      i = i == N +1 ? N +2 : N +1;
  }
  f0.cp = -1;
  zsclose(&f0);
  unlink(f0.fn);
fprintf(stderr, "PASS-4 COMPLETED\n");
  f[N +1].cp =-1;
  f[N +2].cp =-1;
  for (i = N +1; i <= N +2; ++i) zsclose(&f[i]);
  for (i = 0; i <= N +2; ++i) unlink (f[i].fn);

  sprintf (str, "%cFLASHES %ld",
	   '"', (long)total_exposures);
  for (i=0; str[i]; i++) fputc (ASCII_to_EBCDIC(str[i]), fip);
  fputc ('\x15', fip);

  sprintf (str, "$");
  for (i=0; str[i]; i++) fputc ( ASCII_to_EBCDIC(str[i]), fip);

  if(fclose (fip)!=0)
  {
  fprintf(stderr, "\nFAILED TO CLOSE %s\n", pat);
  zabort();
  }
  zz_dos_date(strDATE, strTIME);

  fprintf (fie, "SORTING PARAMETERS:\r\n");
  fprintf (fie, "SORT_STRIP = %ld\r\n", SORT_STRIP);
  fprintf (fie, "TOTAL FLASHES = %ld\r\n", total_exposures);
  fprintf (fie, "M05009 finished at %s\r\n\r\n", strTIME);
  exit(0);
}
