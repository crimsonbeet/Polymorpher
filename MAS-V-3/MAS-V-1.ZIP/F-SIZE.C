  #define F_SIZE_MODULE
  /**/
  #include<DOS.H>
  #include<MATH.H>
  #include<STDIO.H>
  /**/
  #ifdef __BORLANDC__
  #include<DIR.H>
  #include<ALLOC.H>
  #endif
  /**/
  #include<STDLIB.H>
  #include<CTYPE.H>
  #include<STRING.H>
  /**/
  #ifdef __BORLANDC__
  #include<VALUES.H>
  #endif
  /**/
  #include<LIMITS.H>
  #include<PROCESS.H>
  /**/
  #include "F0EVAL.H"
  /**/
  extern char Dix_Rewrite_FP_S;
  extern long DIX_OpenS;
  /**/
  extern void
  Dxb_Ld_Image_Maker
  (char closure, char*s);
  extern void
  Shapes_Generation_Main(void);
  extern void
  Db_Collars_Generater(void);
  extern char
  FindxFile(char*Name);
  extern void
  Init_ILayer_File(FX_Struct*L);
  extern void
  Zd_Struct_Init(long F);
  /**/
  extern long*LDPTR1;
  extern long*LDPTR2;
  extern long*LDPTR3;

  extern long*PLDCO0;
  extern long*PLDCO1;

  extern SHORT*PDJCO0;

  extern long**LLLCOR[4];
  extern long**PLDCOR[3];

  extern SHORT**ILBCOR_L[9];
  extern SHORT**ILVCOR_L[8];

  extern long PLDLIM;
  extern long PLDMAX;
  extern long LLDMAX;

  extern long LLDLIM[3];

  extern long PDJCNT;
  extern long PDJMAX;
  /**/
  double Size_Width;
  /**/
  long Total_Collar;
  long Total_Shapes;
  /**/
  char Bdb_Exists;

  long Core_Size;
  long Min_Core_Size;
  /**/
  void Print_Out_Of_Mem(void)
  {
  fprintf(stderr, "\nERROR: OUT OF MEMORY.\n");
  }
  void Print_Out_Of_Storage(void)
  {
  fprintf(stderr, "\nERROR: OUT OF STORAGE.\n");
  }
  #define Bdb_File_X (O_Layer.File.Fil)
  void zabort(void)
  {
  if(Bdb_File_X!=NULL)
  {
  fclose(Bdb_File_X);
  unlink(O_Layer.PdbN);
  }
  exit(1);
  }
  void ZoutAbort(void)
  {
  Print_Out_Of_Storage();
  zabort();
  }
  long
  PLDNEXT(void)
  {
  if(++PLDLIM>PLDMAX) ZoutAbort();
  return(PLDLIM-1);
  }
  long
  LldNext(long L)
  {
  if(LLDLIM[L]>=LLDMAX+1) ZoutAbort();
  return(LLDLIM[L]++);
  }
  void
  PLDALLOC(long N)
  {
#ifdef __BORLANDC__
  if(N>16000)N = 16000;
#else
  if(N>64000)N = 64000;
#endif
  PLDMAX = N;
  ZXXALLOC((void***)PLDCOR, N*4);
  }
  void
  LLDALLOC(long N)
  {
#ifdef __BORLANDC__
  if(N>16000)N = 16000;
#else
  if(N>64000)N = 64000;
#endif
  LLDMAX = N;
  ZXXALLOC((void***)LLLCOR, N*4);
  }
  void
  ZLBALLOC_L(long L)
  {
#ifdef __BORLANDC__
  if(L>32000)L = 32000;
#else
  if(L>64000)L = 64000;
#endif
  ZLBLIM = 1;
  ZLBMAX = L;

  ZXXALLOC((void***)ILBCOR_L, L*2);
  }
  void
  ZLVALLOC_L(long L)
  {
#ifdef __BORLANDC__
  if(L>32000)L = 32000;
#else
  if(L>64000)L = 64000;
#endif
  ZLVLIM = 1;
  ZLVMAX = L;

  ZXXALLOC((void***)ILVCOR_L, L*2);
  }
  typedef void mergelvchain(long, long);
  extern mergelvchain*MERGELVCHAIN;
  extern void MERGELVCHAIN_M(long, long);
  void MERGELVCHAIN_L
  (long VT, long PV)
  {
  long LS;
    LS = ZVTCO5[VT];
    if(LS)
    ZVTCO5[PV] = LS;
  }
  typedef long compsplitlv(long, long, long, long);
  extern compsplitlv*COMPSPLITLV;
  extern long COMPSPLITLV_M(long, long, long, long);
  long COMPSPLITLV_L(long L3, long V3, long V4, long IP)
  {
    long L4;
    L4 = ZLVNEXT();

    ZLVCO1[L4] = ZLVCO1[L3];
    ZLVCO1[L3] = L4;

    ZLVCO2[L4] = V4;

    if(ZLVCO2[L3]!=V3)zabort();
    if(ZVTCO1[V4]!=IP)zabort();
    return(L4);
  }
  #define P_LD_Wt_L 0.5
  #define Z_LD_Wt_L 1.0
  #define Z_LB_Wt_L 0.5
  #define Z_LV_Wt_L 2.0
  #define Z_VT_Wt_L 4.0
  #define Z_PT_Wt_L 1.0
  #define Z_LL_Wt_L 2.0

  #define P_LD_Sz_L 8*P_LD_Wt_L
  #define Z_LD_Sz_L 8*Z_LD_Wt_L
  #define Z_LB_Sz_L 2*Z_LB_Wt_L
  #define Z_LV_Sz_L 4*Z_LV_Wt_L
  #define Z_LL_Sz_L 6*Z_LL_Wt_L + 6L*Z_LL_Wt_L
  #define Z_VT_Sz_L 2*Z_VT_Wt_L + 10*Z_VT_Wt_L
  #define Z_PT_Sz_L 8*Z_PT_Wt_L + 4L*Z_PT_Wt_L
  void
  Initial_Setup_3(void)
  {
    long I;

    PXCNT = 32;
    PYCNT = 32;
    PBLIM = PXCNT*PYCNT;
    ZPBCOR = malloc(PBLIM*2);

    PDJMAX = 256;
    PDJCO0 = malloc(PDJMAX*2);

    Z_Layers_Cnt = 4;
    Find_ILayer();

    for(I = 0; I<4; ++I)
    INIT_ILayer(&Z_Layer[I], I);

    Zd_Delta_X = Z_Layer[0].Delta_X-CXMIN;
    Zd_Delta_Y = Z_Layer[0].Delta_Y-CYMIN;

    if(!(Z_Layer[0].LX_S.STATUS&1))
    fprintf(stderr, "\nNOTE! OVERLAP ELIMINATION MUST BE PERFORMED\n"),
    zabort();

    O_Layer.LX_S.PDBI = Z_Layer[0].LX_S.PDBI;
    Make_BDB_File_Name(O_Layer.BdbN, O_Layer.LX_S.PDBI);

    if(FindxFile(O_Layer.BdbN))Bdb_Exists = 1;
    else
    INIT_OLayer(&O_Layer);

#ifdef __BORLANDC__
    Core_Size = coreleft() -20000;
#else
    Core_Size = LZ_S.EMSIZ*1024 + 250000L;
#endif

    Min_Core_Size =
    Core_Size/(P_LD_Sz_L+Z_LD_Sz_L+Z_LB_Sz_L+Z_LV_Sz_L+Z_VT_Sz_L+Z_PT_Sz_L+Z_LL_Sz_L);

    ZLBALLOC_L((long)(Min_Core_Size*Z_LB_Wt_L));
    ZLVALLOC_L((long)(Min_Core_Size*Z_LV_Wt_L));

    PLDALLOC((long)(Min_Core_Size*P_LD_Wt_L));
    ZLDALLOC((long)(Min_Core_Size*Z_LD_Wt_L));
    ZVTALLOC((long)(Min_Core_Size*Z_VT_Wt_L));
    ZPTALLOC((long)(Min_Core_Size*Z_PT_Wt_L));
    LLDALLOC((long)(Min_Core_Size*Z_LL_Wt_L));

    IPOINT = IPOINT3;
    COMPSPLITLV = COMPSPLITLV_L;
    MERGELVCHAIN = MERGELVCHAIN_L;
    return;
  }
  void
  Initial_Setup_4(void)
  {
    long I;

    free(ZPBCOR);
    free(PDJCO0);

    for(I = 0; I<4; ++I)
    fclose(Z_Layer[I].File.Fil),
    free(Z_Layer[I].File.Buf);

    ZXXFREE((void***)PLDCOR);
    ZXXFREE((void***)LLLCOR);

    ZXXFREE((void***)ILBCOR_L);
    ZXXFREE((void***)ILVCOR_L);

    ZXXFREE((void***)LLDCOR);
    ZXXFREE((void***)IVTCOR);
    ZXXFREE((void***)CVTCOR);
    ZXXFREE((void***)LPTCOR);
    ZXXFREE((void***)IPTCOR);

    Core_Size = coreleft();
  }
  void
  Initial_Setup_5(void)
  {
    DIX_OpenS = Z_Open_Shape = 0;

    PXCNT = 32;
    PYCNT = 32;
    PBLIM = PXCNT*PYCNT;
    ZPBCOR = malloc(PBLIM*2);

    /*Setup Intersection_Analysis Core.*/

    LF_LIM = 64;

    Lf_Sdown = malloc(LF_LIM*1);
    Lf_Rolld = malloc(LF_LIM*2);
    Lf_ROLLD = malloc(LF_LIM*2);
    Lf_First = malloc(LF_LIM*2);
    Lf_Upper = malloc(LF_LIM*2);
    Lf_Lower = malloc(LF_LIM*2);
    Lf_Ymidl = malloc(LF_LIM*4);
    Lf_Stack = malloc(LF_LIM*2);

    Lf_Factor = 1;
    while(LF_LIM>>Lf_Factor)
    Lf_Factor++;
    Lf_Factor--;

    IPOINT = IPOINT3;
    COMPSPLITLV = COMPSPLITLV_M;
    MERGELVCHAIN = MERGELVCHAIN_M;

    /*Z_Layer INITIALIZED already By Setup_3*/
    /*But File-Struct Have Been Destructed.*/

    Make_BDB_File_Name(Z_Layer[0].PdbN, Z_Layer[0].LX_S.PDBI);
    Init_ILayer_File(&Z_Layer[0]);

    /*ReDirect Zd-Input to Z_Layer[0].*/

    Delta_X = 0;
    Delta_Y = 0;
    Zd_Struct_Init(0); ZZ_RP_KB = 0;

    INIT_OLayer(&O_Layer);

#ifdef __BORLANDC__
    Core_Size = coreleft() -25000L;
#else
    Core_Size = LZ_S.EMSIZ*1024 +250000L;
#endif

    Min_Core_Size =
    Core_Size/(P_LD_Sz_L + 2*(Z_LD_Sz) + Z_LB_Sz + Z_LV_Sz + Z_VT_Sz + Z_PT_Sz + Z_VX_Sz + Z_JS_Sz);

    PLDALLOC((long)(Min_Core_Size*P_LD_Wt_L));

    ZLDALLOC((long)(Min_Core_Size*Z_LD_Wt));
    ZldALLOC((long)(Min_Core_Size*Z_LD_Wt));
    ZLBALLOC((long)(Min_Core_Size*Z_LB_Wt));
    ZLVALLOC((long)(Min_Core_Size*Z_LV_Wt));
    ZVTALLOC((long)(Min_Core_Size*Z_VT_Wt));
    ZPTALLOC((long)(Min_Core_Size*Z_PT_Wt));
    ZJSALLOC((long)(Min_Core_Size*Z_JS_Wt));

    Dix_Rewrite_FP_S = 1;
    Total_Shapes = 0;

    ZZ_DELTA_X = -CXMIN;
    ZZ_DELTA_Y = -CYMIN;

    CXMIN = CYMIN = LONG_MAX;
    CXMAX = CYMAX = LONG_MIN;
  }
  void
  main(int Narguments, char*Arguments[])
  {
    long I;
    for(I = 0; I<4; ++I)
    strncpy(Z_Layer[I].Name, Arguments[1], 19);

    strncpy(O_Layer.Name, Arguments[1], 19);
    strncat(O_Layer.Name, "$CLR", 5);

    Initial_Setup_1();
    Initial_Setup_2();
    Initial_Setup_3();

    if(Bdb_Exists)
    fprintf(stderr, "\nBoundary resolution data is OK!\n");
    else
    Shapes_Generation_Main();

    Initial_Setup_4();
    Initial_Setup_5();

Size_Width = 1.0;

    if(Size_Width>0.0)
    Db_Collars_Generater();
    else
    fprintf(stderr, "\nOK!");

    Dxb_Ld_Image_Maker(ZLDLIM = 0, NULL);
    Lz_Lx_Close();
  }
