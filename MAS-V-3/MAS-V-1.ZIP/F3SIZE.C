  #define F_SIZE_MODULE
  /**/
  #include<DOS.H>
  #include<MATH.H>
  #include<STDIO.H>
  /**/
  #ifdef __BORLANDC__
  #include<DIR.H>
  #include<ALLOC.H>
  #endif
  /**/
  #include<STDLIB.H>
  #include<CTYPE.H>
  #include<STRING.H>
  /**/
  #ifdef __BORLANDC__
  #include<VALUES.H>
  #endif
  /**/
  #include<LIMITS.H>
  #include<PROCESS.H>
  /**/
  extern long Total_Shapes;
  long
  PLDNEXT(void);
  long
  LldNext(long L);
  void
  ZoutAbort(void);
  /**/
  #include "F0EVAL.H"
/*CORES FOR LEAD-IN AND TAIL VECTORS*/
  /**/
  long*LDPTR1;
  long*LDPTR2;
  long*LDPTR3;

  long*PLDCO0;
  long*PLDCO1;

  SHORT*PDJCO0;

  long**LLLCOR[4] = {&LDPTR1, &LDPTR2, &LDPTR3, NULL};
  long**PLDCOR[3] = {&PLDCO0, &PLDCO1, NULL};
  SHORT**ILBCOR_L[9] = {&ZLBCO3, NULL};
  SHORT**ILVCOR_L[8] = {&ZLVCO1, &ZLVCO2, NULL};
/*FOR EACH ROW */
  long*LLDPTR[3];
  long LLDLIM[3];
  long LLDASS[3];
  long CnFROM[3];
  long CentTO[3];
  long RgFROM[3];
  long RighTO[3];
  long LfFROM[3];
  long LeftTO[3];
/*FOR EACH COLUMN*/
  #define Pdb_File_X (Z_Layer[3].File.Fil)
  #define Pdb_File_1 (Z_Layer[0].File.Fil)
  #define Pdb_File_2 (Z_Layer[1].File.Fil)
  #define Pdb_File_3 (Z_Layer[2].File.Fil)
  #define Bdb_File_X (O_Layer.File.Fil)

  char Pdb_Load_Too;

  #define Pdb_Block_X (Z_Layer[3].Fragment)
  #define Bdb_Block_1 (Z_Layer[0].Fragment)
  #define Bdb_Block_2 (Z_Layer[1].Fragment)
  #define Bdb_Block_3 (Z_Layer[2].Fragment)
  #define Block_For_Get (Zd_Fragment)
/*COMMON GLOBALS*/
  long Pdb_Xg;
  long Pdb_Yg;
  long Bdb_Xg;
  long Bdb_Yg;
  char Bdb_Regen;
  char Left_Enabled; /*FOR Xg == 0 LEFT COLUMN DISABLED*/
  char Right_Enabled; /*FOR Xg == XgCnt-1 RIGHT COLUMN DISABLED*/
  #define Left_Disabled (!Left_Enabled)
  #define Right_Disabled (!Right_Enabled)
  /**/
  long Delta_X_2;
  long Delta_Y_1;
  long Delta_Y_2;
  /**/
  long*BS1_coord;
  long*BS2_coord;
  /**/
  long PLDLIM;
  long PLDMAX;
  long LLDMAX;

  long PDJCNT;
  long PDJMAX;
  /**/
  #define XgCnt XBCNT
  #define YgCnt YBCNT
  #define XgDiv XBSIZ
  #define YgDiv YBSIZ
  #define CxMin CXMIN
  #define CyMin CYMIN
  #define CxMax CXMAX
  #define CyMax CYMAX
  /**/
  long Lb_CnFrom[3];
  long Lb_LfFrom[3];
  long Lb_RgFrom[3];
  long Lb_CentTo[3];
  long Lb_LeftTo[3];
  long Lb_RighTo[3];

  long Lb_PbasTO;
  /**/
  void
  Print_Normal_Finish(void)
  {
  fprintf(stderr, "\n\nFinished Normally\n");
  }
  void
  Print_Program_Err(void)
  {
  fprintf(stderr, "\n PROGRAMMING ERROR. APPLY TO A.N.B WITH THIS EXAMPLE.");
  }
  void
  Print_Pos_Err(void)
  {
  fprintf(stderr, "\n0 PDB-FILE POSITION ERROR.");
  }
  void
  Mirror_File_Buffer(long S, long D)
  {
    long I;

    fgetpos(Z_Layer[S].File.Fil, &I);
    fsetpos(Z_Layer[D].File.Fil, &I);

    I = Z_Layer[S].File.Buf_Len;
    memcpy(Z_Layer[D].File.Buf, Z_Layer[S].File.Buf, I);

    Z_Layer[D].File.Buf_Len=
    Z_Layer[S].File.Buf_Len;
    Z_Layer[D].File.Buf_Pos=
    Z_Layer[S].File.Buf_Pos;
    Z_Layer[D].File.Buf_Eof=
    Z_Layer[S].File.Buf_Eof;

    Z_Layer[D].Fragment=
    Z_Layer[S].Fragment;
  }
  void ZDREAD(char*, char);
  void ZDREAD_P(void);
  char ZDSKIP_P(void)
  {
  char Z[4];

  ZDREAD(Z, 1);
  if(!Z[0])
  {
  return(0);
  }
  #define Z_LEN(Z) ((Z)&7)
  ZDREAD(Z, Z_LEN(Z[0]));
  #undef Z_LEN

  return(1);
  }
  void Skip_Polygon(void)
  {
  #define BL Block_For_Get

  if(!ZDSKIP_P())
	{
	long L;
	char Z;
	ZDREAD(&Z, 1), L = (Z&(7<<4))>>4;
	if(L)
		{
		fprintf(stderr, "\nABNORMAL INPUT FILE FORMAT");
		zabort();
		}
	BL[0] = 0;
	ZDREAD((char*)BL, Z);

	if(Zd_File_Eof)
	BL[0] = LONG_MAX;
	return;
	}
  else
  if(!ZDSKIP_P())
	zabort();
  while(1);
  #undef BL
  }
  void
  Local_Zd_Back(long F)
  {
    Z_Layer[F].File.Buf_Pos = Zd_File_Ptr;
    Z_Layer[F].File.Buf_Eof = Zd_File_Eof;
    Z_Layer[F].File.Buf_Len = Zd_File_Lim;
  }
  void
  Zd_Struct_Init(long F)
  {
    Zd_File = Z_Layer[F].File.Fil;

    Zd_File_Buf = Z_Layer[F].File.Buf;

    Zd_File_Ptr = Z_Layer[F].File.Buf_Pos;
    Zd_File_Eof = Z_Layer[F].File.Buf_Eof;
    Zd_File_Lim = Z_Layer[F].File.Buf_Len;

    Zd_Fragment = &Z_Layer[F].Fragment;

    Zd_Delta_X = -Delta_X;
    Zd_Delta_Y = -Delta_Y;
  }
  void
  Load_Insert_Master(void)
  {
  long LB, LV, LE, P1, P2;
  long LD, X, Y, V3, V4, TM;
    LB = ZLBNEXT();
    LE = LV = ZLBCO3[LB] = ZLVLIM;

    X = ZLDCO0[0];
    Y = ZLDCO1[0];

    P1 = P2 = IPOINT(X, Y);
    for(LD=1; LD<ZLDLIM; ++LD, P1=P2, LE=LV)
    {
      if(ZLDCO0[LD]==X&&ZLDCO1[LD]==Y) continue;
      P2 = IPOINT((X=ZLDCO0[LD]), (Y=ZLDCO1[LD]));

      LV = ZLVNEXT();
      V3 = ZVTNEXT();
      V4 = ZVTNEXT();

      if(ZPTCO1[P1]>X||(ZPTCO1[P1]==X&&ZPTCO2[P1]>Y))
	TM = V3, V3 = V4, V4 = TM;

      ZLVCO2[LV] = V3;
      ZLVCO1[LE] = LV;

      ZVTCO5[V3] = LV;
      ZVTCO6[V3] = V4;
      ZVTCO6[V4] = V3;

      ZVTCO2[V4] = P1;
      ZVTCO1[V3] = P1;
      ZVTCO1[V4] = P2;
      ZVTCO2[V3] = P2;

      ZVTCO5[V4] = 0;
      ZVTCO8[V3] = 0;
      ZVTCO8[V4] = 0;

      ZVTCO4[V3] = 0;
      ZVTCO4[V4] = 0;
    }
    ZLVCO1[LV] = ZLBCO3[LB];
  }
  void
  Generate_CBDB(long * Z, long L)
  {
  long i, Y;
  char o, O;
    Y = ZLDCO1[0];

    if(Y==Delta_Y_1) o = 1;
    else
    if(Y==Delta_Y_2) o = 1;
    else o = 0;

    for(i = 1; i<ZLDLIM; ++i)
    {
      Y = ZLDCO1[i];

      if(Y==Delta_Y_1) O = 1;
      else
      if(Y==Delta_Y_2) O = 1;
      else O = 0;

      if(O||o)
      {
	Z[LldNext(L)] = ZLDCO0[i-1];
	Z[LldNext(L)] = ZLDCO1[i-1];

	Z[LldNext(L)] = ZLDCO0[i];
	Z[LldNext(L)] = ZLDCO1[i];
      }
      o = O;
    }
  }
  void
  Generate_BBDB(long * Z, long L)
  {
  long i, X;
  char o, O;
    X = ZLDCO0[0];

    if(X==Delta_X_2) o = 1;
    else o = 0;

    for(i = 1; i<ZLDLIM; ++i)
    {
      X = ZLDCO0[i];

      if(X==Delta_X_2) O = 1;
      else O = 0;

      if(O||o)
      {
	Z[LldNext(L)] = ZLDCO0[i-1];
	Z[LldNext(L)] = ZLDCO1[i-1];

	Z[LldNext(L)] = ZLDCO0[i];
	Z[LldNext(L)] = ZLDCO1[i];
      }
      o = O;
    }
  }
  void
  Read_Bdb_Center(long L)
  {
  long Bdb_Block, * Z;

    L = LLDASS[L];
    Z = LLDPTR[L];

    CnFROM[L] = LLDLIM[L];
    CentTO[L] = LLDLIM[L];

    if(Bdb_Yg==YgCnt)
    {
    /*SCAN REACHED UPPER BOUNDARY.*/
      Bdb_Regen = 1;
      return;
    }
    Delta_X = CxMin + Bdb_Xg*XgDiv;
    Delta_Y = CyMin + Bdb_Yg*YgDiv;

    Delta_Y_1 = Delta_Y;
    Delta_Y_2 = Delta_Y + YgDiv;
    if(Delta_Y_2==CyMax)
    {
    /*UPPER BOUNDARY VECTORS MUST BE SCIPPED.*/
      Delta_Y_2 -= YgDiv;
    }
    if(Delta_Y_1==CyMin)
    {
    /*LOWER BOUNDARY VECTORS MUST BE SCIPPED.*/
      Delta_Y_1 += YgDiv;
    }
    Bdb_Block = Bdb_Xg*YgCnt + Bdb_Yg;

    if(Bdb_Block_2>Bdb_Block)
    {
    /*THIS FRAGMENT IS EMPTY.*/
      return;
    }
    else
    if(Bdb_Block_2<Bdb_Block)
    {
      Print_Pos_Err();
      zabort();
    }
    Zd_Struct_Init(1);

    for(
    ZDREAD_P();
    Bdb_Block_2==Bdb_Block;
    ZDREAD_P())
    {
    if(ZLDLIM==0) continue;

    Z_Check_Closure();
    if(Pdb_Load_Too)
    {
    Load_Insert_Master();
    }
    if(YgCnt==1) continue;

    Generate_CBDB(Z, L);
    }
    CentTO[L] = LLDLIM[L];

    Local_Zd_Back(1);
  }
  void
  Read_Bdb_Right(long L)
  {
  long Bdb_Block,* Z;

    L = LLDASS[L];
    Z = LLDPTR[L];

    RgFROM[L] = LLDLIM[L];
    RighTO[L] = LLDLIM[L];

    if(Right_Disabled)
    {
    /*BORDER CASE*/
      return;
    }
    if(Bdb_Yg==YgCnt)
    {
    /*SCAN REACHED UPPER BOUNDARY.*/
      Bdb_Regen = 1;
      return;
    }
    Delta_X = CxMin + Bdb_Xg*XgDiv;
    Delta_Y = CyMin + Bdb_Yg*YgDiv;

    Delta_X_2 = Delta_X;

    Bdb_Block = Bdb_Xg*YgCnt + Bdb_Yg;

    if(Bdb_Block_3>Bdb_Block)
    {
    /*THIS FRAGMENT IS EMPTY.*/
      return;
    }
    else
    if(Bdb_Block_3<Bdb_Block)
    {
      Print_Pos_Err();
      zabort();
    }
    Zd_Struct_Init(2);

    for(
    ZDREAD_P();
    Bdb_Block_3==Bdb_Block;
    ZDREAD_P())
    {
    if(ZLDLIM==0) continue;

    Z_Check_Closure();
    Generate_BBDB(Z, L);
    }
    RighTO[L] = LLDLIM[L];

    Local_Zd_Back(2);
  }
  void
  Read_Bdb_Left(long L)
  {
  long Bdb_Block, * Z;

    L = LLDASS[L];
    Z = LLDPTR[L];

    LfFROM[L] = LLDLIM[L];
    LeftTO[L] = LLDLIM[L];

    if(Left_Disabled)
    {
    /*BORDER CASE*/
      return;
    }
    if(Bdb_Yg==YgCnt)
    {
    /*SCAN REACHED UPPER BOUNDARY.*/
      Bdb_Regen = 1;
      return;
    }
    Delta_X = CxMin + Bdb_Xg*XgDiv;
    Delta_Y = CyMin + Bdb_Yg*YgDiv;

    Delta_X_2 = Delta_X + XgDiv;

    Bdb_Block = Bdb_Xg*YgCnt + Bdb_Yg;

    if(Bdb_Block_1>Bdb_Block)
    {
    /*THIS FRAGMENT IS EMPTY.*/
      return;
    }
    else
    if(Bdb_Block_1<Bdb_Block)
    {
      Print_Pos_Err();
      zabort();
    }
    Zd_Struct_Init(0);

    for(
    ZDREAD_P();
    Bdb_Block_1==Bdb_Block;
    ZDREAD_P())
    {
    if(ZLDLIM==0) continue;

    Z_Check_Closure();
    Generate_BBDB(Z, L);
    }
    LeftTO[L] = LLDLIM[L];

    Local_Zd_Back(0);
  }
  void
  Read_Pdb_Next_Block(void)
  {
  long Pdb_Block;
    if(Pdb_Yg==YgCnt)
    {
      Bdb_Regen = 1;
      return;
    }
    Delta_X = CxMin + Pdb_Xg*XgDiv;
    Delta_Y = CyMin + Pdb_Yg*YgDiv;

    Pdb_Block = Pdb_Xg*YgCnt + Pdb_Yg;

    if(Pdb_Block_X>Pdb_Block)
    {
    /*THIS FRAGMENT IS EMPTY.*/
      return;
    }
    else
    if(Pdb_Block_X<Pdb_Block)
    {
      Print_Pos_Err();
      zabort();
    }
    Zd_Struct_Init(3);

    for(
    ZDREAD_P();
    Pdb_Block_X==Pdb_Block;
    ZDREAD_P())
    {
    if(ZLDLIM==0)continue;

    Z_Check_Closure();
    Load_Insert_Master();
    }
    Local_Zd_Back(3);
  }
  void
  Seek_Block(long F)
  {
    long Bdb_Block;
    Bdb_Block = Bdb_Xg*YgCnt + Bdb_Yg;

    Zd_Struct_Init(F);

    while(Block_For_Get[0]<Bdb_Block)
    Skip_Polygon();

    Local_Zd_Back(F);
  }
  void
  Load_Next_Row_Common_Case(void)
  {
  long I;
    I = LLDASS[0];
    LLDASS[0] = LLDASS[1];
    LLDASS[1] = LLDASS[2];
    LLDASS[2] = I;

    LLDLIM[I] = 0;

    LeftTO[I] = 0;
    CentTO[I] = 0;
    RighTO[I] = 0;

    LfFROM[I] = 0;
    CnFROM[I] = 0;
    RgFROM[I] = 0;

    Pdb_Yg += 1;

    PXMIN = CxMin + Pdb_Xg*XgDiv - 0.5*XgDiv;
    PYMIN = CyMin + Pdb_Yg*YgDiv - 0.5*YgDiv;

    PXMAX = CxMin + Pdb_Xg*XgDiv + 2.0*XgDiv;
    PYMAX = CyMin + Pdb_Yg*YgDiv + 2.0*YgDiv;

    Determine_Point_Base();

    Bdb_Xg = Pdb_Xg;
    Bdb_Yg = Pdb_Yg + 1;

    Pdb_Load_Too = 0;

    Read_Bdb_Center(2);

    Bdb_Xg = Pdb_Xg - 1;
    Read_Bdb_Left(2);

    Bdb_Xg = Pdb_Xg + 1;
    Read_Bdb_Right(2);

    Read_Pdb_Next_Block();
  }
  void
  Regen_Row_Streams(void)
  {
  long i;
    LLDASS[0] = 0;
    LLDASS[1] = 1;
    LLDASS[2] = 2;

    LLDLIM[0] = 0;
    LLDLIM[1] = 0;
    LLDLIM[2] = 0;

    for(i = 0; i<3; ++i)
    LeftTO[i] = 0,
    CentTO[i] = 0,
    RighTO[i] = 0,

    LfFROM[i] = 0,
    CnFROM[i] = 0,
    RgFROM[i] = 0;

    LLDPTR[0] = LDPTR1;
    LLDPTR[1] = LDPTR2;
    LLDPTR[2] = LDPTR3;

    if(Left_Disabled&&XgCnt!=1)
    {
      Left_Enabled = 1;
    }

    Pdb_Xg+= 1;
    Pdb_Yg = 0;

    PXMIN = CxMin + Pdb_Xg*XgDiv - 0.5*XgDiv;
    PYMIN = CyMin + Pdb_Yg*YgDiv - 0.5*YgDiv;

    PXMAX = CxMin + Pdb_Xg*XgDiv + 2.0*XgDiv;
    PYMAX = CyMin + Pdb_Yg*YgDiv + 2.0*YgDiv;

    Determine_Point_Base();

    Bdb_Regen = 0;

    if(Pdb_Xg==XgCnt-1) Right_Enabled = 0;
    else if(Pdb_Xg==XgCnt) return;
    else Right_Enabled = 1;

    Pdb_Load_Too = 1;

    Bdb_Xg = Pdb_Xg;
    Bdb_Yg = Pdb_Yg;
    Read_Bdb_Center(1);

    Mirror_File_Buffer(1, 3);

    Pdb_Load_Too = 0;

    Bdb_Yg += 1;
    Read_Bdb_Center(2);

    Bdb_Xg = Pdb_Xg - 1;
    Bdb_Yg = Pdb_Yg;
    Read_Bdb_Left(1);

    Bdb_Yg += 1;
    Read_Bdb_Left(2);

    Bdb_Xg = Pdb_Xg + 1;
    Bdb_Yg = Pdb_Yg;
    Read_Bdb_Right(1);

    Bdb_Yg += 1;
    Read_Bdb_Right(2);
  }
  void
  Initial_Load_Common_Case(void)
  {
  long i;
    ZLBLIM = 1;
    ZLVLIM = 1;
    ZPTLIM = 1;
    ZVTLIM = 2;

    Pdb_Xg = 0;
    Pdb_Yg = 0;

    PXMIN = CxMin + Pdb_Xg*XgDiv - 0.5*XgDiv;
    PYMIN = CyMin + Pdb_Yg*YgDiv - 0.5*YgDiv;

    PXMAX = CxMin + Pdb_Xg*XgDiv + 2.0*XgDiv;
    PYMAX = CyMin + Pdb_Yg*YgDiv + 2.0*YgDiv;

    Determine_Point_Base();

    LLDASS[0] = 0;
    LLDASS[1] = 1;
    LLDASS[2] = 2;

    LLDLIM[0] = 0;
    LLDLIM[1] = 0;
    LLDLIM[2] = 0;

    for(i = 0; i<3; ++i)
    LeftTO[i] = 0,
    CentTO[i] = 0,
    RighTO[i] = 0,

    LfFROM[i] = 0,
    CnFROM[i] = 0,
    RgFROM[i] = 0;

    LLDPTR[0] = LDPTR1;
    LLDPTR[1] = LDPTR2;
    LLDPTR[2] = LDPTR3;

    Left_Enabled = 0;

    if(XgCnt>1) Right_Enabled = 1;
    else Right_Enabled = 0;

    Bdb_Regen = 0;

    Pdb_Load_Too = 1;

    Bdb_Xg = 0;
    Bdb_Yg = 0;
    Read_Bdb_Center(1);

    Mirror_File_Buffer(1, 3);

    Pdb_Load_Too = 0;

    Bdb_Yg = 1;
    Read_Bdb_Center(2);

    Mirror_File_Buffer(1, 2);

    Bdb_Xg = 1;
    Bdb_Yg = 0;
    if(Right_Enabled)
    Seek_Block(2);

    Read_Bdb_Right(1);

    Bdb_Yg = 1;
    Read_Bdb_Right(2);
  }
  void LLD_Insert
  (long*L,
   long D,
   char c,
   long I,
   long J)
  {
  char on; long LD;
    for(on = 0; I<J; on = 0)
    {
      ZLDLIM = 0;

      LD = ZLDNEXT();
      ZLDCO0[LD] = L[I++];
      ZLDCO1[LD] = L[I++];

      if(c)
      {
	on |= ZLDCO1[LD]==D;
      }
      else on = 1;

      LD = ZLDNEXT();
      ZLDCO0[LD] = L[I++];
      ZLDCO1[LD] = L[I++];

      if(c)
      {
	on |= ZLDCO1[LD]==D;
      }
      if(on) Load_Insert_Master();
    }
  }
  void Load_Right(long L)
  {
  long K, I, J, D;

    K = L;
    L = LLDASS[L];

    I = RgFROM[L];
    J = RighTO[L];

    D = CyMin + Pdb_Yg*YgDiv;
    if(K==2) D += YgDiv;

    Lb_RgFrom[K] = ZLBLIM;

    LLD_Insert(LLDPTR[L], D, (K!=1), I, J);

    Lb_RighTo[K] = ZLBLIM;
  }
  void Load_Left(long L)
  {
  long K, I, J, D;

    K = L;
    L = LLDASS[L];

    I = LfFROM[L];
    J = LeftTO[L];

    D = CyMin + Pdb_Yg*YgDiv;
    if(K==2) D += YgDiv;

    Lb_LfFrom[K] = ZLBLIM;

    LLD_Insert(LLDPTR[L], D, (K!=1), I, J);

    Lb_LeftTo[K] = ZLBLIM;
  }
  void Load_Center(long L)
  {
  long K, I, J, D;

    K = L;
    L = LLDASS[L];

    Lb_CnFrom[K] = ZLBLIM;
    Lb_CentTo[K] = ZLBLIM;

    if(K==1) return;

    I = CnFROM[L];
    J = CentTO[L];

    D = CyMin + Pdb_Yg*YgDiv;
    if(K==2) D += YgDiv;

    LLD_Insert(LLDPTR[L], D, 1, I, J);

    Lb_CentTo[K] = ZLBLIM;
  }
  char BScan
  (long I,
   long J,
   long D,
   long y,
   long Y)
  {
  long K, e, v, V, p;
  long z, x, P, Z, X;
    while(I++<J)
    {
      v = ZLBCO3[I-1];

      if(v==0) continue;

      e = v;
      K = 0;
      do
      {
	V = ZLVCO2[v];
	v = ZLVCO1[v];
	++K;

	if(V%2) V = ZVTCO6[V];

	p = ZVTCO1[V];
	z = BS1_coord[p];
	x = BS2_coord[p];

	P = ZVTCO2[V];
	Z = BS1_coord[P];
	X = BS2_coord[P];

	if(z!=Z)
	{
	ZLBCO3[I-1] = 0;
	continue;
	}
	if(X<=y)
	{
	continue;
	}
	if(x>=Y)
	{
	continue;
	}
	if(x==y)
	{
	if(K==1&&v==e&&X==Y)
	{
	ZLBCO3[I-1] = 0;
	return 0;
	}
	continue;
	}
	if(X==Y)
	{
	continue;
	}
	if(x<y)
	{
	SPLITVT(V, ZVTCO1[D]);
	return 1;
	}
	if(x>y)
	{
	SPLITVT(D, p);
	return 1;
	}
      }
      while(v&&e!=v);
    }
    return 0;
  }
  char On_Left_Bound
  (long D,
   long y,
   long Y)
  {
  long I, J;
  char R;
    if(D%2)
    {
      D = ZVTCO6[D];

      I = Y;
      Y = y;
      y = I;
    }

    I = Lb_LfFrom[1];
    J = Lb_LeftTo[1];

    BS1_coord = ZPTCO1;
    BS2_coord = ZPTCO2;

    R = BScan(I, J, D, y, Y);

    return R;
  }
  char On_Right_Bound
  (long D,
   long y,
   long Y)
  {
  long I, J;
  char R;
    if(D%2)
    {
      D = ZVTCO6[D];

      I = Y;
      Y = y;
      y = I;
    }

    I = Lb_RgFrom[1];
    J = Lb_RighTo[1];

    BS1_coord = ZPTCO1;
    BS2_coord = ZPTCO2;

    R = BScan(I, J, D, y, Y);

    return R;
  }
  char On_Lower_Bound
  (long D,
   long x,
   long X)
  {
  long I, J;
  char R;
    if(D%2)
    {
      D = ZVTCO6[D];

      I = X;
      X = x;
      x = I;
    }

    I = Lb_CnFrom[0];
    J = Lb_CentTo[0];

    BS1_coord = ZPTCO2;
    BS2_coord = ZPTCO1;

    R = BScan(I, J, D, x, X);

    return R;
  }
  char On_Upper_Bound
  (long D,
   long x,
   long X)
  {
  long I, J;
  char R;
    if(D%2)
    {
      D = ZVTCO6[D];

      I = X;
      X = x;
      x = I;
    }

    I = Lb_CnFrom[2];
    J = Lb_CentTo[2];

    BS1_coord = ZPTCO2;
    BS2_coord = ZPTCO1;

    R = BScan(I, J, D, x, X);

    return R;
  }
  void On_Boundary_Extraction(void)
  {
  long b;
  char o, O, z, Z, A, B, R;
  long v, e, p, x, y, X, Y, V;
    Delta_Y = CyMin + Pdb_Yg*YgDiv;
    Delta_X = CxMin + Pdb_Xg*XgDiv;

    Delta_Y_2 = Delta_Y + YgDiv;
    Delta_X_2 = Delta_X + XgDiv;

    for(b = 1; b<Lb_PbasTO; ++b)
    {
      v = e = ZLBCO3[b];

      p = ZVTCO1[ZLVCO2[e]];

      x = ZPTCO1[p];
      y = ZPTCO2[p];

      o = 0;
      O = 0;

      if(x==Delta_X)   o = 1;
      else
      if(x==Delta_X_2) o = 2;

      if(y==Delta_Y)   O = 4;
      else
      if(y==Delta_Y_2) O = 8;

      A = o|O;

      do
      {
	V = ZLVCO2[v];
	p = ZVTCO2[V];

	X = ZPTCO1[p];
	Y = ZPTCO2[p];

	z = 0;
	Z = 0;
	R = 0;

	if(X==Delta_X)   z = 1;
	else
	if(X==Delta_X_2) z = 2;

	if(Y==Delta_Y)   Z = 4;
	else
	if(Y==Delta_Y_2) Z = 8;

	B = z|Z;

	if(!A||!B||!(A&B))
	{
	/*INSIDE! MUST BE SKIPPED.*/
	  x = X;
	  y = Y;
	  A = B;
	  o = z;
	  O = Z;
	  v = ZLVCO1[v];
	  continue;
	}
	/*NOTE! ALL POLYGONS ARE*/
	/*CLOCKWISE.*/
	/*BECAUSE OF IT BOUNDARY*/
	/*SIDE EVALUATING IS MORE*/
	/*SIMPLE.*/

	if(o)

	switch(o)
	{
	case 1: /*LEFT OR UPPER*/

	if(z==1) R = On_Left_Bound (V, y, Y);
	else     R = On_Upper_Bound(V, x, X);

	break;

	case 2: /*RIGHT OR LOWER*/

	if(z==2) R = On_Right_Bound(V, y, Y);
	else     R = On_Lower_Bound(V, x, X);

	break;
	}
	else
	switch(O)
	{
	case 8: /*UPPER*/

	R = On_Upper_Bound(V, x, X);

	break;

	case 4: /*LOWER*/

	R = On_Lower_Bound(V, x, X);

	break;
	}
	if(!R)
	x = X,
	y = Y,
	A = B,
	o = z,
	O = Z,
	v = ZLVCO1[v];
      }
      while(!R&&v!=e);
    }
  }
  void McxVtxBead(void)
  {
  register long v, r;
    for(v = 2; v<ZVTLIM; ++v)
    {
      if(ZVTCO6[v]==0)
      {
      continue;
      }
      if(ZVTCO5[v]==0)
      {
      continue;
      }
      r = ZVTCO6[v];

      if(ZVTCO5[r]==0)
      {
      continue;
      }
      ZVTCO6[v] = 0;
      ZVTCO6[r] = 0;
    }
  }
  void SetxRxStat(void)
  {
  long b, v, e, z;
    for(b = 1; b<Lb_PbasTO; ++b)
    {
      e = ZLBCO3[b];
      if(e==0)
      {
      continue;
      }
      v = e;
      do
      {
      z = ZLVCO2[v];
      ZVTCO4[z] = 1;

      v = ZLVCO1[v];
      }
      while(v!=e);
    }
  }
  void
  dontworry_1(void)
  {
  long T;
  T = ZLDLIM? ++Total_Shapes: 77;

  if(!(T-(T/77)*77))
  fprintf(stderr, "\rINPUT: KBYTES=%ld; OUTPUT: SHAPES=%ld; FRAGMENT: %ld",
  ZZ_RP_KB/1024, Total_Shapes, Pdb_Xg*YgCnt+Pdb_Yg);
  }
  /*
  long
  Ld_Incr_Loc(long L)
  {
  if(++L>=ZLDLIM) L=0;
  return(L);
  }
  */
  void
  Write_Chain_Pieces(void)
  {
    long S;
    /*
    long P;
    */
    long E;
    long I;
    long L;

    long c;
    long*x;
    long*y;

    x = ZLDCO0;
    y = ZLDCO1;
    c = ZLDLIM;

    Z_Open_Shape = 1;

    if(PDJCNT%2)
    Print_Program_Err(),
    zabort();

    for(I = 0; I<PDJCNT; I += 2)
    {
    PLDLIM = 0;

    S = PDJCO0[I];
    E = PDJCO0[I+1];

    if(S>E)
    {
    L = ZLDLIM-S;

    PLDLIM += L;
    if(PLDLIM>=PLDMAX) ZoutAbort();

    memcpy(PLDCO0, ZLDCO0+S, L*4);
    memcpy(PLDCO1, ZLDCO1+S, L*4);
    L = E + 1;

    if(PLDLIM+L>=PLDMAX) ZoutAbort();

    memcpy(PLDCO0+PLDLIM, ZLDCO0, L*4);
    memcpy(PLDCO1+PLDLIM, ZLDCO1, L*4);
    PLDLIM += L;
    }
    /*
    for(L = S; 1; L = Ld_Incr_Loc(L))
    {
    P = PLDNEXT();
    PLDCO0[P] = ZLDCO0[L];
    PLDCO1[P] = ZLDCO1[L];

    if(L==E)break;
    }
    */
    else
    {
    PLDLIM = E-S+1;
    if(PLDLIM>=PLDMAX) ZoutAbort();

    memcpy(PLDCO0, ZLDCO0+S, PLDLIM*4);
    memcpy(PLDCO1, ZLDCO1+S, PLDLIM*4);
    }
    ZLDCO0 = PLDCO0;
    ZLDCO1 = PLDCO1;

    ZLDLIM = PLDLIM +1;
    Dix_output();

    dontworry_1();
    ZLDCO0 = x;
    ZLDCO1 = y;

    ZLDLIM = c;
    }
  }
  void
  Put_Dj_Local(long LD)
  {
  if(++PDJCNT>PDJMAX) ZoutAbort();
  PDJCO0[PDJCNT-1] = LD;
  }
  void SxTraverse(long VT)
  {
    long LD;
    long P2;
    long V3;
    long V4;

    long XM;
    long xm;

    long MX;
    long mx;

    long xx;

    XM = CxMin;
    xm = CxMax;

    mx = CxMin + Pdb_Xg*XgDiv;
    MX = mx+XgDiv;

    ZLDLIM = 0;
    PDJCNT = 1;
    STATUS = 1;

    V3 = VT;
    do
    {
    ZVTCO8[V3] = 1;
    LD = ZLDNEXT();

    P2 = ZVTCO2[V3];

    xx =
    ZLDCO0[LD] = ZPTCO1[P2];
    ZLDCO1[LD] = ZPTCO2[P2];

    if(xx>XM)XM = xx;
    if(xx<xm)xm = xx;

    V4 = V3;
    V3 = ZVTCO6[V3];

    V3 = FETCHSUCCESSOR(V3);
    while(ZVTCO6[V3]==0)
    V3 = FETCHSUCCESSOR(V3);

    if(ZVTCO6[V4]==V3)Put_Dj_Local(LD);
    }
    while(V3!=VT);

    if(xm>=MX||XM<=mx)
    {
    return;
    }
    if(--PDJCNT!=0)
    {
    PDJCO0[0] = PDJCO0[PDJCNT];
    Write_Chain_Pieces();
    return;
    }
    Z_Open_Shape = 0;

    ++ZLDLIM; Dix_output();

    dontworry_1();
  }
  void S_Traverse(void)
  {
  long v;
    ZLBLIM = 1;
    ZLVLIM = 1;

    for(v = 2; v<ZVTLIM; ++v)
    {
    if(ZVTCO8[v]!=0)
    {
    continue;
    }
    if(ZVTCO6[v]==0)
    {
    continue;
    }
    if(ZVTCO4[v]==0)
    {
    continue;
    }
    SxTraverse(v);
    }
  }
  void ZZxLoadxAbout(void)
  {
  long i;
  Lb_PbasTO = ZLBLIM;

  for(i = 0; i<3; ++i)Load_Left(i);
  for(i = 0; i<3; ++i)Load_Right(i);
  for(i = 0; i<3; ++i)Load_Center(i);
  }
  void Shapes_Generation(void)
  {
    On_Boundary_Extraction();

    POINT_VECTOR_ANALYSIS(2);

    McxVtxBead();
    SetxRxStat();
    S_Traverse();
  }
  void
  Shapes_Generation_Main(void)
  {
    fprintf(stderr, "\nBoundary resolution data Extraction Started on %s\n",
    Z_Layer[0].Name);
    fprintf(stderr, "\nTotal Fragments = %ld (in X dir.= %ld, in Y dir.= %ld)\n",
    XgCnt*YgCnt, XgCnt, YgCnt);

    Initial_Load_Common_Case();

    ZLDLIM = 0; dontworry_1();

    ZZxLoadxAbout();

    Shapes_Generation();
    while(Pdb_Xg+1<XgCnt||Pdb_Yg+1<YgCnt)
    {
    ZLBLIM = 1;
    ZLVLIM = 1;
    ZPTLIM = 1;
    ZVTLIM = 2;

    if(Bdb_Regen) Regen_Row_Streams();
    else
    Load_Next_Row_Common_Case();

    ZZxLoadxAbout();

    Shapes_Generation();
    }
    ZLDLIM = 0; dontworry_1();
    Dix_close();

    Delete_File(O_Layer.BdbN);
    rename(O_Layer.PdbN, O_Layer.BdbN);
    free(O_Layer.File.Buf);

    Print_Normal_Finish();
  }
