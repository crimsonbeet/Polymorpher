  /**/
  #include<DOS.H>
  #include<ERRNO.H>
  #include<MATH.H>
  #include<STDIO.H>
  /**/
  #ifdef __BORLANDC__
  #include<DIR.H>
  #include<ALLOC.H>
  #endif
  /**/
  #include<STDLIB.H>
  #include<CTYPE.H>
  #include<STRING.H>
  #ifndef __BORLANDC__
  #define stricmp strcmpl
  #define max pmax
  #define min pmin
  #endif
  /**/
  #ifdef __BORLANDC__
  #include<VALUES.H>
  #else
  #include<FLOAT.H>
  #endif
  /**/
  #include<LIMITS.H>
  #include<PROCESS.H>

#ifndef __BORLANDC__
#define far
#define huge
#endif

typedef struct
{
long
    xb,
    yb,
    xe,
    ye,
    dx,
    zx,
    zy;
double
    ct;
signed char
    sx,
    sy;
} vector;

typedef struct point
{
long
    x,
    y;
struct point
    *n;
} point;

struct front
{
struct front
    *n;
vector
    LFT,
    RGT;
short
    lc,
    rc;
};

long MinS = 4, MaxS = 200;

#define horizontal(a) ((a).yb == (a).ye ? 1 : 0 )
#define vertical(a)   ((a).xb == (a).xe ? 1 : 0 )
#define swapf(m, n, a) ((a) = (m), (m) = (n), (n) = (a))

void *m_alloc (long size);
void 
Message (char *m)
{
	fprintf(stderr, "\n%s", m);
	return;
}

char is_joined
(vector *v1,
 vector *v2)
{
char i, j;
  i = v1->xb == v2->xb;
  j = v1->yb == v2->yb;
  if (i && j) return 1;
  i = v1->xb == v2->xe;
  j = v1->yb == v2->ye;
  if (i && j) return 1;
  i = v1->xe == v2->xb;
  j = v1->ye == v2->yb;
  if (i && j) return 1;
  i = v1->xe == v2->xe;
  j = v1->ye == v2->ye;
  if (i && j) return 1;
  return 0;
}

// PROCEDURES FOR BOX BUILDING

#define TRUE 1
#define FALS 0
#define pabs(l) ((l) > 0 ? (l) : -(l))
#define pmod(z,x) ( (z)-(((z)/(x))*(x)) )
#define pmin(a,b) ((a) < (b) ? (a) : (b))
#define pmax(a,b) ((a) < (b) ? (b) : (a))
#define crnb (vectors[chnl[crnc]])
#define bcdr crnb.sx
#define bcxm crnb.xe
#define bcxl crnb.xb
#define bcyl crnb.yb
#define bcym crnb.ye
#define bckd crnb.ct
#define nxtf (crnf->n)
#define nlyl nxtf->LFT.yb
#define nlym nxtf->LFT.ye
#define nlxl nxtf->LFT.xb
#define nlxm nxtf->LFT.xe
#define nryl nxtf->RGT.yb
#define nrym nxtf->RGT.ye
#define nrxl nxtf->RGT.xb
#define nrxm nxtf->RGT.xe
#define flzy crnf->LFT.zy
#define frzy crnf->RGT.zy
#define flzx crnf->LFT.zx
#define frzx crnf->RGT.zx
#define fldx crnf->LFT.dx
#define frdx crnf->RGT.dx
#define flyl crnf->LFT.yb
#define flym crnf->LFT.ye
#define flxl crnf->LFT.xb
#define flxm crnf->LFT.xe
#define fryl crnf->RGT.yb
#define frym crnf->RGT.ye
#define frxl crnf->RGT.xb
#define frxm crnf->RGT.xe
#define flkd crnf->LFT.ct
#define frkd crnf->RGT.ct
#define flft crnf->LFT
#define frgt crnf->RGT

#define gt(k,m) ( \
  (k).yb > (m).yb ? TRUE : \
  (k).yb < (m).yb ? FALS : \
  (k).xb > (m).xb ? TRUE : \
  (k).xb < (m).xb ? FALS : \
  (k).ct - (m).ct >  0.005 ? TRUE : \
  (k).ct - (m).ct < -0.005 ? FALS : \
  (k).sx > (m).sx ? TRUE : \
  FALS)

#define swab_(n,m,w) ((w)=chnl[(n)], chnl[(n)]=chnl[(m)], chnl[(m)]=(w))

#define pmod(z,x) ( (z)-(((z)/(x))*(x)) )

#define NEXTvector NEXTvector()

#ifdef __BORLANDC__
vector huge * vectors;
#else
vector * vectors;
#endif
long vectors_lim;
vector
    zero = {LONG_MAX, LONG_MAX, LONG_MAX, LONG_MAX}, /* EMPTY VECTOR */
    stopvector = {LONG_MAX, LONG_MAX, 0, 0}; /* LAST VECTOR */
struct front
    *oldf,   /* POINTERS */
    *crnf,   /* AT */
    *topf;   /* FRONT */
long
    fcyl,
    fcxl;
unsigned short * chnl;
unsigned short
    crnc,
    bxsm;
FILE
    *BFIL,
    *EFIL,
    *PFIL;
short
    BINM =0,    /* INPUT FROM BIN FILE */
    ANGLE =0,
    CRNTlayer =1;
long
    MSHT =1,    /* MAGNIFICATION */
    TCHS =4,    /* MIN EXPOSURE */
    ECHS =1500, /* MAX EXPOSURE */
    TCHF =4,    /* ERROR */
    ZONE =20;    /* FOR SORTING */
long
    ZERRORS = 0,
    WARNINGS = 0,
    NBOXES = 0,
    NPOLYGONS = 0,
    NWIRES = 0,
    NRECTANGLES = 0,
    NEXPOSURES = 0;
long Max_Strip;
long Max_Dist;
  /**/
  long UN001;
  long UN002;
  long EMSIZ;
  long LVCNT;
  long BLCNT;
  long UBSIZ;
  long XBSIZ;
  long YBSIZ;
  long XBCNT; /*TOTAL-BLOCKS-IN-X-DIRECTION*/
  long YBCNT; /*TOTAL-BLOCKS-IN-Y-DIRECTION*/
  long CXMIN; /*MIN-X-COORD-ON-CHIP*/
  long CXMAX; /*MAX-X-COORD*/
  long CYMIN; /*MIN-Y-COORD-ON-CHIP*/
  long CYMAX; /*MAX-Y-COORD*/
  /**/
  long Z_Fragment;
  long Z_Layers_Cnt;
  /**/
  double ZZ_DELTA_X;
  double ZZ_DELTA_Y;
  /**/
  double STSIZ;
  /**/
  char*Zd_File_Buf;
  long Zd_File_Ptr;
  long Zd_File_Eof;
  long Zd_File_Lim;

  FILE*Zd_File;
  long DIX_Fragment;
  long DIX_Layer;
  long Dix_Layer;

  long*Zd_Fragment = &DIX_Fragment;
  long*Zd_Layer = &Dix_Layer;

  long Zd_Delta_X;
  long Zd_Delta_Y;
char
    * rptNAME,
    * inpNAME,
    * patNAME,
    * appNAME,
    * expNAME,
    * strDATE,
    * strTIME;

short _EXIT = 0;
long NELEMS = 0, NEXPS = 0;

void done (short nerr)
{
  exit(nerr);
}

void
dontworry(void)
{
fprintf(stderr, "\rPOLYGONS PASSED %ld, FLASHES GENERATED %ld", NELEMS, NEXPS);
}
void compute_exposure (void);

void vector_scanner(void);

void zabort (short );

void NEXTvector
{
  ++crnc;
  while (bcyl == bcym) {vector_scanner (); ++crnc;}
}

long compute_cut_x
(vector *v,
 long y)
{
long
    x,
    a,
    b;
double
    c,
    dx;
  a = v->yb - v->ye;
  b = v->xe - v->xb;
  c = (double)(v->xb) *v->ye - (double)(v->xe) *v->yb;
  dx = (double)(b) *(-y) -c;
  x  = a != 0 ? floor (dx /a +0.5): v->xe;
  return x;
}

long compute_cut_y_for_dispvectors
(short diry,
 short dist)
{
long y;
double a0, b0, c0, a1, b1, c1, ds, dy;
  a0 = flyl - flym;
  b0 = flxm - flxl;
  c0 = (double)(flxl +fldx) *flym - (double)(flxm +fldx) *flyl;
  a1 = fryl - frym;
  b1 = frxm - frxl;
  c1 = (double)(frxl -frdx) *frym - (double)(frxm -frdx) *fryl;
  ds = a0 *b1 - b0 *a1;
  dy = c0 *a1 - a0 *c1;
  y  = ds != 0 ? floor (dy /ds +0.5):
       diry < 0 ?
	  (dist ? -LONG_MAX : LONG_MAX):
       (dist ? LONG_MAX : -LONG_MAX);
  return y;
}

void WRITEBOX
(long *sbox)
{
long
    i = 0, j = 0, z = 0,
    stpx = 0, stpy = 0;
long
    dstx = 0,    dsty = 0,
    corx = 0,    cory = 0,    tbox[4];
  dstx = sbox[3] - sbox[1];
  dsty = sbox[2] - sbox[0];
  stpx = dstx / ECHS;
  stpy = dsty / ECHS;
  for (i = 0; i <= stpx; i++)
  {
      tbox[1] = sbox[1] + ECHS * i;
      tbox[3] = i == stpx ? sbox[3] : tbox[1] + ECHS;
      if((i==stpx) && (tbox[3]==tbox[1])) continue;
    for (j = 0; j <= stpy; j++)
    {
      tbox[0] = sbox[0] + ECHS * j;
      tbox[2] = j == stpy ? sbox[2] : tbox[0] + ECHS;
      if((j==stpy) && (tbox[2]==tbox[0])) continue;
      dstx = tbox[3] - tbox[1];
      dsty = tbox[2] - tbox[0];
      corx = tbox[1] + dstx/2.0;
      cory = tbox[0] + dsty/2.0;
      if(dstx < TCHS) dstx = TCHS;
      if(dsty < TCHS) dsty = TCHS;
      if(pmod(dstx, 2))
      {
	if(stpx) dstx += 1, corx += !i? 1:0;
	/*else dstx += 1;*/
      }
      if(pmod(dsty, 2))
      {
	if(stpy) dsty += 1, cory += !j? 1:0;
	else dsty += 1;
      }
/* MAKE OBJECT BOX FILE */
      if(UN001>1)
	{
	corx = floor(corx*STSIZ +0.5);
	cory = floor(cory*STSIZ +0.5);
	dstx = floor(dstx*STSIZ +0.5);
	dsty = floor(dsty*STSIZ +0.5);
	}
      fwrite (&corx, 4, 1, BFIL);
      fwrite (&cory, 4, 1, BFIL);
      fwrite (&dstx, 4, 1, BFIL);
      fwrite (&dsty, 4, 1, BFIL);
      z = 0;
      fwrite (&z, 2, 1, BFIL);
      NEXPS++;
if(!(NEXPS%256))dontworry();
    }
  }
}

long
    oly1 = 0,    oly2 = 0,    olx1 = 0,    olx2 = 0,
    dly1 = 0,    dly2 = 0,    dlx1 = 0,    dlx2 = 0,
    dsy1 = 0,    dsy2 = 0,    dsx1 = 0,    dsx2 = 0,
    erx1 = 0,    ery1 = 0,    erx2 = 0,    ery2 = 0,
    dst1 = 0,    dst2 = 0,    tmv1 = 0,    tmv2 = 0,
    inx1 = 0,    inx2 = 0,    iny1 = 0,    iny2 = 0,
    diry = 0,    endy = 0,    stty = 0;

void boxs_generater
(long endy,
 long TCHS,
 long inx1,
 long inx2)
{
short
    i,
    j,
    k,
    endloop =0;
long
    t[4],
    tmv1 = olx1,
    tmv2 = olx2;
  dsy1 = dsy2 = erx1 =
  erx2 = ery1 = ery2 = 0;
  while (!endloop)
  {
  i = oly1 >= endy;
  j = oly2 >= endy;
  endloop = i && j;
  i = dsy1 == dsy2;
  j = dsy1 >= TCHS;
  k = i && j;
  if (k || endloop)
  {
    t[0] = oly1-dsy1;
    t[2] = oly1;
    t[1] = inx1 < 0 ? olx1 +dsx1 : tmv1 +dsx1;
    t[3] = inx2 > 0 ? olx2 -dsx2 : tmv2 -dsx2;
    i = diry < 0 ? t[2] >stty :	t[0] <stty;
    j = t[1] < t[3];
    k = t[0] < t[2];
    if ((i && j) && k) WRITEBOX (t);
    dsy1 = dsy2 = 0;
    tmv1 = olx1; tmv2 = olx2;
  }
  if (oly1 < endy && dsy1 <= dsy2)
  {
    erx1 += dlx1;
    ery1 += dly1;
    if (erx1 > dst1) erx1 -= dst1, olx1 += inx1;
    if (ery1 > dst1) ery1 -= dst1, oly1 += iny1, dsy1 += iny1;
  }
  if (oly2 < endy && dsy2 <  dsy1)
  {
    erx2 += dlx2;
    ery2 += dly2;
    if (erx2 > dst2) erx2 -= dst2, olx2 += inx2;
    if (ery2 > dst2) ery2 -= dst2, oly2 += iny2, dsy2 += iny2;
  }
  }
}

void
TERMINATE1 (void)
{
long
    i,
    k,
    j,
    m,
    n;
long
    lbnd,
    cmlb,
    ubnd,
    cmub;
vector
    v,
    V,
    w,
    W;
long
    y;
long
    t[4],
    s[4],
    TCHS,
    STTY;
  inx1 = 0, inx2 = 0, iny1 = 1, iny2 = 1,
  dsy1 = 0, dsy2 = 0, dsx1 = 0, dsx2 = 0,
  dly1 = flym - flyl, dly2 = frym - fryl,
  dlx1 = flxm - flxl, dlx2 = frxm - frxl;
  oly1 = oly2 = flyl;
  olx1 = flxl; olx2 = frxl;
  cmlb = cmub = 0;
  i = flyl != fryl;
  j = flym <  fcyl;
  k = frym <  fcyl;
  if (dlx1 > 0) inx1 =  1;
  else
  if (dlx1 < 0) inx1 = -1;
  if (dlx2 > 0) inx2 =  1;
  else
  if (dlx2 < 0) inx2 = -1;
  tmv1 = inx1 != 0 ? pabs ((double)fldx /flkd)+0.5 :dly1;
  tmv2 = inx2 != 0 ? pabs ((double)frdx /frkd)+0.5 :dly2;
  TCHS = pmin (tmv1-1, tmv2-1);
  dlx1 = pabs (dlx1);
  dlx2 = pabs (dlx2);
  dst1 = dlx1 > dly1 ? dlx1 : dly1;
  dst2 = dlx2 > dly2 ? dlx2 : dly2;
  if (dlx1 == 0) dlx1 = dly1;
  if (dlx2 == 0) dlx2 = dly2;
  V.xb = flxl;
  W.xb = frxl;
  V.xe = flym > fcyl ? compute_cut_x (&flft, fcyl) :flxm;
  W.xe = frym > fcyl ? compute_cut_x (&frgt, fcyl) :frxm;
  v.ye = flym +flzy;
  v.yb = flyl +flzy;
  w.ye = frym +frzy;
  w.yb = fryl +frzy;
  v.yb = v.yb < fcyl ? v.yb : fcyl;
  w.yb = w.yb < fcyl ? w.yb : fcyl;
  v.ye = v.ye > flyl ? v.ye : flyl;
  w.ye = w.ye > flyl ? w.ye : flyl;
  y = pmax (w.yb, v.yb);
  k = crnf->lc;
  n = v.ye > fcyl;
  j = v.ye > flyl;
  m = v.yb < flyl;
  i = v.yb < fcyl;  // m = !n - ALWAYS; m = n - NOT ALLOWED
  v.xb = m? (j? (y < fcyl ? V.xb +fldx : V.xe) : V.xe) :
	 k? (y != fcyl ? compute_cut_x (&flft, y) : V.xe) +fldx : V.xb;
  v.xe = !m? (i? V.xe +fldx : v.xb) : V.xe;
  k = crnf->rc;
  n = w.ye > fcyl;
  j = w.ye > flyl;
  m = w.yb < flyl;
  i = w.yb < fcyl;
  w.xb = m? (j? (y < fcyl ? W.xb -frdx : W.xe) : W.xe) :
	 k? (y != fcyl ? compute_cut_x (&frgt, y) : W.xe) -frdx : W.xb;
  w.xe = !m? (i? W.xe -frdx : w.xb) : W.xe;
  V.ct = (double)(V.xb - V.xe) /(flyl - fcyl);
  W.ct = (double)(W.xb - W.xe) /(flyl - fcyl);
  diry = V.ct -W.ct < -0.001 ? -1 : V.ct -W.ct > 0.001 ? 1 : 0;
  i = flxl +fldx < frxl -frdx;
  stty = compute_cut_y_for_dispvectors (diry, i);
  stty = diry != 0? stty : i? fcyl :flyl;
  stty = pmax (flyl, pmin (fcyl, stty));
  // GENERATE LOWER BOX
  y = pmax (w.yb, v.yb);
  cmlb = (v.xb < w.xb) && (y >oly1);
  lbnd = 0;
  if (cmlb)
  {
    i = tmv1 >= y -oly1;
    j = tmv2 >= y -oly1;
    cmlb = i && j;
    lbnd =  !cmlb;
    t[0] = oly1, t[1] = v.xb, t[2] = y, t[3] = w.xb;
  }
  // END GENERATE LOWER BOX
  if (lbnd) // FILL UP IN BAD BOX OCCURENCE
  {
    dsx1 = !i ? fldx : 0;
    dsx2 = !j ? frdx : 0;
    olx1 = !i ? olx1 : v.xb;
    olx2 = !j ? olx2 : w.xb;
    STTY = stty;
    stty = diry < 0? oly1 :fcyl;
    boxs_generater (y, TCHS, !i ? inx1 :0, !j ? inx2 :0);
    stty = STTY;
  }
  // COMPUTE NEW XYS FOR LOWER POINTS
  y = pmax (y, oly1);
  olx1 = y != flyl ? compute_cut_x (&flft, y) :olx1;
  olx2 = y != flyl ? compute_cut_x (&frgt, y) :olx2;
  oly1 = oly2 = y;
  // BUILD CORE
  y = pmax (y, pmin (v.ye, w.ye));
  y = pmin (y, fcyl);
  dsx1 = fldx;
  dsx2 = frdx;
  boxs_generater (y, TCHS, inx1, inx2);
  // GENERATE UPPER BOX
  k = 1;
  while (k)
  {
  k = cmub = (v.xe < w.xe) && (y < fcyl);
  ubnd = 0;
  if (cmub)
  {
    i = tmv1 >= fcyl -y;
    j = tmv2 >= fcyl -y;
    cmub = i && j;
    k = ubnd =  !cmub;
    s[0] = y, s[1] = v.xe, s[2] = fcyl, s[3] = w.xe;
  }
  // END GENERATE UPPER BOX
  if (ubnd) // FILL UP IN BAD BOX OCCURENCE
  {
    y = pmin (fcyl, pmax (v.ye, w.ye));
    dsx1 = !i ? fldx : 0;
    dsx2 = !j ? frdx : 0;
    olx1 = !i ? olx1 : v.xe;
    olx2 = !j ? olx2 : w.xe;
    stty = diry < 0? oly1 :fcyl;
    boxs_generater (y, TCHS, !i ? inx1 :0, !j ? inx2 :0);
    i = y < fcyl;
    j = y > flyl;
    k = i && j;
  }
  }
  if (cmub && cmlb)
  {
    if (s[2] == t[2])
    {
      if (s[1] >= t[1] && s[3] <= t[3]) cmub = 0;
    }
  }
  if (cmlb) WRITEBOX (t);
  if (cmub) WRITEBOX (s);
  if (v.yb < fcyl) crnf->lc = 1;
  if (w.yb < fcyl) crnf->rc = 1;
  flyl = fryl = fcyl;
  flxl = V.xe;
  frxl = W.xe;
}

void TERMINATE2(void)
{
long
    t[4];
  t[0] = flyl;
  t[2] = fcyl;
  t[1] = flxl;
  t[3] = frxl;
  WRITEBOX (t);
  flyl = fcyl;
  fryl = fcyl;
}

void TERMINATE()
{
short
    i = flxl == flxm,
    j = frxl == frxm;
  if (i && j)
    TERMINATE2();
  else
    TERMINATE1();
}

struct front *FFPUT
(vector *l, vector *r)
{
struct front *q;
  q = (struct front *)m_alloc (sizeof (struct front));
  if (oldf != NULL) q->n = oldf->n, oldf->n = q;
  else q->n = topf, topf = q;
  q->LFT = *l;
  q->RGT = *r;
  q->lc = 0;
  q->rc = 0;
  return q;
}

void FFREE(void)
{
  if (oldf == NULL) topf = crnf->n;
  else oldf->n = crnf->n;
  free (crnf);
  crnf = oldf == NULL ? topf : oldf->n;
}

short ANALIZE(void) {
  if (bcyl != fcyl) return 0; /* REWIND FRONTS */
  if (crnf == NULL) return bcdr >= 0 ? 1:10; /* IT IS END OF FRONTS */
  if (flym == flyl && frym == fryl)
    return 2; /* THIS FRONT WAS MERELY TERMINATED */
  switch (fcyl == (flyl == flym ? fryl : flyl))
  {
  case FALS:
	 if (flym == flyl) return bcdr > 0 ? 3:30;
	 if (frym == fryl) return bcdr < 0 ? 7:70;
	 if (bcyl < flym && bcyl < frym)
	 {
long ffxl = pmin (flxl, flxm);
long ffxm = pmax (frxl, frxm);
	if (bcxl <= ffxl) return bcdr > 0 ? 4:40;
	if (bcxl >= ffxm) return bcdr < 0 ? 5:50;
ffxl = compute_cut_x (&flft, fcyl);
ffxm = compute_cut_x (&frgt, fcyl);
	if (bcxl <= ffxl) return bcdr > 0 ? 4:40;
	if (bcxl >= ffxm) return bcdr < 0 ? 5:50;
	 }
	 fcyl = pmin (fcyl, pmin (flym, frym));
	 return TERMINATE(), fcyl = bcyl, ANALIZE();
  case TRUE:
	 if (flym == flyl) return bcdr > 0 ? 3:30;
/* THIS IS SPECIAL CASE FOR MERGENING */
	 if (frym == fryl)
	 if (bcxl >= flxl)  return 7;
/* ELSE IT IS A "LEFT" CASE AND SUBMITTED TO SYMPLE PASS */
	 if (bcxl <  flxl) return bcdr > 0 ? 4:40;
	 if (bcxl == flxl) return bcdr < 0 ? 8:    /* THIS ANALIZE IS    */
			  bckd <  flkd  ? 4:    /* TO CATCH           */
			  bcxl == frxl  ? 9:40; /* COINCIDENCES LINES */
	 if (bcxl <  frxl) return bcdr < 0 ? 6:
			  bcxl+1 == frxl ? 91:60;
	 if (bcxl == frxl) return bcdr > 0 ? 9:92;   /* VECTOR IS SUSPICIOUS */
	 if (bcxl-1 == frxl) return bcdr > 0 ? 92:50; /* FOR COINCIDENCE */
	 return 5; }
return 100; }

short  MERGENEXT()
{
short error = 0;
struct front
    *OLDF = oldf,
    *CRNF = crnf;
short endloop = FALS;
  oldf = crnf; crnf = nxtf;
  while (!endloop)
  {
  if(error) break;
  switch (ANALIZE())
  {
    case 60: case 6: case 0: error = 1;
    case 2: FFREE(); break;
    case 70: case 7: error = MERGENEXT(); endloop = TRUE; break;
    case 30: case 3: oldf->RGT = frgt; oldf->rc = crnf->rc;
    FFREE(); endloop = TRUE; break;
    default: endloop = TRUE; break;
  }
  }
  oldf = OLDF;
  crnf = CRNF;
  return error;
}

void QUICKSORT (short sl, short sr)
{
short
    k,
    j,
    w,
    x;
  if (sr-sl < 11)
  {
    while (sl < sr)
    {
    for( j=sr, k=sr; sl<j; j-- )
    if( gt (vectors[chnl[j-1]], vectors[chnl[j]]) )
    {
      x = chnl[j] ;
    do
    {
      chnl[j] = chnl[j-1] ;
      j-- ;
    }
    while( sl <j && gt (vectors[chnl[j-1]], vectors[x]) ) ;
      chnl[j] = x ;
      k = j;
    }
      sl = k+1;
    for( j =sl; j <sr; j++ )
    if( gt (vectors[chnl[j]], vectors[chnl[j+1]]) )
    {
      x = chnl[j] ;
    do
    {
      chnl[j] = chnl[j+1] ;
      j++ ;
    }
    while( j <sr && gt (vectors[x], vectors[chnl[j+1]]) );
      chnl[j] = x;
      k = j;
    }
      sr = k-1;
    }
  }
  else
  {
    x = (sl + sr)/2 ;
    if( gt (vectors[chnl[sl]], vectors[chnl[x]]) ) swab_ (sl, x, w) ;
    if( gt (vectors[chnl[x]], vectors[chnl[sr]]) ) swab_ (sr, x, w) ;
    if( gt (vectors[chnl[sl]], vectors[chnl[x]]) ) swab_ (sl, x, w) ;
    x = chnl [x];
    for( k =sl+1, j =sr-1; k < j ; )
    {
	 while( gt (vectors[x], vectors[chnl[k]]) )
	  k += 1;
      while( gt (vectors[chnl[j]], vectors[x]) )
	  j -= 1;
      if (k < j)
      {
	  swab_( k, j, w ) ;
	  k += 1;
	  j -= 1;
	 }
    }
    if( sl<j ) QUICKSORT ( sl, j ) ;
    if( k<sr ) QUICKSORT ( k, sr ) ;
  }
}

void BUILDBOXES ()
{
short
    i,
    j;
short nloops = 0,
    clearnloops = 0;
short error = 0;
  fcyl = -LONG_MAX;
  crnc = 0;
  while (crnc <= bxsm)
  if(nloops>100)
  {
    error = 1;
    break;
  }
  else
  {
  clearnloops = 1;
  switch (ANALIZE())
  {
  case 2: FFREE();
	  if(crnc==bxsm)
		if(topf==NULL)
			++crnc;
	  break;
  case 8: j = flkd-0.005 >  bckd; if (j) { error = 1; break; }
  case 6:
	 if (!vertical (crnb)) compute_exposure ();
	 else vector_scanner ();
	 crnf = FFPUT ((vector far*)&flft, (vector far*)&crnb);
	 crnf->lc = nxtf->lc;
	 nlym = nlyl;
	 NEXTvector;
	 break;
  case 0:
	 fcyl = bcyl;
	 crnf = topf;
	 oldf = NULL;
	 break;
  case 70: case 7:
	 clearnloops = 0;
	 nloops++;
	 error = MERGENEXT();
	 if(error) break;
	 if (bcdr < 0 && fryl == frym && fcyl == flyl)
		{
		if (!vertical (crnb)) compute_exposure ();
		else vector_scanner ();
		crnf->rc = 0;
		frgt = crnb;
		NEXTvector;
		}
	 break;
  case 3:
	 if (!vertical (crnb)) compute_exposure ();
	 else vector_scanner ();
	 crnf->lc = 0;
	 flft = crnb;
	 NEXTvector;
	 break;
  case 91: frxl = bcxl;
  case 92:
  case 9:
	 j = frkd - bckd >  0.005;
	 if (j)
	 {
	   error = 1;
	   break;
	 }
  case 5: case 50:
	 oldf = crnf;
	 crnf = nxtf;
	 break;
  case 4:
	 if (!vertical (crnb)) compute_exposure ();
	 else vector_scanner ();
	 crnf = FFPUT ((vector far*)&crnb, (vector far*)&zero);
	 NEXTvector;
	 break;
  case 1:
	 fcyl = bcyl;
	 j = !vertical (crnb);
	 i = crnc != bxsm;
	 if (i) {
	 if (j) compute_exposure ();
	 else vector_scanner (); }
	 crnf = FFPUT ((vector far*)&crnb, (vector far*)&zero);
	 NEXTvector;
	 break;
  case 60:
  case 30:
  case 40:
  case 10: error = 1; break;
  }
  if(clearnloops) nloops = 0;
  if(error) break;
  }
  if(error)
  {
    fprintf(EFIL,
    " FATAL! ABNORMAL POLYGON at point %ld %ld; FRACT DATA is NOT VALID\r\n", bcxl, bcyl);
    WARNINGS++;
  }
  while(topf != NULL)
  {
    crnf = topf;
    free (topf);
    topf = crnf->n;
  }
  topf = crnf = oldf = NULL;
}
  double CALCATAN(DELX, DELY)
  double DELX,
	DELY;
  {
  double AN;
    if(DELX==0)
	 AN = DELY>0 ? 90.0 : 270.0;
    else if(DELY==0)
	 AN = DELX>0 ? 0.0 : 180.0;
    else
    {
	 AN = atan(DELY/DELX)*57.29577;
	 if(DELX<0) AN = 180.0+AN;
	 else AN = DELY>0 ? AN : 360.0+AN;
    }
    return AN;
  }
  double CALCANGL(A0, A1)
  double A0, A1;
  {
    A0 = A0-A1;
    if(A0 > 180.0) A0 -= 360.0;
    else if(A0 < -180.0) A0 += 360.0;
    return A0;
  }

short acuteangleclip
(point *p,
 short ClockWise)
{
point
    *a = NULL,
    *b = NULL,
    *c = NULL,
    *z = NULL;
short
    npoint,
    i,
    j,
    k;
long
    x[2],
    y[2],
    x2,
    y2;
double
    a0,
    b0,
    h[2],
    h2,
    nx[2],
    ny[2];
  a = p;
  b = a != NULL ? a->n :NULL;
  c = b != NULL ? b->n :NULL;
  npoint = 0;
  while (c != NULL)
  {
    x[0] = a->x - b->x;
    y[0] = a->y - b->y;
    x[1] = c->x - b->x;
    y[1] = c->y - b->y;
    x2 = a->x - c->x;
    y2 = a->y - c->y;
    i = x[0] == 0 && y[0] == 0;
    if (i) { a->n = c, free (b); }
    if (i) { b = a->n, c = b != NULL ? b->n :NULL; continue; }
    j = x[1] == 0 && y[1] == 0;
    if (j) { a->n = c, free (b); }
    if (j) { b = a->n, c = b != NULL ? b->n :NULL; continue; }
    h[0] = (double)(x[0])*x[0] + (double)(y[0])*y[0];
    h[1] = (double)(x[1])*x[1] + (double)(y[1])*y[1];
    a0 = h[0] + h[1];
    b0 = (double)x2*x2 + (double)y2*y2;
    if (a0 > b0)
    {   // SUSPICUOUS FOR ACUTE ANGLE
	 if (ClockWise != 0)
	 {
	 double  st;
	   st = (double)x[1]*y[0] - (double)x[0]*y[1];
	   st = st < 0.0 ? -1.0 : 1.0;
	   k  = st == ClockWise;
	 }
	 else k = 1;
	 if (k)
	 {   // IS ACUTE ANGLE
	h[0] = sqrt (h[0]);
	h[1] = sqrt (h[1]);
	nx[0] = ((double) x[0]) /h[0];
	ny[0] = ((double) y[0]) /h[0];
	nx[1] = ((double) x[1]) /h[1];
	ny[1] = ((double) y[1]) /h[1];
	i = h[0] > h[1] ? 0 :1;
	j = i == 0 ? 1 :0;
	x[i] = floor (nx[i] * h[j] +0.5);
	y[i] = floor (ny[i] * h[j] +0.5);
	x2 = x[1] - x[0];
	y2 = y[1] - y[0];
	h2 = (double) x2 *x2 + y2 *y2;
	h2 = ((double) TCHF *MinS) /sqrt (h2);
	h2 =h2 < 1.0 ? h2 :1.0;
	j = h2 < 1.0 ? 0 : h[0] > h[1] ? 0 :1;
	i = h2 < 1.0 ? 1 :j;
	z = a;
	for (; j <=i; j++)
	{
	  x[j] = floor (x[j] *h2 +0.5);
	  y[j] = floor (y[j] *h2 +0.5);
	  z->n = (point *)m_alloc (sizeof (point));
	  z = z->n;
	  z->x = b->x +x[j], z->y = b->y +y[j];
	  z->n = c;
	  npoint++;
	}
	free (b);
	npoint--;
	 }
    }
    a = a->n;
    b = a != NULL ? a->n :NULL;
    c = b != NULL ? b->n :NULL;
    npoint++;
  }
  return npoint;
}

void compute_abc
(vector *o,
 vector *p,
 double a[4],
 double b[4],
 double c[4])
{
short
    i;
long
    x[5],
    y[5];
  x[0] = o->xb, y[0] = o->yb;
  x[1] = o->xe, y[1] = o->ye;
  x[2] = p->xe, y[2] = p->ye;
  x[3] = p->xb, y[3] = p->yb;
  x[4] = o->xb, y[4] = o->yb;
  for (i = 0; i < 4; ++i)
  {
    a[i] = y[i] - y[i +1];
    b[i] = x[i +1] - x[i];
    c[i] = (double)(x[i]) *y[i +1] -(double)(y[i]) *x[i +1];
  }
  if (o->sx > 0)
  for (i = 0; i < 4; ++i)
  {
    a[i] *= -1;
    b[i] *= -1;
    c[i] *= -1;
  }
}

short point_in_exposure
(double a[4],
 double b[4],
 double c[4],
 long x,
 long y)
{
short
    n, m,
    i[4];
  for (m = 0; m < 4; ++m) i[m] = (long)(a[m] *x +b[m] *y +c[m]) >= 0;
  n = 1;
  for (m = 0; m < 4; ++m) n &= i[m];
  return n;
}


short point_on_vectors
(long x,
 long y,
 vector *c,
 vector *o,
 vector *p,
 short mask)
{
short
    m =1,
    n =1;
  m &= (mask ? pmin (o->xe, p->xe) :pmin (o->xb, p->xb)) <= x;
  m &= (mask ? pmax (o->xe, p->xe) :pmax (o->xb, p->xb)) >= x;
  m &= (mask ? pmin (o->ye, p->ye) :pmin (o->yb, p->yb)) <= y;
  m &= (mask ? pmax (o->ye, p->ye) :pmax (o->yb, p->yb)) >= y;
  n &= pmin (c->xe, c->xb) <= x;
  n &= pmax (c->xe, c->xb) >= x;
  n &= pmin (c->ye, c->yb) <= y;
  n &= pmax (c->ye, c->yb) >= y;
  return n && m;
}

short compute_cross_xy
(vector *c,
 double a1,
 double b1,
 double c1,
 long *x,
 long *y)
{
double
    a0,
    b0,
    c0,
    ds,
    dx,
    dy;
  a0 = c->yb - c->ye;
  b0 = c->xe - c->xb;
  c0 = (double)(c->xb) *c->ye - (double)(c->yb) *c->xe;
  ds = a0 *b1 - b0 *a1;
  dy = c0 *a1 - a0 *c1;
  dx = b0 *c1 - c0 *b1;
  *x  = ds != 0 ? floor (dx /ds +0.5) :LONG_MAX;
  *y  = ds != 0 ? floor (dy /ds +0.5) :LONG_MAX;
  return ds == 0 ? 0 :1;
}

short cross_xy (vector *v1, vector *v2, long *x, long *y)
{
double dl, a1, b1, c1, a2, b2, c2;
  a1 = v1->yb - v1->ye;
  b1 = v1->xe - v1->xb;
  a2 = v2->yb - v2->ye;
  b2 = v2->xe - v2->xb;
  dl = a1*b2  - b1*a2 ;
  if ( dl == 0 )  return (0);
  c1 = v1->xb * v1->ye - v1->xe * v1->yb;
  c2 = v2->xb * v2->ye - v2->xe * v2->yb;
  *x = floor ((b1*c2 -b2*c1) /dl +0.5);
  *y = floor ((a2*c1 -a1*c2) /dl +0.5);
  return (1);
}

void move_vector
(vector *o,
 vector *p)
{
  p->xb = o->xb + o->zx;
  p->yb = o->yb + o->zy;
  p->xe = o->xe + o->zx;
  p->ye = o->ye + o->zy;
}

void build_per_vector
(vector *o,
 vector *p)
{
  p->xb = o->xb;
  p->yb = o->yb;
  p->xe = o->xb + o->ye - o->yb;
  p->ye = o->yb + o->xb - o->xe;
}

void compute_zx_zy
(vector *o)
{
long
    k,
    x,
    y;
vector
    a, // PARALLEL LINE
    b; // PERPENDICULAR LINE
  o->zx = o->sy *o->dx, o->zy = 0;
  move_vector (o, &a);
  build_per_vector (o, &b);
  cross_xy (&a, &b, &x, &y);
  o->zx = x - o->xb;
  o->zy = y - o->yb;
  k = o->zx *o->zx +o->zy *o->zy;
  if ( k < MinS *MinS)
  {
    if(k<1.0) k = 1.0;
    else
    k = floor (sqrt (k) +0.5);
    o->zx *= floor (((double) MinS) /k +0.5);
    o->zy *= floor (((double) MinS) /k +0.5);
  }
  if (o->zx == 0) o->zx =o->sx;
  if (o->zy == 0) o->zy =o->sy;
}

void define_nearx
(vector *o,
 vector *d,
 vector *p,
 long *z)
{
long
    nearx = *z,
    x,
    y;
double
    a[4],
    b[4],
    c[4];
short
    flagb = 0,
    flage = 0;
  compute_abc (o, p, a, b, c);
  switch (o->sy)
  {
    case  1 :
  x = d->xb, y = d->yb;
  if (point_in_exposure (a, b, c, x, y))
  {
    flagb = 1;
    x = d->xb - compute_cut_x (o, y);
    nearx = o->sx >0 ? min (nearx, x) :max (nearx, x);
  }
  x = d->xe, y = d->ye;
  if (point_in_exposure (a, b, c, x, y))
  {
    flage = 1;
    x = d->xe - compute_cut_x (o, y);
    nearx = o->sx >0 ? min (nearx, x) :max (nearx, x);
  }
  if ( !(flagb && flage) )
  {
    compute_cross_xy (d, a[1], b[1], c[1], &x, &y);
    if (point_on_vectors (x, y, d, o, p, 1)) // 1 IS FROM END POINTS
    {
    x = x - compute_cut_x (o, y);
    nearx = o->sx > 0 ? min (nearx, x) :max (nearx, x);
    }
    compute_cross_xy (d, a[3], b[3], c[3], &x, &y);
    if (point_on_vectors (x, y, d, o, p, 0)) // 0 IS FROM START POINT
    {
    x = x - compute_cut_x (o, y);
    nearx = o->sx > 0 ? min (nearx, x) :max (nearx, x);
    }
  }
  break;
    case -1 :
  x = d->xb, y = d->yb;
  if (point_in_exposure (a, b, c, x, y))
  {
    flagb = 1;
    x = compute_cut_x (o, y) - d->xb;
    nearx = o->sx >0 ? max (nearx, x) :min (nearx, x);
  }
  x = d->xe, y = d->ye;
  if (point_in_exposure (a, b, c, x, y))
  {
    flage = 1;
    x = compute_cut_x (o, y) - d->xe;
    nearx = o->sx >0 ? max (nearx, x) :min (nearx, x);
  }
  if ( !(flagb && flage) )
  {
    compute_cross_xy (d, a[1], b[1], c[1], &x, &y);
    if (point_on_vectors (x, y, d, o, p, 1)) // 1 IS FROM END POINTS
    {
    x = compute_cut_x (o, y) - x;
    nearx = o->sx > 0 ? max (nearx, x) :min (nearx, x);
    }
    compute_cross_xy (d, a[3], b[3], c[3], &x, &y);
    if (point_on_vectors (x, y, d, o, p, 0)) // 0 IS FROM START POINT
    {
    x = compute_cut_x (o, y) - x;
    nearx = o->sx > 0 ? max (nearx, x) :min (nearx, x);
    }
  }
  }
  if (nearx != 0) *z = nearx;
}

void define_border
(vector *v,
 long b[4])
{
 switch ( v->sx )
 {
  case  1 :
    b[1] = min (v->xb, v->xe);
    b[3] = max (v->xb +v->zx, v->xe +v->zx);
    break;
  case -1 :
    b[1] = min (v->xb +v->zx, v->xe +v->zx);
    b[3] = max (v->xb, v->xe);
 }
 b[0] = min (v->yb, v->yb +v->zy);
 b[2] = max (v->ye, v->ye +v->zy);
}

short is_enable_vector
(vector *c,
 vector *o,
 long b[4])
{
  if (c->yb >= b[2]) return 0;
  if (c->ye <= b[0]) return 0;
  if (is_joined (o ,c)) return 0;
  if (c->xb <= b[1] && c->xe <= b[1]) return 0;
  if (c->xb >= b[3] && c->xe >= b[3]) return 0;
  if (c->sx ==o->sx && c->sy ==o->sy) return 0;
  return 1;
}

void compute_nearx
(vector *o,
 vector *c)
{
long
    nearx1,
    nearx2;
vector
    par;
 nearx1 = nearx2 = o->dx;
 move_vector (o, &par);
 define_nearx (o, c, &par, &nearx2);
 if (nearx1 != nearx2)
 {
   o->dx = nearx2;
   compute_zx_zy (o);
 }
}

void vector_scanner (void)
{
long
    i,
    k,
    g[4];
vector
    *o,
    *c;
  if(Max_Strip==0) return;

  o = (vector far*)(vectors +chnl[crnc]);
  k = o->ye + Max_Strip;

  for (i = crnc +1; i < bxsm; i++)
  {
    c = (vector far*)(vectors +chnl[i]);

    if(c->yb>k) break;

    if (horizontal((*c))) continue;
    if (vertical  ((*c))) continue;
    define_border (c, g);
    if (is_enable_vector (o, c, g))
    compute_nearx (c, o);
  }
}

long cross_y (vector *v1, vector *v2)
{
double
    a1,
    b1,
    c1,
    a2,
    b2,
    c2;
long
    y;
 a1 = v1->yb - v1->ye;
 b1 = v1->xe - v1->xb;
 c1 = v1->xb * v1->ye - v1->xe * v1->yb;
 a2 = v2->yb - v2->ye;
 b2 = v2->xe - v2->xb;
 c2 = v2->xb * v2->ye - v2->xe * v2->yb;
 y = floor (((double)(a2*c1 -a1*c2)) /(a1*b2 -b1*a2) +0.5);
 return (y);
}

void PUTintoPAT
(long t[10],
 signed char sx,
 signed char sy)
{
short
    py = 0,
    px = 1,
    k  = 0,
    i  = 0;
long
    hx, hy,
    wx, wy;
long
    brc[5];
  for (i =2, k =0; i < 8; i +=2)
    k = t[i +py] < t[k +py] ? i :
    t[i +py] > t[k +py] ? k :
    t[i +px] < t[k +px] ? i : k;
  while (k != 0)
  {
    t[8 + py] = t[0 +py];
    t[8 + px] = t[0 +px];
  for (i = 2; i < 8; i+=2)
  {
    t[i -2 +py] = t[i +py];
    t[i -2 +px] = t[i +px];
  }
  t[6 +px] = t[8 +px];
  t[6 +py] = t[8 +py];
  k -= 2;
  }
  i = 2, k = 6;
  if (t[0 +px] < t[i +px])
    i = 6, k = 2;
  if (t[0 +px] == t[i +px])  /* ORTOGONAL BOX ?*/
  {
    t[2 +px] = t[k +px];
    t[2 +py] = t[i +py];
    WRITEBOX (t);
  }
  else
  {
    hx = t[0 +px] - t[i +px]; hx=pabs(hx);
    hy = t[i +py] - t[0 +py]; hy=pabs(hy);
    wx = t[k +px] - t[0 +px]; wx=pabs(wx);
    wy = t[k +py] - t[0 +py]; wy=pabs(wy);
    brc[3] = ceil(sqrt(hx*hx + hy*hy));
    if (brc[3] < TCHS) brc[3] = TCHS;
    brc[2] = ceil(sqrt(wx*wx + wy*wy));
    if (brc[2] < TCHS) brc[2] = TCHS;
    brc[0] = sx==1? (hx+wx)/2.0+0.5 : (hx+wx)/2;
    brc[0] += t[i +px];
    brc[1] = sy==1? (wy+hy)/2.0+0.5 : (wy+hy)/2;
    brc[1] += t[0 +py];
    brc[4]  = brc[3] > brc[2] ?
		 (hy != 0 ? atan (((double)hx) /hy) *572.958 +0.5: 899):
		 (wx != 0 ? atan (((double)wy) /wx) *572.958 +0.5: 899);
    if(UN001>1)
	for(i = 0; i<4; ++i)
	brc[i] = floor(brc[i]*STSIZ +0.5);
    fwrite (brc, 4, 4, BFIL);
    i = brc[4];
    fwrite (&i, 2, 1, BFIL);
    NEXPS++;
if(!(NEXPS%256))dontworry();
  }
}

void WRITE_EXPOSURE
(vector *o)
{
long t[10];
  t[0] = o->yb, t[1] = o->xb;
  t[2] = o->ye, t[3] = o->xe;
  t[4] = o->ye +o->zy, t[5] = o->xe +o->zx;
  t[6] = o->yb +o->zy, t[7] = o->xb +o->zx;
  PUTintoPAT (t, o->sx, o->sy);
}

void OUT_EXPOSURE
(vector *o)
{
vector
    og =*o,
    pa,
    pe,
    tm,
    t0,
    t1;
short
    i,
    j;
long
    lv[2],
    lx[2],
    ly[2],
    kv[2],
    dx[2];
 move_vector (&og, &pa);
 pe.xb  =og.xb;
 pe.yb  =og.yb;
 pe.xe  =pa.xb;
 pe.ye  =pa.yb;
 t0.yb =t1.yb =0;
 t0.ye =t1.ye =100;
 lx[0] =og.xb -og.xe;
 ly[0] =og.yb -og.ye;
 lv[0] =floor (sqrt (lx[0] *lx[0] +ly[0] *ly[0]) +0.5);
 if (lv[0] <= MaxS)   WRITE_EXPOSURE (&og);
 else
 {
 kv[0] =ceil  (((double)lv[0]) /MaxS);
 kv[0] =kv[0] ? kv[0] :1;
 dx[0] =lx[0] > 0 ? ceil(((double)lx[0])/kv[0]) :
		    ceil(((double)lx[0])/kv[0]-1);
 lx[1] =og.zx;
 ly[1] =og.zy;
 lv[1] =floor (sqrt (lx[1] *lx[1] +ly[1] *ly[1]) +0.5);
 kv[1] =ceil  (((double)lv[1]) /MaxS);
 kv[1] =kv[1] ? kv[1] :1;
 dx[1] =lx[1] > 0 ? ceil(((double)lx[1])/kv[1]) :
		    ceil(((double)lx[1])/kv[1]-1);
 for (i =1; i <=kv[0]; i++)
 {
  t0.xb =t0.xe =og.xe =og.xb -dx[0];
  switch ( o->sy )
  {
   case  1 :
   if ((o->sx > 0 && t0.xe < o->xe) || (o->sx < 0 && t0.xe > o->xe))
    t0.xb =t0.xe =o->xe;
   break;
   case -1 :
   if ((o->sx > 0 && t0.xe > o->xe) || (o->sx < 0 && t0.xe < o->xe))
    t0.xb =t0.xe =o->xe;
  }
  og.xe =t0.xe;
  og.ye =cross_y(o, &t0);
  tm =og;
  for (j =1; j <=kv[1]; j++)
  {
   t1.xb =t1.xe =og.xb +dx[1];
   if ((o->sx > 0 && t1.xb > pe.xe) || (o->sx < 0 && t1.xb < pe.xe))
   t1.xb =t1.xe =pe.xe;
   og.zx =t1.xb -og.xb;
   og.zy =cross_y (&pe, &t1) -og.yb;
   move_vector (&og, &pa);
   WRITE_EXPOSURE (&og);
   og = pa;
  }
 og = tm;
 og.xb =og.xe;
 og.yb =og.ye;
 pe.xb =og.xb;
 pe.yb =og.yb;
 pe.xe =pa.xe;
 pe.ye =pa.ye;
 }
 }
}

void compute_exposure (void)
{
long
    i,
    k,
    b[4],
    g[4];
vector
    *c,
    *o = (vector far*)(vectors +chnl[crnc]);
  if(Max_Strip==0) return;

  define_border (o, b);
  k = o->ye + Max_Strip;

  for (i = crnc +1; i < bxsm; i++)
  {
    c = (vector far*)(vectors +chnl[i]);

    if(c->yb>k) break;

    if (is_enable_vector (c, o, b)) compute_nearx (o, c);
    if (horizontal((*c))) continue;
    if (vertical  ((*c))) continue;
    define_border (c, g);
    if (is_enable_vector (o, c, g)) compute_nearx (c, o);
  }
  OUT_EXPOSURE (o);
  crnb.dx = pabs (crnb.dx);
  crnb.zx = crnb.zx;
  crnb.zy = crnb.zy;
}

void MAKEVECTORS
(point *ptop,
 point *pold,
 point *pcrn,
 point *z[3])
{
short i, k, t;
long a;
  if (z[2] == NULL) z[2] =ptop;
  if (z[0] == NULL) z[0] =pold;
  {
  double x[2], y[2];
    x[0] = z[1]->x - z[0]->x;
    y[0] = z[1]->y - z[0]->y;
    x[1] = z[1]->x - z[2]->x;
    y[1] = z[1]->y - z[2]->y;
    x[0] = x[1]*y[0] - x[0]*y[1];
    t = x[0] > 0.0 ? +1.0 : -1.0;
  }
  i = pcrn->x != ptop->x;
  k = pcrn->y != ptop->y;
  if (i || k)
  {
    pold = pcrn, pcrn = (point *) m_alloc (sizeof (point));
    pold->n = pcrn;
    pcrn->n = NULL;
    pcrn->x = ptop->x;
    pcrn->y = ptop->y;
  }
  pold = (point *) m_alloc (sizeof (point));

  *pold = *ptop->n;

  pcrn->n = pold;
  pold->n = NULL;

  k = acuteangleclip (ptop, t);

  pold = ptop->n, pcrn = pold->n;
  crnc = 0;

  while (pcrn != NULL)
  {
    vectors[crnc].xb = pold->x;
    vectors[crnc].yb = pold->y;
    vectors[crnc].xe = pcrn->x;
    vectors[crnc].ye = pcrn->y;
    pold = pold->n;
    pcrn = pcrn->n;
    crnc++;
    if(crnc==vectors_lim){
      fprintf(stderr, " OUT OF STORAGE! ATTEMPTING TO ALLOCATE crnc > %ld", vectors_lim);
      zabort (0);
      }
  }
  vectors[crnc -1].xe = vectors[0].xb;
  vectors[crnc -1].ye = vectors[0].yb;

  bxsm = crnc;
  for(i = 0; i<=bxsm; ++i) chnl[i] = i;

  vectors[crnc] = stopvector;
  while (ptop != NULL)
  {
    pcrn = ptop;
    free (ptop);
    ptop = pcrn->n;
  }
  for (crnc = 0; crnc < bxsm; crnc++)
  {
  if (horizontal (vectors[crnc]))
  {
    vectors[crnc].ct = (bcxl > bcxm) ? -MAXFLOAT : MAXFLOAT;
    vectors[crnc].sx = vectors[crnc].sy = 0;
    continue;
  }
  if (vertical (vectors[crnc]))
  {
    vectors[crnc].sy = 0;
    if (bcyl > bcym)
    {
    vectors[crnc].sx = -1*(-t);
    swapf (bcyl, bcym, a);
    }
    else  vectors[crnc].sx = 1*(-t);
    vectors[crnc].ct = 0;
    vectors[crnc].dx = 0;
    vectors[crnc].zy = 0;
    vectors[crnc].zx = 0;
    continue;
  }
  if (bcyl > bcym)
  {
    vectors[crnc].sx = -1*(-t);
    swapf (bcxl, bcxm, a);
    swapf (bcyl, bcym, a);
  }
  else vectors[crnc].sx = 1*(-t);
  vectors[crnc].dx = bcxl - bcxm;
  {
  double S;
  double C;
  double A;
  double B;
  double H;
  A = bcyl - bcym;
  B = bcxl - bcxm;

  C = sqrt(A*A+B*B);
  S = A * B;
  if(S<0) S = -S;

  H = S/C;
  if(H>Max_Dist)
	{
	S = H/Max_Dist;
	vectors[crnc].dx = floor(B/S);
	H = Max_Dist;
	}
  if(Max_Strip<H)Max_Strip = ceil(H);
  }
  vectors[crnc].ct = ((double)vectors[crnc].dx) /(bcyl -bcym);
  }
  QUICKSORT (0, bxsm);
  if (vectors[chnl[0]].sx == -1)
  {
    for (crnc = 0; crnc < bxsm; crnc++)
	 vectors[chnl[crnc]].sx *= -1;
    QUICKSORT(0, bxsm);
  }
  for (crnc = 0; crnc < bxsm; crnc++)
  {
    if (vectors[chnl[crnc]].sx > 0)
      vectors[chnl[crnc]].sy = bcxl <bcxm ? -1 :bcxl >bcxm ? 1 :0;
    else
    if (vectors[chnl[crnc]].sx < 0)
      vectors[chnl[crnc]].sy = bcxl <bcxm ? 1 :bcxl >bcxm ? -1 :0;
    if (horizontal (crnb)) continue;
    if (vertical   (crnb)) continue;
    compute_zx_zy ((vector far*)&crnb);
  }
}

void
clzabort(void)
{
  fprintf (stderr, "NOTE! M-5009 command line:\r\n");
  fprintf (stderr, "layer | [options]\r\n");
  fprintf (stderr, "options:\r\n");
  fprintf (stderr, "Znn (nn - zone for sorting, 20 - by default)\r\n");
  fprintf (stderr, "Snn (nn - number of min. expos. to fit into acute angle\r\n");
  fprintf (stderr, "    ,4 - by default)\r\n");
  fprintf (stderr, "Mnn (nn - magnification, 1 - by default)\r\n");
  fprintf (stderr, "Tnn (nn - min. exposure, 4 - by default)\r\n");
  fprintf (stderr, "Enn (nn - max. exposure, 1500 - by default)\r\n");
  zabort(0);
}

short scanfname
( char *s0
, char *s1
, char *s2 ) {
  while (*s0 != '.' && *s0 != 0) *s1++ = *s0++; *s1 = '\0';
  if (*s0 == '\0') return (0>1);
  else {
    while (*s0 != '\0') *s2++ = *s0++; *s2 = '\0'; }
  return (0<1); }
/**/
/*INTERNAL INPUT-OUTPUT*/
/**/
  #ifdef CHAR
  #undef CHAR
  #endif
  #ifdef SHORT
  #undef SHORT
  #endif
  #define CHAR unsigned char
  #define SHORT unsigned short
  /**/
  typedef struct
  {
  char Id_String[32];

  long Delta_X; /*In Units*/
  long Delta_Y; /*In Units*/
  } FP_Struct;
  typedef struct
  {
  long EMSIZ; /*In PAGES BY 1K*/
  long UN001; /*Units_Per_Micron*/
  long UN003; /*Delta Window In Units*/
  long CXMIN; /*In Units*/
  long CXMAX; /*In Units*/
  long CYMIN; /*In Units*/
  long CYMAX; /*In Units*/
  long XBSIZ; /*In Units*/
  long YBSIZ; /*In Units*/
  long XBCNT;
  long YBCNT;
  long LVCNT;
  long FiLID;
  char FileP[4];
  char Err1P[4];
  char PlotP[4];
  char TempP[4];
  } LZ_Struct;
  /**/
  typedef struct
  {
  long STATUS;

  long CXMIN;
  long CXMAX;
  long CYMIN;
  long CYMAX;

  long XBCNT;
  long YBCNT;
  long XBSIZ;
  long YBSIZ;

  long ER1I;
  long PLTI;
  long BDBI;
  long PDBI;
  } LX_Struct;
  typedef struct
  {
  FILE*Fil;
  char*Buf;
  long Buf_Len;
  long Buf_Pos;
  char Buf_Eof;
  } LF_Struct;
  typedef struct
  {
  long Fragment;

  LX_Struct LX_S;
  LF_Struct File;

  char Name[20];
  char PdbN[20];
  char BdbN[20];
  char Er1N[20];
  char PltN[20];

  long Delta_X;
  long Delta_Y;

  long Lcode;
  long Lmask;

  char Exist;

  FILE*ER1;
  FILE*ER2;
  } FX_Struct;

  LZ_Struct LZ_S;
  LX_Struct LX_S;
  FX_Struct Z_Layer[4], O_Layer;

  FP_Struct FP_S = {"Mascot V2.0 Internal Storage\n", 0, 0};

  long FPOS_1 = sizeof(LZ_S)+sizeof(FP_S);
  long FPOS_2 = sizeof(FP_S);
  long FPOS_3;

  char LZ_S_Changed;

  FILE*LZ_S_FILE;
  FILE*LX_S_FILE;
  char*LZ_S_NAME;
  char*LX_S_NAME;
  /**/
  long S_BPOS;
  long S_BLEN;
  char*S_BTOP;
  /**/
  char
  ZDNEXT(void)
  {
    if(Zd_File_Ptr>=Zd_File_Lim)
    {
    Zd_File_Buf[0] = 0;
    Zd_File_Lim = fread(Zd_File_Buf, 1, Zd_File_Lim, Zd_File);
    Zd_File_Eof = (Zd_File_Lim == 0);
    Zd_File_Ptr = 0;
    }
    return Zd_File_Buf[Zd_File_Ptr++];
  }
  void ZDREAD(char*B, char L)
  {
  register char i;
    if(Zd_File_Ptr+L>=Zd_File_Lim)
    {
    for(i = 0; i<L; ++i)
	B[i] = ZDNEXT();
    return;
    }
    memcpy(B, &Zd_File_Buf[Zd_File_Ptr], L);
    Zd_File_Ptr += L;
  }
  #define Z_LEN(Z) ((Z)&7)
  #define Z_REV(Z) ((Z)&128)
  #define Z_TEN(Z) (((Z)&56)>>3)
  void ZDREAD_X(long*D, char Z)
  {
  ZDREAD((char *)D, (D[0] = (long)Z_LEN(Z)));
  if(Z_REV(Z))D[0] *=-1L;

  for(Z = Z_TEN(Z) ; Z; --Z)D[0] *= 10;
  }
  void
  Ferror(FILE*File, char*Name)
  {
    if(File==NULL)return;

    if(ferror(File))
    {
    fprintf(stderr, "\n\nERROR ON FILE %s\n", Name);
    zabort(0);
    }
  }
  FILE*Fopen(char*Name, char*Mode)
  {
  FILE*File;
  File = fopen(Name, Mode);
  if(File==NULL)
	{
	fprintf(stderr, "\n\nFile %s Open ERROR\n", Name);
	zabort(0);
	}
  return(File);
  }
  char*SS_Fetch(char*Name)
  {
    long i;
    char*n;
    i = strlen(Name)+1;
    if((S_BLEN-S_BPOS)<=i)zabort(0);

    memcpy(&S_BTOP[S_BPOS], Name, i);
    n = &S_BTOP[S_BPOS];
    S_BPOS+= i;

    return(n);
  }
  char ZZ_Hash(char*s)
  {
    char i = 0;
    while(*s) i = (i + (*s++))&63;
    return(i);
  }
  /**/
  typedef struct
  {
  char*N;
  char X;
  } MM_layer;
  MM_layer*MM_Layer;
  /**/
  long MM_Layer_Old;
  long MM_Layer_Lim;
  long MM_Layer_Max;
  /**/
  CHAR MM_Hash[64];
  long MM_Fetch(char*Name)
  {
    long i;
    long I;
    i = ZZ_Hash(Name);

    I = MM_Hash[i];
    while(I)
    {
    if(stricmp(Name, MM_Layer[I].N)==0)break;
    I = MM_Layer[I].X;
    }
    return(I);
  }
  long MM_Insert(char*N)
  {
    long i;
    long I;
    I = MM_Layer_Lim++;
    if(MM_Layer_Lim>=MM_Layer_Max)zabort(0);

    MM_Layer[I].N = N;

    i = ZZ_Hash(N);

    MM_Layer[I].X = MM_Hash[i];
    MM_Hash[i] = I;

    return(I);
  }
  void Make_File_Name(char*Sd, long Id)
  {
  long I;
  static char*Sp = "abcxzjps";

  sprintf(Sd, "%08ld", Id);

  for(I = 0; Sp[I]!=0; ++I)
  {
  if(Sd[I]== 0 )continue;
  if(Sd[I]=='0')Sd[I] = Sp[I];
  if(Sd[I]=='1')Sd[I] = 'e';
  }
  memcpy(Sd, LZ_S.FileP, 3);

  strncat(Sd, ".xzq", 5);
  }
  void
  Find_ILayer(void)
    {
    long I;
    long n;
    long i;

    I = Z_Layers_Cnt;
    for(i = n = 0; i<I; ++i)
    {
    Z_Layer[i].Exist = MM_Fetch(Z_Layer[i].Name);
    if(Z_Layer[i].Exist)++n;
    }
    if(n<I)
	{
	for(i = 0; i<I; ++i)
	if(!Z_Layer[i].Exist)
	fprintf(stderr, "\nLAYER %s is NOT VALID", Z_Layer[i].Name);
	zabort(0);
	}
    for(i = 0; i<I; ++i)
    {
    n = FPOS_2 + (Z_Layer[i].Exist-1)*sizeof(LX_S);

    fsetpos(LX_S_FILE, &n);
    n = fread(&Z_Layer[i].LX_S, sizeof(LX_S), 1, LX_S_FILE);

    if(n!=1)zabort(0);
    }
    }
  void
  INIT_ILayer(FX_Struct*L, long n)
  {
    Make_File_Name(L->PdbN, L->LX_S.PDBI);

    L->File.Fil = Fopen(L->PdbN, "rb");

    fread(&FP_S, sizeof(FP_S), 1, L->File.Fil);

    L->Delta_X = FP_S.Delta_X;
    L->Delta_Y = FP_S.Delta_Y;

    L->File.Buf = malloc(1024);

    L->File.Buf_Len = 1024;
    L->File.Buf_Pos = 1024;

    L->File.Buf_Eof = 0;

    L->Lcode = 1<<(2*n);
    L->Lmask = (L->Lcode<<1)|L->Lcode;

    L->Fragment = 0;
  }
  void
  Initial_Setup_1(void)
  {
    S_BPOS = 1;
    S_BLEN = 4096;
    S_BTOP = calloc(4096, 1);

    S_BLEN-= 20;
    LZ_S_NAME  = &S_BTOP[S_BLEN];
    S_BLEN-= 20;
    LX_S_NAME  = &S_BTOP[S_BLEN];

    memcpy(LZ_S.FileP, "M2$\n", 4);
    memcpy(LZ_S.Err1P, "E1$\n", 4);
    memcpy(LZ_S.PlotP, "PT$\n", 4);
    memcpy(LZ_S.TempP, "TM$\n", 4);

    Make_File_Name(LZ_S_NAME, 0);
    Make_File_Name(LX_S_NAME, 1);

    LZ_S.FiLID = 2;
  }
  void
  Initial_Setup_2(void)
  {
    char*b;
    long i;
    long m;
    long n;

    LZ_S_FILE = Fopen(LZ_S_NAME, "r+b");
    LX_S_FILE = Fopen(LX_S_NAME, "r+b");

    i = fread(&FP_S, sizeof(FP_S), 1, LZ_S_FILE);
    m = fread(&FP_S, sizeof(FP_S), 1, LX_S_FILE);
    n = fread(&LZ_S, sizeof(LZ_S), 1, LZ_S_FILE);
    if(i!=1||m!=1||n!=1)zabort(0);

    UN001 = LZ_S.UN001;
    UN002*= UN001;
    STSIZ = 1.0/(double)UN001;

    CXMIN = LZ_S.CXMIN;
    CXMAX = LZ_S.CXMAX;
    CYMIN = LZ_S.CYMIN;
    CYMAX = LZ_S.CYMAX;

    XBSIZ = LZ_S.XBSIZ;
    YBSIZ = LZ_S.YBSIZ;
    XBCNT = LZ_S.XBCNT;
    YBCNT = LZ_S.YBCNT;

#ifdef __BORLANDC__
    EMSIZ = 0;
#else
    EMSIZ = LZ_S.EMSIZ;
#endif

    LVCNT = ((EMSIZ+300.)/300.)*2000;

    BLCNT = XBCNT*YBCNT;

    MM_Layer = calloc(256, 5);
    MM_Layer_Lim = 1;
    MM_Layer_Max = 256;

    b = &S_BTOP[S_BLEN-200];

    fsetpos(LZ_S_FILE, &FPOS_1);
    b[0] = 1;
    while(!feof(LZ_S_FILE))
    {
    i = 0;
    do
    if(!fread(&b[i], 1, 1, LZ_S_FILE))
    b[i] = 0;
    while(b[i++]);

    if(b[0]==0)break;

    i = MM_Insert(SS_Fetch(b));
    }
    MM_Layer_Old = MM_Layer_Lim;

    fgetpos(LZ_S_FILE, &FPOS_3);

    if(ferror(LZ_S_FILE))
	zabort(0);
#ifdef __BORLANDC__
    n = coreleft();
#else
    n = EMSIZ*1024 + 200000;
#endif
    n = (n/3)<<1;
    m = sizeof(vectors[0]) + sizeof(chnl[0]);
    i = n/m;
    if(i>64000)i = 64000;
#ifdef Huge_Pointer_not_allowed
    n = i*sizeof(vectors[0]);
    if(n>0xFFFFL)i = 0xFFFFL/sizeof(vectors[0]);
#endif
#ifdef __BORLANDC__
    vectors = farmalloc(i*sizeof(vectors[0]));
    chnl = farmalloc(i*sizeof(chnl[0]));
#else
    vectors = malloc(i*sizeof(vectors[0]));
    chnl = malloc(i*sizeof(chnl[0]));
#endif
    if(!vectors||!chnl)
	{
	fprintf(stderr, "\nOUT OF MEMORY\n");
	zabort(0);
	}
#ifdef __ZTC__
    memset(vectors, 0, i*sizeof(vectors[0]));
    memset(chnl, 0, i*sizeof(chnl[0]));
#else
    _fmemset(vectors, 0, i*sizeof(vectors[0]));
    _fmemset(chnl, 0, i*sizeof(chnl[0]));
#endif
    vectors_lim = i;
  }
  void
  Initial_Setup_3(void)
  {
    S_BLEN-= 60;
    rptNAME = &S_BTOP[S_BLEN];
    S_BLEN-= 60;
    inpNAME = &S_BTOP[S_BLEN];
    S_BLEN-= 60;
    patNAME = &S_BTOP[S_BLEN];
    S_BLEN-= 60;
    appNAME = &S_BTOP[S_BLEN];
    S_BLEN-= 60;
    expNAME = &S_BTOP[S_BLEN];
    S_BLEN-= 20;
    strDATE = &S_BTOP[S_BLEN];
    S_BLEN-= 20;
    strTIME = &S_BTOP[S_BLEN];
  }
void CONVERTBINFILE(void)
{
point
    *ptop,
    *pcrn,
    *pold,
    *(z[3]);
long
    yl,
    xl;
short
    t = 0,
    k = 0,
    i = 0,
    j = 0;

    char Z;
    long L;
    long X;
    long Y;

    long D[2];

    ptop = NULL;
    pcrn = NULL;
    pold = NULL;
    Zd_File = Z_Layer[0].File.Fil;

    Zd_File_Buf = Z_Layer[0].File.Buf;

    Zd_File_Ptr = Z_Layer[0].File.Buf_Pos;
    Zd_File_Eof = Z_Layer[0].File.Buf_Eof;
    Zd_File_Lim = Z_Layer[0].File.Buf_Len;

    Zd_Delta_X = Z_Layer[0].Delta_X-CXMIN;
    Zd_Delta_Y = Z_Layer[0].Delta_Y-CYMIN;

    Zd_Fragment = &Z_Layer[0].Fragment;

    Z_Fragment = 0;
    DIX_Fragment = -1;
    while(Zd_Fragment[0]!=LONG_MAX)
    {
    ZDREAD(&Z, 1);
    if(!Z)
	{
	long XB;
	long YB;
	ZDREAD(&Z, 1), L = (Z&(7<<4))>>4;
	if(L)
		{
		fprintf(stderr, "\nABNORMAL INPUT FILE FORMAT");
		zabort(0);
		}
	Zd_Fragment[0] = 0;
	ZDREAD((char*)Zd_Fragment, Z);

	if(Zd_File_Eof)
		{
		Zd_Fragment[0] = LONG_MAX;
		continue;
		}
	Z_Fragment = Zd_Fragment[0];

	Zd_Delta_X = Z_Layer[0].Delta_X-CXMIN;
	Zd_Delta_Y = Z_Layer[0].Delta_Y-CYMIN;

	XB = Z_Fragment/YBCNT;
	Zd_Delta_X -= XB*XBSIZ;

	YB = Z_Fragment - XB*YBCNT;
	Zd_Delta_Y -= YB*YBSIZ;

	continue;
	}
    z[0] = NULL;
    z[1] = NULL;
    z[2] = NULL;

    yl = LONG_MAX;
    xl = LONG_MAX;

    X = Y = 0;
    do
	{
	ZDREAD_X(&D[0], Z);

	ZDREAD(&Z, 1);
	ZDREAD_X(&D[1], Z);

	X += D[0];
	Y += D[1];

	pold = pcrn;

	pcrn = m_alloc (sizeof (struct point));
	pcrn->x = (X-Zd_Delta_X) * MSHT;
	pcrn->y = (Y-Zd_Delta_Y) * MSHT;
	pcrn->n = NULL;
	if(pold != NULL)pold->n = pcrn;
	if(ptop == NULL)ptop = pcrn;

	i =  Y < yl ? 1 :Y > yl ? 0 :X < xl ? 1:0;
	if (i)
		{
		z[0] = pold, z[1] = pcrn;
		xl = X, yl = Y;
		}
	ZDREAD(&Z, 1);
	}
    while(Z);
    i = ptop != NULL;
    k = i ? ptop->n != NULL: i;
    t = k ? ptop->n->n != NULL: k;
    if(i && k && t)
	{
	Max_Strip = 0;
	z[2] = z[1]->n;
	MAKEVECTORS (ptop, pold, pcrn, z);
	ptop = pold = pcrn = NULL;
	BUILDBOXES ();

	NELEMS++;
	NPOLYGONS++;

	dontworry();
	}
    else
    while(ptop != NULL){ free (ptop); ptop = ptop->n; }
    }
}
#ifdef __ZTC__
void
zz_dos_date(char * d, char * t)
{
  struct dos_date_t zdate;
  struct dos_time_t ztime;
  dos_getdate (&zdate);
  sprintf (d, "%ld-%02ld-%02ld", (long)zdate.year,
				 (long)zdate.month,
				 (long)zdate.day);
  dos_gettime (&ztime);
  sprintf (t, "%ld:%02ld", (long)ztime.hour,
			   (long)ztime.minute);
}
#else
void
zz_dos_date(char * d, char * t)
{
  struct date zdate;
  struct time ztime;
  getdate (&zdate);
  sprintf (d, "%ld-%02ld-%02ld", (long)zdate.da_year,
				 (long)zdate.da_mon,
				 (long)zdate.da_day);
  gettime (&ztime);
  sprintf (t, "%ld:%02ld", (long)ztime.ti_hour,
			   (long)ztime.ti_min);
}
#endif
char *
zz_get_errno(void)
{
switch(errno)
	{
	case E2BIG: return "E2BIG";
	case EACCES: return "EACCES";
	case ENOENT: return "ENOENT";
	case ENOMEM: return "ENOMEM";
	}
return "?";
}
void
main(short nlines, char *line[])
{
  char out_is_def = 0,
  zoneSTR[10] = "20",
  emszSTR[20] = "900";

  if (nlines < 2) clzabort();

  Initial_Setup_1();
  Initial_Setup_3();

  strncpy (inpNAME, line[1], 60);

  strncpy(Z_Layer[0].Name, inpNAME, 59);

  if (nlines > 2)
  {
  short i = 1, j = 0;

  char z[20];

  while (++i < nlines)
	{
	if(line[i][0]!='-') j = 1;
	else
	switch (line[i][1])
		{
		case 'M' :
		case 'm' : j = sscanf (line[i]+2, "%ld%s", &MSHT, z);
		break;
		case 'T' :
		case 't' : j = sscanf (line[i]+2, "%ld%s", &TCHS, z);
		break;
		case 'S' :
		case 's' : j = sscanf (line[i]+2, "%ld%s", &TCHF, z);
		break;
		case 'E' :
		case 'e' : j = sscanf (line[i]+2, "%ld%s", &ECHS, z);
		break;
		case 'Z' :
		case 'z' : j = sscanf (line[i]+2, "%ld%s", &ZONE, z);
		strcpy (zoneSTR, line[i]+2);
		break;
		case 'O' :
		case 'o' : strcpy (expNAME, line[i] +2);
		j = out_is_def = 1;
		break;
		default  : j = 0;
		}
	if (j != 1) clzabort ();
	}
  }
  if (TCHS >ECHS)
	{
	Message ("ERROR!MIN FLASH > MAX FLASH");
	zabort (0);
	}
  if ((((ECHS <0 || TCHS <0) || ZONE <0) || TCHF <0) || MSHT <0)
	{
	Message ("ERROR: PARAMETER MUST BE POSITIVE");
	zabort (0);
	}
  if (!out_is_def)
	{
	strncpy (expNAME, inpNAME, 20);
	strncat (expNAME, ".P", 4);
	}
  Initial_Setup_2();

  ECHS = ECHS*UN001;
  TCHS = TCHS*UN001;
  MaxS = ECHS;
  MinS = TCHS;
  Max_Dist = 3000*UN001;

  Z_Layers_Cnt = 1;

  Find_ILayer();
  INIT_ILayer(&Z_Layer[0], 0);

  BFIL = Fopen(expNAME, "wb");

  EFIL = stderr;

  zz_dos_date(strDATE, strTIME);

  fprintf (EFIL, "M-5009 started on LAYER %s on %s at %s\r\n",
	   inpNAME,
	   strDATE,
	   strTIME);
  fprintf (EFIL, "START OF MESSAGES\r\n");

      CONVERTBINFILE ();

#ifdef __BORLANDC__
    farfree(vectors);
    farfree(chnl);
#else
    free(vectors);
    free(chnl);
#endif
  fclose(Z_Layer[0].File.Fil);
  fclose(LZ_S_FILE);
  fclose(LX_S_FILE);

  free(Z_Layer[0].File.Buf);
  free(MM_Layer);
  free(S_BTOP);

  fprintf (EFIL, "\n");
  fprintf (EFIL, "TOTAL-WARNINGS=%ld\r\n", WARNINGS);
  fprintf (EFIL, "TOTAL-ERRORS=%ld\r\n", ZERRORS);
  fprintf (EFIL, "END OF MESSAGES\r\n");

  zz_dos_date(strDATE, strTIME);

  fprintf (EFIL, "INPUT = %s OUTPUT = %s\r\n", inpNAME, expNAME);
  fprintf (EFIL, "FRACTURING PARAMETERS:\r\n");
  fprintf (EFIL, "MIN-FLASH = %ld. MAX-FLASH = %ld\r\n", MinS, MaxS);
  fprintf (EFIL, "SCALE-FACTOR = %ld\r\n", MSHT);
  fprintf (EFIL, "ACUTE-ANLGLE-CLIP-FACTOR = %ld\r\n", TCHF);
  fprintf (EFIL, "FRACTURING STATISTICS:\r\n");
  fprintf (EFIL, "TOTAL FLASHES = %ld\r\n", NEXPS);
  fprintf (EFIL, "M-5009 finished at %s\r\n", strTIME);
  if(EFIL!=stderr)
  fclose (EFIL);

  if(PFIL!=NULL)
  fclose (PFIL);

  if(BFIL!=NULL)
  fclose (BFIL);
  {
  char sortNAME[80];
  long i = 0;

  strncpy (sortNAME, line[0], 60);
  strrchr (sortNAME, '\\')[1] = 0;
  strncat (sortNAME, "M05009.exe", 12);

  sprintf(emszSTR, "%ld", EMSIZ);
  i = execl(sortNAME, sortNAME,
  expNAME, inpNAME, zoneSTR, emszSTR, NULL);

  if (i <0)
  {
  fprintf(stderr, "\nFAILED TO SPAWN SORTING!\nTask = %s, Return Value = %ld", sortNAME, i);
  fprintf(stderr, "\nErrNo was setted to %s", zz_get_errno());
  }
  zabort (0);
  }
}

void
zabort (short err)
{
  if(PFIL)fclose (PFIL);
  if(BFIL)fclose (BFIL), unlink (expNAME);
  if(EFIL&&EFIL!=stderr)fclose (EFIL);

  if(err) Message("EXITING DUE TO ERROR");
  exit(1);
}

void *m_alloc (long size)
{
 void *ptr;
 if ( (ptr = (void *)malloc (size)) == NULL )
	{
	Message (" FAILED TO SET UP MEMORY BLOCK");
	zabort (0);
	}
 return (ptr);
}
