  #define F_EVAL_MODULE
  /**/
  #include<DOS.H>
  #include<MATH.H>
  #include<STDIO.H>
  /**/
  #ifdef __BORLANDC__
  #include<DIR.H>
  #include<ALLOC.H>
  #endif
  /**/
  #include<STDLIB.H>
  #include<CTYPE.H>
  #include<STRING.H>
  /**/
  #ifdef __BORLANDC__
  #include<VALUES.H>
  #endif
  /**/
  #include<LIMITS.H>
  #include<PROCESS.H>
  /**/
  char SH_ROLL;
  long SH_XDIR;
  long SH_YDIR;
  long SH_PMIN;
  long SH_XMIN;
  long SH_XMAX;
  long SH_YMIN;
  long SH_YMAX;
  long HL_XMIN;
  long Hl_Xmin;
  long HL_XMAX;
  long SH_VT, SH_IP, HL_LB;

  double sh_xdir;
  /**/
  char Dxb_Output_Pleas;
  /**/
  #include "F0EVAL.H"
  char zi_cmp(long a, long b, char x)
  {
  if(x<0)return(a<b);
  if(x>0)return(a>b);

  return(a!=b);
  }
  void Initial_Setup_3(void)
  {
#ifndef __BORLANDC__
    long Px;
    long Py;
#endif
    long Sz;
    long Dy;
    long nn;
    char cm;
    Find_ILayer();

    PXMAX = XBSIZ+1;
    PYMAX = YBSIZ+1;
    PXMIN = -1;
    PYMIN = -1;

    if(PXMAX>PYMAX) nn = PXMAX;
    else nn = PYMAX;
    S_Factor = 0;
    S_FACTOR = 0;
    do
    {
    ++S_Factor;
    }
    while(((nn<<S_Factor)>>S_Factor)==nn);
    S_Factor--;
    S_Factor--;
    if(S_Factor<0)S_Factor = 0;
    if(S_Factor>9)S_Factor = 9;

    if(Without_Scale){}
    else
    {
    S_FACTOR = S_Factor;
    S_Factor = 0;
    }
    PXCNT = 64*((double)XBSIZ/YBSIZ);
    PYCNT = 64*((double)YBSIZ/XBSIZ);
#ifndef __BORLANDC__
    Px = ((long)(XBSIZ*STSIZ))>>10;
    if(Px>128L)Px = 128L;

    if(Px>PXCNT)PXCNT = Px;

    Py = ((long)(YBSIZ*STSIZ))>>10;
    if(Py>128L)Py = 128L;

    if(Py>PYCNT)PYCNT = Py;
#endif
    PBLIM = PXCNT*PYCNT;
    ZPBCOR = malloc(PBLIM*2);

    Dy = YBSIZ*STSIZ;

    LF_LIM = 512;
    while((Dy/(LF_LIM>>1))<2)
    LF_LIM>>=1;

    Lf_Sdown = malloc(LF_LIM*1);
    Lf_Rolld = malloc(LF_LIM*2);
    Lf_ROLLD = malloc(LF_LIM*2);
    Lf_First = malloc(LF_LIM*2);

    Lf_Upper = malloc(LF_LIM*2);
    Lf_Lower = malloc(LF_LIM*2);

    Lf_Ymidl = malloc(LF_LIM*4);

    Lf_Stack = malloc(LF_LIM*2);

    Lf_Factor = 1;
    while(LF_LIM>>Lf_Factor)
    ++Lf_Factor;
    --Lf_Factor;

    IPOINT = IPOINT1;
    Determine_Point_Base();

    Z_Fragment = 0;
    DIX_Fragment = -1;
    for(nn = 0; nn<Z_Layers_Cnt; ++nn)
    {
    INIT_ILayer(&Z_Layer[nn], nn);
    }
    for(nn = 0; nn<Z_Layers_Cnt; ++nn)
    {
    if(Z_Layer[nn].LX_S.XBCNT!=XBCNT)
    Z_Layer[nn].Exist = 0;
    else
    if(Z_Layer[nn].LX_S.YBCNT!=YBCNT)
    Z_Layer[nn].Exist = 0;
    }
    cm = BLCNT==1? cm =-1: 0;
    for(nn = 0; nn<Z_Layers_Cnt; ++nn)
    {
    if(zi_cmp(Z_Layer[nn].LX_S.CXMIN, CXMIN, cm))
    Z_Layer[nn].Exist = 0;
    else
    if(zi_cmp(Z_Layer[nn].LX_S.CYMIN, CYMIN, cm))
    Z_Layer[nn].Exist = 0;
    else
    if(zi_cmp(Z_Layer[nn].LX_S.CYMAX, CYMAX,-cm))
    Z_Layer[nn].Exist = 0;
    else
    if(zi_cmp(Z_Layer[nn].LX_S.CXMAX, CXMAX,-cm))
    Z_Layer[nn].Exist = 0;
    }
    cm = 0;
    for(nn = 0; nn<Z_Layers_Cnt; ++nn)
    if(!Z_Layer[nn].Exist)
    cm = 1,
    fprintf(stderr, "\nLayer %s NOT Initialized\n", Z_Layer[nn].Name);

    if(cm)zabort();

    INIT_OLayer(&O_Layer);

#ifdef __BORLANDC__
    Sz = coreleft() -20000;
#else
    Sz = LZ_S.EMSIZ*1024 + 300000L;
#endif

    Sz /= Z_LD_Sz + Z_LB_Sz + Z_LV_Sz + Z_VT_Sz + Z_PT_Sz + Z_JS_Sz;

    ZLDALLOC((long)(Sz*Z_LD_Wt));
    ZLBALLOC((long)(Sz*Z_LB_Wt));
    ZLVALLOC((long)(Sz*Z_LV_Wt));
    ZVTALLOC((long)(Sz*Z_VT_Wt));
    ZPTALLOC((long)(Sz*Z_PT_Wt));
    ZJSALLOC((long)(Sz*Z_JS_Wt));

    return;
  }
  #define Isalpha(S) (isalpha((S))||(S)=='$')
  /**/
  char*FUNAME[6]={"OVR", "ANDNOT", "AND", "XOR", "OR", "NOT"};
  /**/
  #ifndef __BORLANDC__
  #define stricmp strcmpl
  #endif
  /**/
  void Com_Line_Scan(short N, char*A[])
  {
  long I, M, ERR, F, D, O, Q, NF = 6;
  long J, K, L;
  char S[100];
    Z_Full_Scan = 1;

    Without_Scale = 1;

    ERR = F = O = L = Q = D = 0;
    for(I = 1; I<N; ++I)
    {
    for(K = 0; A[I][K]; ++K)
    if(islower(A[I][K])) A[I][K] = toupper(A[I][K]);

    M = A[I][1];

    if(A[I][0]=='-') /*OPTIONAL-PARAMETER*/
    {
    switch(M)
    {
    case 'D': /*OUTPUT TO DXB*/
    K = strlen(A[I]+2)+2;
    if(K>2)
    {
    for(J = 2; A[I][J]; ++J)
    if(!isdigit(A[I][J])&&!Isalpha(A[I][J]))break;
    if(A[I][J]){ ERR = 1; break; }

    ZALLOCATE((void**)&ERRNAM,  K+4);
    strncpy(ERRNAM, A[I]+2, K);
    strncat(ERRNAM, ".DXB", 5);
    }
    if(D) ERR = 2;
    D = 1;
    break;

    case 'F': /*FUNCTION*/
    strncpy(S, A[I]+2, 100);
    for(K = 0; K<NF; ++K)
    if(stricmp(FUNAME[K], S)==0)break;

    if(K==NF){ ERR = 1; break; }

    Target_Function = K;
    if(F) ERR = 2;
    F = 1;
    break;

    case 'O': /*OUTPUT*/
    K = strlen(A[I]+2);
    if(!K||K>=20){ ERR = 1; break; }

    for(J = 2; A[I][J]; ++J)
    if(!isdigit(A[I][J])&&!isalpha(A[I][J]))break;

    if(A[I][J]){ ERR = 1; break; }

    strncpy(O_Layer.Name, A[I]+2, 20);
    if(O) ERR = 2;
    O = 1;
    break;

    case 'S': /*SCALE*/
    if(A[I][2]){ ERR = 1; break; }
    Without_Scale = 0;
    break;
    case 'B': /*FRAGMENT*/
    if(!A[I][2]){ ERR = 1; break; }

    J = sscanf(A[I]+2, "%ld%s", &Z_User_Block, S);

    if(Z_User_Block<0){ ERR = 1; break; }
    if(J!=1){ ERR = 1; break; }
    if(Q) ERR = 2;
    Z_Full_Scan = 0;
    Q = 1;
    break;

    default: ERR = 1;
    }
    if(ERR) break;
    }
    /*End Switch*/

    else
    /*Layer Name*/
    {
    K = strlen(A[I]);
    if(!K||K>=20){ ERR = 1; break; }

    for(J = 0; J<K; ++J)
    if(!isdigit(A[I][J])&&!Isalpha(A[I][J]))break;
    if(J<K){ ERR = 1; break; }

    if(++L>4)
    {
    Print_Note_Message();
    fprintf(stderr, "\nLayers Count ERROR");
    Print_Note_Message();
    zabort();
    }
    Z_Layers_Cnt = L;
    strncpy(Z_Layer[L-1].Name, A[I], 20);
    }
    /*End Layer*/
    }
    /*End Parse*/
    if(ERR)
    Print_Note_Message();
    if(ERR==2)
    fprintf(stderr, "\nAmbiguous Parameter %s", A[I]);
    if(ERR==1)
    fprintf(stderr, "\nStrange Parameter %s", A[I]);
    if(ERR)
    {
    Print_Note_Message();
    zabort();
    }
    if(L==0)exit(1);

    Dxb_Output_Pleas = D;

    if(O==0)
    strncpy(O_Layer.Name, Z_Layer[0].Name, 20);

    if(L>=2&&Target_Function==ZZZNOTJ)
    {
    Print_Note_Message();
    fprintf(stderr, "\nNOT is Unary Operation");
    Print_Note_Message();
    zabort();
    }
    if(L==1&&Target_Function==ZZZANDJ)
    Target_Function = -1;
    if(L==1&&Target_Function==ZZZXORJ)
    Target_Function = -2;
    if(L==1&&Target_Function==ZANDNOT)
    Target_Function = ZZZNOTJ;

    return;
  }
  long dispstrclear()
  {
  long I;
    fprintf(stderr, "\r");
    for(I=0; I<79; ++I) fprintf(stderr, " ");
    return(fprintf(stderr, "\r"));
  }
  /*DXB-FORMAT-SECTION*/
  void write_header(FILE*DXB)
  {
  char header[40];
    strncpy(header, "AutoCAD DXB 1.0\r\n\x1a", 40);
     fwrite(header, strlen(header)+1, 1, DXB);
    return;
  }
  void set_double(FILE*DXB)
  {
  unsigned char id;
  short mode;
    id = 135; /*ITEM-IS-NUMBER-MODE*/
    mode = 1; /*DOUBLE-MODE-FOLLOWS*/
    fwrite((char*)&id, 1, 1, DXB);
    fwrite((char*)&mode, 2, 1, DXB);
  }
  void write_pline
  (FILE*DXB, short closure)
  {
  struct
  {
    unsigned char id;
    short closure;
  } pline;
    pline.id = 19;
    pline.closure = closure;
    fwrite((char*)&pline, 3, 1, DXB);
  }
  void write_layer
  (FILE*DXB, char*layer)
  {
  unsigned char id;
    id = 129;
    fwrite((char*)&id, 1, 1, DXB);
    fwrite(layer, strlen(layer)+1, 1, DXB);
  }
  void write_vertex
  (FILE*DXB, long x, long y)
  {
  struct
  {
    unsigned char id;
    double dx, dy;
  } vertex;
    vertex.id = 20;
    vertex.dx = ((double)x * STSIZ) /1000.0;
    vertex.dy = ((double)y * STSIZ) /1000.0;
    fwrite((char*)&vertex, 17, 1, DXB);
  }
  void write_seqend
  (FILE*DXB)
  {
  unsigned char id;
    id = 17;
    fwrite((char*)&id, 1, 1, DXB);
  }
  void
  Dxb_Ld_Image_Maker
  (char closure, char*s)
  {
  static char*N;
  long L;
  long X;
  long Y;
  long x;
  long y;
  unsigned char id;
    if(ZLDLIM==0)
    {
      id = 0;
      if(ERRFIL) fwrite((char*)&id, 1, 1, ERRFIL), fclose(ERRFIL);
      return;
    }
    if(ZLDLIM<=1) return;
    if(!ERRFIL)
    {
      if(!strlen(ERRNAM))
      ERRNAM = "F-Eerr.dxb";
      if((ERRFIL=fopen(ERRNAM, "wb"))==NULL)zabort();
      write_header(ERRFIL);
      set_double(ERRFIL);
      N = s;
      if(s) write_layer(ERRFIL, s);
    }
    if((N!=s)&&s)
    {
    write_layer(ERRFIL, s);
    N = s;
    }
    write_pline(ERRFIL, (short)closure);

    X = Z_Fragment/YBCNT;
    Y = Z_Fragment - X*YBCNT;

    x = CXMIN + X*XBSIZ;
    y = CYMIN + Y*YBSIZ;
    for(L = 0; L<ZLDLIM; ++L)
    {
    write_vertex(ERRFIL, x+ZLDCO0[L], y+ZLDCO1[L]);
    }
    write_seqend(ERRFIL);
  }
  void
  Dxb_Lb_Image_Maker(long Lb, char*Layer)
  {
  long Le;
  long Lv;
  long Ld;
    Le = ZLBCO3[Lb];
    if(Le==0)return;

    Lv = Le;
    ZLDLIM = 0;
    do
    {
    Ld = ZLDNEXT();
    ZLDCO0[Ld] = ZPTCO1[ZLVCO5[Lv]];
    ZLDCO1[Ld] = ZPTCO2[ZLVCO5[Lv]];

    Lv = ZLVCO1[Lv];
    }
    while(Le!=Lv&&Lv!=0);

    Dxb_Ld_Image_Maker(1, Layer);
  }
  void Load_Boundary(void)
  {
    long DX;
    long DY;
    long XB;
    long YB;
    Target_Function = ZZZNOTJ;

    XB = Z_Fragment/YBCNT;
    if((XB+1)==XBCNT)
    {
    DX = XBSIZ*XBCNT-(CXMAX - CXMIN);
    if(DX<0)zabort();
    DX = XBSIZ-DX;
    }
    else DX = XBSIZ;

    YB = Z_Fragment - XB*YBCNT;
    if((YB+1)==YBCNT)
    {
    DY = YBSIZ*YBCNT-(CYMAX - CYMIN);
    if(DY<0)zabort();
    DY = YBSIZ-DY;
    }
    else DY = YBSIZ;

    ZLDCO0[0] = ZLDCO0[1] = 0L;
    ZLDCO0[2] = ZLDCO0[3] = DX;

    ZLDCO1[0] = ZLDCO1[3] = 0L;
    ZLDCO1[1] = ZLDCO1[2] = DY;

    ZLDCO0[4] = ZLDCO0[0];
    ZLDCO1[4] = ZLDCO1[0];

    C_Layer = 4;

    STATUS = 1;
    ZLDLIM = 5;

    Z_FEval_Storage();
  }
  long MAKE_MASK(long S)
  {
  long I;
    for(I = 0; I<Z_Layers_Cnt; ++I)
    {
    if(S&LYMASK[I]) S |= LYCODE[I]<<1;
    if(S&LYCODE[I]) S ^= LYCODE[I];
    }
    return(S);
  }
  void Find_Ix_Intsect(SHORT Lf)
  {
  long XO, XM, YM;
  long V3, X3, X4, Y3, Y4, YMIN, YMAX;
  long XI, VT, IP, P3, P4;
  long LE, LV, LB, FB, fb;

  double xo;
  double xi;

    FB = Lf_First[Lf];
    if(!FB)return;

    XO = SH_XDIR;
    xo = sh_xdir;
    XM = SH_XMIN<<S_Factor, YM = SH_YDIR<<S_Factor;

    VT = SH_VT, IP = SH_IP;

    for(LB = FB; LB; FB = fb, LB = ZLbNxt[LB])
    {
    /*Loop For Each Lb*/
    fb = LB;

    if(!ZLBCO3[LB])
    {
    if(FB==LB)
    Lf_First[Lf] = fb = ZLbNxt[LB];

    else ZLbNxt[FB] = ZLbNxt[LB], fb = FB;
    continue;
    }
    P3 = ZLbXx1[LB];
    P4 = ZLbXx2[LB];

    X3 = ZPTCO1[P3];
    if(X3>=SH_XMIN||LB==HL_LB)
    {
    SH_VT = VT;
    SH_IP = IP;
    return;
    }
    X4 = ZPTCO1[P4];
    if(X4<Hl_Xmin)
    {
    Lf_First[Lf] = fb = ZLbNxt[LB];
    continue;
    }
    if(X4<SH_XMIN)
    {
    if(!(ZLBCO7[LB]&2))
    {
    if(FB==LB)
    Lf_First[Lf] = fb = ZLbNxt[LB];

    else ZLbNxt[FB] = ZLbNxt[LB], fb = FB;
    continue;
    }
    if((X4 << S_Factor)<=SH_XDIR)
    continue;
    }
    P3 = ZLbYy1[LB];
    P4 = ZLbYy2[LB];

    Y3 = ZPTCO2[P3];
    Y4 = ZPTCO2[P4];
    if(Y3>SH_YDIR||Y4<SH_YDIR)continue;

    LE = LV = ZLBCO3[LB];
    do
    {
    V3 = ZLVCO2[LV];
    if(zznoeven(V3)) V3 = ZVTCO6[V3];

    P3 = ZVTCO1[V3];
    P4 = ZVTCO2[V3];

    Y3 = ZPTCO2[P3]<<S_Factor;
    Y4 = ZPTCO2[P4]<<S_Factor;

    YMIN = Y3>Y4? (YMAX=Y3, Y4): (YMAX=Y4, Y3);
    if(YMIN>YM||YMAX<YM)continue;

    X3 = ZPTCO1[P3]<<S_Factor;
    X4 = ZPTCO1[P4]<<S_Factor;
    if(X4<XO||X3>XM)continue;

    if(YMIN==YMAX) XO = X4, VT = 0, IP = P4;
    else if(Y3==YM&&X3>=XO) VT = 0, xo = XO = X3, IP = P3;
    else if(Y4==YM&&X4>=XO) VT = 0, xo = XO = X4, IP = P4;
    else if(X3==X4) VT = V3, xo = XO = X3, IP = 0;
    else
    {
    xi = ((double)(YM-Y3)*(X4-X3))/(Y4-Y3)+X3;
    XI = floor(xi+0.5);
    if(xo<xi&&XM>XI) VT = V3, XO = (xo = xi), IP = 0;
    }
    if(XO>=XM)
    {
    SH_ROLL = 1;
    return;
    }
    }
    while((LV = ZLVCO1[LV])!=LE);

    SH_XDIR = XO;
    sh_xdir = xo;
    }
    /*End Loop*/
    SH_VT = VT;
    SH_IP = IP;
  }
  void IntSect_Ju(SHORT Lf)
  {
  register SHORT Lf_Nxt;

    Find_Ix_Intsect(Lf);
    if(SH_ROLL)return;

    if(SH_YDIR<Lf_Ymidl[Lf])
    {
    Lf_Nxt = Lf_Lower[Lf];
    if(Lf_Nxt)
    IntSect_Ju(Lf_Nxt);
    }
    if(SH_ROLL)return;

    if(SH_YDIR>Lf_Ymidl[Lf])
    {
    Lf_Nxt = Lf_Upper[Lf];
    if(Lf_Nxt)
    IntSect_Ju(Lf_Nxt);
    }
    return;
  }
  void IX_SET_VALUES(long P)
  {
    SH_PMIN = ZLbXx2[P];
    SH_XMAX = ZPTCO1[SH_PMIN];

    SH_PMIN = ZLbXx1[P];

    SH_IP = SH_VT = 0;

    SH_XMIN = ZPTCO1[SH_PMIN];
    SH_XDIR = 0;
    sh_xdir = 0;
    SH_YDIR = ZPTCO2[SH_PMIN];

    HL_LB = P; SH_ROLL = 0;

    if(SH_XMIN>HL_XMAX) HL_XMIN = SH_XMIN;
    if(SH_XMAX>HL_XMAX) HL_XMAX = SH_XMAX;

    Hl_Xmin = HL_XMIN;
  }
  long Class_IX_Status(long LB)
  {
  long P1, P2, V3, V5, IN;

    IntSect_Ju(0);
    if(SH_ROLL) return(0);

    if(SH_VT)
    {
    P1 = ZVTCO1[SH_VT];
    P2 = ZVTCO2[SH_VT];

    if(ZPTCO2[P1]<ZPTCO2[P2]) V3 = SH_VT;
    else V3 = ZVTCO6[SH_VT];
    }
    else V3 = SH_IP? ZPTCO3[SH_IP]: 0;

    if(!V3||!ZVTCO4[V3]) return(0);

    SI_IX_FL = +1;
    IN = MAKE_MASK(ZVTCO4[V3]);

    V5 = ZVTCO6[V3];

    SI_LB = 0;

    SI_V1 = ZVTCO5[V3];
    SI_V2 = ZVTCO5[V5];

    SET_BIT_2(SI_V1);
    SET_BIT_2(SI_V2);

    if(Z_JFlag)
    {
    SH_XDIR = floor((double)SH_XDIR/(1L<<S_Factor) +0.5);
    if(SH_VT)
    {
    V5 = SPLITVT(V3, (SH_IP=IPOINT(SH_XDIR, SH_YDIR)));

    V5 = (V5>>1)<<1;
    POINT_VECTOR_ANALYSIS(V5);
    }
    V3 = INSERTV(SH_IP, SH_PMIN, 0);

    ZVTCO4[V3] = IN;
    ZVTCO4[ZVTCO6[V3]] = IN;

    POINT_VECTOR_ANALYSIS(V3);
    }
    V3 = ZVTCO6[ZLVCO2[ZLBCO3[LB]]];
    SI_LB = ZLBMAX;
    SI_V1 = SI_V2 = V3;
    SI_ST = IN;

    SET_INSIDE_ALL();

    SI_IX_FL = 0;
    return(IN);
  }
  #define Z_Stat(VT,Vt) (ZVTCO8[(Vt)]>0||(ZVTCO8[(Vt)]<0&&ZVTCO8[(VT)]>0))
  void
  Z_P_ROLLB(long Lb_Lim)
  {
    long LB;
    long LE;
    long LV;
    long VT;
    for(LB = Lb_Lim; LB<ZLBLIM; ++LB)
    {
    if(ZLBCO3[LB]==0)continue;
    LE = ZLBCO3[LB];
    LV = LE;
    do
    {
    REMOVE_FROM_VT_CHAIN(LV);
    VT = ZLVCO2[LV];
    ZVTCO8[VT] = 0L;

    LV = ZLVCO1[LV];
    }
    while(LV&&LV!=LE);
    }
    Roll_Back_Intsect = 1;
  }
  void
  Z_P_Check(void)
  {
    long Lb_Lim;
    long Lv_Lim;
    long LV_Lim;

    char St;
    long Lb;
    long LB;
    long Lv;
    long LV;
    long Le;
    long LE;
    long VT;
    long Vt;
    long V3;
    long LS;
    long Ls;
    for(Lb = 1; Lb<ZLBLIM; ++Lb)
    {
    DUMMYJUNCTIONANALYSIS(Lb);
    if(ZLBCO3[Lb]==0)continue;
    DETERMINE_STAT_2(Lb);

    if(STATUS==1)continue;

    Lb_Lim = ZLBLIM;
    LV_Lim = ZLVLIM;

    Le = ZLBCO3[Lb];
    Lv = Le;
    do
    {
      Vt = ZLVCO2[Lv];
      VT = ZVTCO6[Vt];
      if(Z_Stat(VT,Vt))
      {
      do
      {
      Lv = ZLVCO1[Lv];
      Vt = ZLVCO2[Lv];
      VT = ZVTCO6[Vt];
      }
      while(Z_Stat(VT,Vt)&&Lv!=Le);
      if(Lv==Le)break;
      }
      if(ZVTCO8[VT]<0&&ZVTCO8[Vt]<0)
      {
      Z_P_ROLLB(Lb_Lim);

      ZLBLIM = Lb_Lim;
      ZLVLIM = LV_Lim;
      return;
      }
      if(ZVTCO8[Vt]==-1)V3 = VT, Vt = VT;
      else V3 = Vt;

      LB = ZLBNEXT();

      ZLBCO4[LB] = ZLBCO4[Lb];
      ZLbXx1[LB] = ZLbXx1[Lb];
      ZLbXx2[LB] = ZLbXx2[Lb];
      ZLbYy1[LB] = ZLbYy1[Lb];
      ZLbYy2[LB] = ZLbYy2[Lb];

      Lv_Lim = LE = ZLVLIM;
      ZLBCO3[LB] = LE;
      do
      {
      LV = ZLVNEXT();
      ZLVCO8[LV] = 0;
      ZLVCO1[LV] = 0;
      ZVTCO8[V3] = 1;
      ZLVCO3[LV] = ZVTCO5[V3];
      ZLVCO2[LV] = V3;
      ZLVCO7[LV] = LB;
      ZLVCO5[LV] = ZVTCO1[V3];
      ZLVCO6[LV] = ZVTCO2[V3];
      ZLVCO1[LE] = ZVTCO5[V3] = LV;
      LE = LV;
      V3 = ZVTCO6[V3];
      do
      {
      V3 = FETCHSUCCESSOR(V3);
      VT = ZVTCO6[V3];

      LS = FETCHITSELF(Lb, VT);
      Ls = FETCHITSELF(Lb, V3);
      }
      while(!Ls&&!LS);
      if(Vt!=V3&&ZVTCO8[V3]!=0)
      {
      Z_P_ROLLB(Lb_Lim);

      ZLBLIM = Lb_Lim;
      ZLVLIM = LV_Lim;
      return;
      }
      }
      while(Vt!=V3);
      LE = ZLVCO1[LV] = ZLBCO3[LB];

      DETERMINE_STAT_2(LB);

      if(STATUS!=1)
      {
      ZLBLIM -= 1;
      LV = LE;
      ZLVLIM = Lv_Lim;
      do
      {
      REMOVE_FROM_VT_CHAIN(LV);
      VT = ZLVCO2[LV];
      ZVTCO8[VT] = -1;

      LV = ZLVCO1[LV];
      }
      while(LV!=LE);
      St = 1;
      }
      else
      St = 0,
      Lv = ZLVCO1[Lv];
    }
    while(St||Lv!=Le);

    if(Lb_Lim==ZLBLIM)
    {
    Roll_Back_Intsect = 1;
    return;
    }
    ZLBCO3[Lb] = 0;
    Lv = Le;
    do
    {
    REMOVE_FROM_VT_CHAIN(Lv);
    Vt = ZLVCO2[Lv];
    VT = ZVTCO6[Vt];

    ZVTCO8[Vt] = 0;
    ZVTCO8[VT] = 0;
    ZLVCO7[Lv] = 0;

    Lv = ZLVCO1[Lv];
    }
    while(Lv!=Le);
    }
  }
  #undef Z_Stat
  void
  Scale_Points(void)
  {
    register long p;
    for(p = 1; p<ZPTLIM; ++p)
    {
    ZPTCO1[p] <<= S_FACTOR;
    ZPTCO2[p] <<= S_FACTOR;
    }
    XPDIV <<= S_FACTOR;
    YPDIV <<= S_FACTOR;
    PXMAX <<= S_FACTOR;
    PYMAX <<= S_FACTOR;
    PXMIN <<= S_FACTOR;
    PYMIN <<= S_FACTOR;
  }
  void PRINT_START(void)
  {
  fprintf(stderr, "\nF-EVAL STARTED..");
  Print_Note_Message();
  }
  void PRINT_FINISH(void)
  {
  fprintf(stderr, "F-EVAL FINISHED\n");
  }
  void F_Evaluater(void)
  {
  long n;
  long J;
  long N;
  long L;
  long M;
  long S;
  long I;
    ZLBLIM = 1;
    ZLVLIM = 1;
    ZPTLIM = 1;
    ZYPLIM = 1;
    ZVTLIM = 2;
    STATUS =+1;
    fprintf(stderr, "\rFRAGMENT%ld!", Z_Fragment);

    if(Z_Full_Scan)
    fprintf(stderr, "Load..");
    for(n = 0; n<Z_Layers_Cnt; ++n)
    {
    C_Layer = Z_Layer[n].Lcode;

    if(Z_Layer[n].Fragment>Z_Fragment)continue;

    Zd_File = Z_Layer[n].File.Fil;

    Zd_File_Buf = Z_Layer[n].File.Buf;
    Zd_File_Ptr = Z_Layer[n].File.Buf_Pos;
    Zd_File_Eof = Z_Layer[n].File.Buf_Eof;
    Zd_File_Lim = Z_Layer[n].File.Buf_Len;

    Zd_Delta_X = Z_Layer[n].Delta_X;
    Zd_Delta_Y = Z_Layer[n].Delta_Y;

    Zd_Fragment = &Z_Layer[n].Fragment;

    while(Z_Layer[n].Fragment==Z_Fragment)
    {
    Z_Read_Polygon();
    if(ZLDLIM==0)continue;

    if(!Z_Full_Scan&&(Z_Fragment!=Z_User_Block))
    continue;

    Z_Check_Closure();
    Z_FEval_Storage();
    }
    Z_Layer[n].File.Buf_Pos = Zd_File_Ptr;
    Z_Layer[n].File.Buf_Eof = Zd_File_Eof;
    Z_Layer[n].File.Buf_Len = Zd_File_Lim;

    if(ferror(Z_Layer[n].File.Fil))
    {
    Print_Note_Message();
    fprintf(stderr, "\nFile %s Read ERROR", Z_Layer[n].PdbN);
    Print_Note_Message();
    zabort();
    }
    }
    if(!Z_Full_Scan&&(Z_Fragment!=Z_User_Block))
    return;
    if(Target_Function==ZZZNOTJ)
    {
    Load_Boundary();
    }
    fprintf(stderr, "Ok!");
    Zptlim_After_Loadmaster = ZPTLIM;
    if(Without_Scale){}
    else
    Scale_Points();
    do
    {
    Roll_Back_Intsect = 0;

    ZVTLIM = 2;
    STATUS =+1;
    INTERSECTION_ANALYSIS();
    POINT_VECTOR_ANALYSIS(2);

    fprintf(stderr, "PASS..");
    Z_P_Check();
    if(Roll_Back_Intsect)
    {
    fprintf(stderr, "ROLL_BACK!");
    fprintf(stderr, "\nFRAGMENT%ld!", Z_Fragment);
    for(I = 1; I<ZPTLIM; ++I)
    ZPTCO3[I] = 0;
    }
    }
    while(Roll_Back_Intsect);

    /*Classification*/

    fprintf(stderr, "PASS..");
    for(n = 1; n<ZLBLIM; ++n)
    {
    ZLBCO6[n] = n;
    }
    if(ZLBLIM>1)
    QLb_Sort(1, ZLBLIM-1);

    if(Target_Function==ZZZANDJ) J = 0;
    else
    if(Target_Function==ZZZAND1) J = 0;
    else J = 1;

    Z_JFlag = J;

    HL_XMIN = 0;
    HL_XMAX = 0;

    Init_Vt_Hash_Tree();

    /*Insert Lbs to Hash*/
    for(N = ZLBLIM-1; N; --N)
    {
    I = ZLBCO6[N];

    L = ZLbYy1[I];
    Lb_Ymin = ZPTCO2[L];

    L = ZLbYy2[I];
    Lb_Ymax = ZPTCO2[L];

    S = 0;
    while(1)
    {
    if(!Lf_Upper[S]){}
    else
    if(Lb_Ymin>Lf_Ymidl[S])
    {
    S = Lf_Upper[S];
    continue;
    }
    else
    if(Lb_Ymax<Lf_Ymidl[S])
    {
    S = Lf_Lower[S];
    continue;
    }
    ZLbNxt[I] = Lf_First[S];
    Lf_First[S] = I;
    break;
    }
    }
    /*End For Each Lb*/

    for(N = 1; N<ZLBLIM; ++N)
    {
    I = 0;
    S = ZLBCO6[N];

    if(!ZLBCO3[S])
    {
    continue;
    }
    IX_SET_VALUES(S);

    M = (L = ZLBCO4[S])<<1;

    if(!ZLBCO7[S])
    I = Class_IX_Status(S);

    if(!(I &= L|M))
    POINT_VECTOR_CLASS(S, L, M);
    else
    if(Target_Function==ZZZAND1)
    ZZ_SET_RSTAT(S);
    }
    fprintf(stderr, "PASS..");
    n = Target_Function;

    if(n==OVRELIM)n = ZZZZORJ;

    /*Output Generator*/

    if(n<0)
    True_Stat = n==-1? AND_1:XOR_1;
    else
    True_Stat = Cmp_Modules[n];
    FORCE_C_POLYGONS();

    if(Without_Scale){}
    else
    {
    for(I = 1; I<ZLBLIM; ++I)
    {
    if(!ZLBCO3[I])continue;

    DUMMYJUNCTIONANALYSIS(I);
    }
    Back_Scale_0();

    ZVTLIM = 2;
    STATUS =+1;

    INTERSECTION_ANALYSIS();
    POINT_VECTOR_ANALYSIS(2);

    Roll_Back_Intsect = 0;
    Z_P_Check();
    if(Roll_Back_Intsect)
    {
    fprintf(stderr, "\nGRAPHICS DATA TOO COMPLEX");
    zabort();
    }
    for(I = 1; I<ZLBLIM; ++I)
    ZZ_SET_RSTAT(I);

    True_Stat = O_R;
    FORCE_C_POLYGONS();
    }
    for(I = 1; I<ZLBLIM; ++I)
    {
    if(!ZLBCO3[I])continue;

    STATUS = Unload_Lv_Polygon(I);
    if(!STATUS)continue;

    Dix_output();
if(Dxb_Output_Pleas)
Dxb_Ld_Image_Maker(1, O_Layer.Name);
    }
    fprintf(stderr, "Ok!");
  }
  void Z_Next_Fragment(void)
  {
  long F;
  long I = 0;
    F = LONG_MAX;
    while(I<Z_Layers_Cnt)
    {
    if(Z_Layer[I].Fragment<F)F = Z_Layer[I].Fragment;
    ++I;
    }
    ++Z_Fragment;
    if(Target_Function==ZZZNOTJ)
    if(Z_Fragment<(XBCNT*YBCNT))
    {
    return;
    }
    Z_Fragment = F;
  }
  void Z_Fclose_All(void)
  {
  long I;
    if(ERRFIL)
    {
    ZLDLIM = 0;
    Dxb_Ld_Image_Maker(0, NULL);
    }
    for(I = 0; I<Z_Layers_Cnt; ++I)
    fclose(Z_Layer[I].File.Fil);

    Dix_close();
    O_Layer.LX_S.STATUS = 1;
    renameoutput();

    Lz_Lx_Close();
  }
  void zabort(void)
  {
    fprintf(stderr, "\nFATAL! EXITING DUE TO ERRORS");
    if(O_Layer.File.Fil)
    {
    fclose(O_Layer.File.Fil);
    unlink(O_Layer.PdbN);
    }
    if(ERRFIL!=NULL)
    {
    ZLDLIM = 0;
    Dxb_Ld_Image_Maker(0, NULL);
    fclose(ERRFIL);
    }
    exit(1);
  }
  void main(short N, char*A[])
  {
    Com_Line_Scan(N, A);

    Initial_Setup_1();
    Initial_Setup_2();
    Initial_Setup_3();

    PRINT_START();

    while(Z_Fragment!=LONG_MAX)
    {
    Determine_Point_Base();

    F_Evaluater();
    if(!Z_Full_Scan&&(Z_Fragment==Z_User_Block))break;

    Z_Next_Fragment();
    }
    fprintf(stderr, "\n");

    Z_Fclose_All();

    PRINT_FINISH();
    exit(0);
  }
