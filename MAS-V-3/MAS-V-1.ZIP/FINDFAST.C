  long  FINDIFAST(long P1, long P2, long VT)
  {
  static double SLOPE1, SLOPE3, SLOP13, IXD;
  static long X1, X2, X3, X4, Y1, Y2, Y3, Y4;
  static long YMIN1, YMAX1, YMIN3, YMAX3;
  static long TM, P3, P4, IT, IX, IY, V3;
  static long DELX1, DELY1, DELX3, DELY3;
  static char INT1, INT3, SW, SV;
    X1 = ZPTCO1[P1];
    X2 = ZPTCO1[P2];
    Y1 = ZPTCO2[P1];
    Y2 = ZPTCO2[P2];
    if((X1>X2)||((X1==X2)&&(Y1>Y2)))
    {
      SW = 1;
      TM = X1, X1 = X2, X2 = TM;
      TM = Y1, Y1 = Y2, Y2 = TM;
      TM = P1, P1 = P2, P2 = TM;
    }
    else SW = 0; /*ALSO-V3-IS-NEVER-SWITCHED*/
    if(Y1>Y2) YMIN1 = Y2, YMAX1 = Y1;
    else YMIN1 = Y1, YMAX1 = Y2;
    DELX1 = X2-X1;
    DELY1 = Y2-Y1;
    if(DELX1) SLOPE1 = (double)DELY1/DELX1;
    else SLOPE1 = MAXLONG;
    for(IT = 0; VT<ZPVLIM; ++VT) /*FOR-EACH-EXISTING-VECTOR*/
    {
      V3 = ZPVCO5[VT];
      P3 = ZVTCO1[V3];
      P4 = ZVTCO2[V3];
      X3 = ZPTCO1[P3];
      X4 = ZPTCO1[P4];
      Y3 = ZPTCO2[P3];
      Y4 = ZPTCO2[P4];
      if(Y3>Y4) YMIN3 = Y4, YMAX3 = Y3;
      else YMIN3 = Y3, YMAX3 = Y4;
      if(X1>X4||X2<X3) continue;
      if(YMIN1>YMAX3||YMAX1<YMIN3) continue;
      SV = (X3==X4)&&(Y3>Y4);
      DELX3 = X4-X3;
      DELY3 = Y4-Y3;
      if(DELX1&&DELX3) /*NOT-INFINITE-SLOPES*/
      {
        SLOPE3 = (double)DELY3/DELX3;
        if(ENVEQ(SLOPE1, SLOPE3, 0.00001)) /*MAY-BE-COINCIDENCE*/
	{
	  if((P1==P4)||(P2==P3)) continue;
	  if(!(X4-X1)) continue;
	  SLOP13 = (double)(Y4-Y1)/(X4-X1);
	  if(!ENVEQ(SLOP13, SLOPE1, 0.00001)) continue;
	  IT = (P1==P3)&&(P2==P4)? 7: 8;
	  break;
	} /*END-FOR-CHECK-COINCIDENCE*/
	else
	{
	  IXD = (SLOPE1*X1-SLOPE3*X3-Y1+Y3)/(SLOPE1-SLOPE3);
	  IX = floor(IXD + 0.5);
	  if(IX<X1||IX>X2) continue;
	  if(IX<X3||IX>X4) continue;
	/*HENCE: IX>=X1&&IX<=X2 AND IX>=X3&&IX<=X4*/
	  IY = floor(SLOPE3*(IXD-X3) + Y3 + 0.5);
	  if(IY<YMIN1||IY>YMAX1) continue;
	  if(IY<YMIN3||IY>YMAX3) continue;
	/*HENCE: VECTORS-WERE-INTERSECTED*/
	/*EXLUDING-POINT-TO-POINT-NEEDED*/
	  if(IX>X1&&IX<X2) INT1 = +1;
	    else if(IY>YMIN1&&IY<YMAX1) INT1 = +1;
	  else INT1 = -1;
	  if(IX>X3&&IX<X4) INT3 = +1;
	    else if(IY>YMIN3&&IY<YMAX3) INT3 = +1;
	  else INT3 = -1;
	  if(INT1<0&&INT3<0) continue;
	  if(INT1<0) IT = 1;
	  else if(INT3<0) IT = 3;
	  else IT = 5;
	  break;
	} /*END-FOR-CHECK-INTERSECTION*/
      } /*END-FOR-NOT-INFINITE-SLOPES*/
      else
      if(DELX1) /*INFINITE-SLOPE3*/
      {
	IX = X3;
	IY = floor(SLOPE1*(IX-X1) + Y1 + 0.5);
        if(IY<Y3||IY>Y4) continue;
          else if(IY>Y3&&IY<Y4) INT3 = +1;
	else INT3 = -1;
	if(INT3<0) /*CHECK-POINT-TO-POINT*/
	{
	  if(X1==IX||X2==IX) continue;
	  IT = 3;
	}
	else /*V3-CROSSED-ALWAYS*/
	{
	  if(X1==IX||X2==IX) IT = 1;
	  else IT = 5;
	}
	break;
      } /*END-FOR-INFINITE-SLOPE3*/
      else
      if(DELX3) /*INFINITE-SLOPE1*/
      {
	SLOPE3 = (double)DELY3/DELX3;
	IX = X1;
        IY = floor(SLOPE3*(IX-X3) + Y3 + 0.5);
        if(IY<Y1||IY>Y2) continue;
	  else if(IY>Y1&&IY<Y2) INT1 = +1;
	else INT1 = -1;
	if(INT1<0) /*CHECK-POINT-TO-POINT*/
	{
	  if(X3==IX||X4==IX) continue;
	  IT = 1;
	}
	else /*V1-CROSSED-ALWAYS*/
	{
	  if(X3==IX||X4==IX) IT = 3;
	  else IT = 5;
	}
	break;
      } /*END-FOR-INFINITE-SLOPE1*/
      else /*BOTH-INFINITE-SLOPE-THEREFORE-COINCIDENCE*/
      {
	if(SV) ZSWAB(&P3, &P4);
	if((P1==P4)||(P2==P3)) continue;
	if((P1==P3)&&(P2==P4)) IT = 7;
	else IT = 8;
	break;
      } /*END-FOR-HARD-COINCIDENCE*/
    } /*END-FOR-EACH-VECTOR*/
    if(IT) switch(IT) /*CORRECT-ITYPE*/
    {
      case 1:
	if(DELX1)
	  IT = SW? (IX==X1? 2: 1): (IX==X1? 1: 2);
	else
	  IT = SW? (IY==Y1? 2: 1): (IY==Y1? 1: 2);
	break;
      case 3:
	if(DELX3)
	  IT = IX==X3? 3: 4;
	else
	  IT = IY==Y3? 3: 4;
	break;
      case 5:
	XINTRS = IX;
	YINTRS = IY;
	break;
      case 7:
	if(SW!=SV) IT = 6;
	break;
    /*DEFAULT-DONT-NEED-ANY-CORRECTING*/
    }
    TINTRS = IT;
    return(VT);
  }
