
  #define F_INIT_MODULE
  /**/
  #include<DOS.H>
  #include<MATH.H>
  #include<STDIO.H>
  /**/
  #ifdef __BORLANDC__
  #include<DIR.H>
  #include<ALLOC.H>
  #endif
  /**/
  #include<STDLIB.H>
  #include<CTYPE.H>
  #include<STRING.H>
  /**/
  #ifdef __BORLANDC__
  #include<VALUES.H>
  #endif
  /**/
  #include<LIMITS.H>
  #include<PROCESS.H>
  /**/
  #ifndef DOS386
  #define malloc farmalloc
  #define free farfree
  #endif
  /**/
  void dontworry(void);
  char * mg_sort(char *);
  /**/
  #ifndef SHORT
  #define SHORT unsigned short
  #endif
  #ifndef MAXLONG
  #define MAXLONG LONG_MAX
  #endif
  #define Isalpha(S) (isalpha((S))||(S)=='$')
  /**/
  long*ZXgCO0; /*GRID-X-BOUNDARY-TABLE*/
  long*ZYgCO0; /*GRID-Y-BOUNDARY-TABLE*/
  long*ZXgCO1; /*GRID-X-BOUNDARY-TABLE*/
  long*ZYgCO1; /*GRID-Y-BOUNDARY-TABLE*/
  long*ZXgCO2; /*GRID-X-BOUNDARY-TABLE*/
  long*ZYgCO2; /*GRID-Y-BOUNDARY-TABLE*/
  #ifdef __BORLANDC__
  SHORT huge*ZgACO2; /*POINTER-TO-FIRST-gV-BEAD-FOR-THIS-BLOCK*/
  #else
  SHORT*ZgACO2; /*POINTER-TO-FIRST-gV-BEAD-FOR-THIS-BLOCK*/
  #endif
  SHORT*ZgVCO1; /*LINK-TO-THE-NEXT-gV-BEAD*/
  SHORT*ZgVCO2; /*FIRST-J-POINT*/
  SHORT*ZgVCO3; /*SECOND-J-POINT*/
  SHORT**IgVCOR[4] = {&ZgVCO1, &ZgVCO2, &ZgVCO3, NULL};

  long ZgVLIM;
  long ZgVMAX;
  /**/
  long XgDIV; /*GRID-BLOCK-SIZE-UNITS-WIDE*/
  long YgDIV; /*GRID-BLOCK-SIZE*/
  long XgCNT; /*TOTAL-BLOCKS-IN-X-DIRECTION*/
  long YgCNT; /*TOTAL-BLOCKS-IN-Y-DIRECTION*/
  long XgCNT_2; /*TOTAL-BLOCKS-IN-X-DIRECTION*/
  long YgCNT_2; /*TOTAL-BLOCKS-IN-Y-DIRECTION*/
  /**/
  long SP_YEND; /*END-Yg-FOR-LOOP*/
  long SP_YBEg; /*START-Yg*/
  long SP_YSTA; /*Y-COORD-SETTED-BY-PREVIOUSLY-COMPUTATING*/
  long SP_XSTA; /*X-COORD*/
  long SP_XFIR; /*FIRST-X-COORD-OF-A-VECTOR*/
  long SP_YFIR; /*FIRST-Y-COORD*/
  long VTMATCH; /*RIGHT-VT-VECTOR-MATCHED-LV-VECTOR*/
  long SP_SWIT; /*VECTOR-WAS-SWITCHED-FLAG*/
  long XSECOND; /*SECOND-X*/
  long YSECOND; /*SECOND-Y*/
  long SP_XMIN; /*MINIMAL-Xg-FOR-THIS-POLY*/
  long SP_XMAX; /*MAX-Xg*/
  long SP_YMIN; /*MINIMAL-Yg-FOR-THIS-VECTOR*/
  long SP_YMAX; /*MAX-Yg*/

  long XROUND;
  long YROUND;
  double SP_SLOP; /*SLOPE-OF-A-VECTOR*/
  /**/
  long Z_XBCNT;
  long Z_YBCNT;
  long Z_XBSIZ;
  long Z_YBSIZ;
  long Z_CXMIN;
  long Z_CXMAX;
  long Z_CYMIN;
  long Z_CYMAX;
  /**/
  SHORT*ZPTAUX;
  SHORT AUXLIM;
  SHORT AUXMAX;
  /**/
  char is_ipoint0;
  /**/
  long gA_Core_Size;
  /**/
  char Out_of_Bound;
  char Out_of_Bound_Xmin;
  char Out_of_Bound_Ymin;
  char Out_of_Bound_Xmax;
  char Out_of_Bound_Ymax;
  /**/
  long Total_IPoly; /*TOTAL-POLYGONS-NUMBER*/
  long Total_OPoly; /*TOTAL-POLYGONS-NUMBER*/
  /**/
  char Dxb_Output_Pleas;
  /**/
  #define EVALUATEX(Y) (floor(((double)((Y)-SP_YFIR))/SP_SLOP+SP_XFIR+0.5))
  #define EVALUATEY(X) (floor(SP_SLOP*((X)-SP_XFIR)+SP_YFIR+0.5))
  char SP_SX;
  char SP_SY;
  /**/
  #include "F0EVAL.H"
  /**/
  void
  zabort(void)
  {
  fprintf(stderr, "\nFATAL! EXITING DUE TO ERRORS");
  if(O_Layer.File.Fil)
  {
  fclose(O_Layer.File.Fil);
  Delete_File(O_Layer.PdbN);
  }
  exit(1);
  }
  long
  ZgVNEXT(void)
  {
  if((ZgVLIM+1)>=ZgVMAX)ZOUTABORT();
  return(ZgVLIM++);
  }
  void
  ZgVALLOC(long L)
  {
    ZgVLIM = 0;
    ZgVMAX = L;
    ZXXALLOC((void***)IgVCOR, L*2);
  }
  /*DXB-FORMAT-SECTION*/
  void write_header(FILE*DXB)
  {
  char header[40];
    strncpy(header, "AutoCAD DXB 1.0\r\n\x1a", 40);
     fwrite(header, strlen(header)+1, 1, DXB);
    return;
  }
  void set_double(FILE*DXB)
  {
  unsigned char id;
  short mode;
    id = 135; /*ITEM-IS-NUMBER-MODE*/
    mode = 1; /*DOUBLE-MODE-FOLLOWS*/
    fwrite((char*)&id, 1, 1, DXB);
    fwrite((char*)&mode, 2, 1, DXB);
  }
  void write_pline
  (FILE*DXB, short closure)
  {
  struct
  {
    unsigned char id;
    short closure;
  } pline;
    pline.id = 19;
    pline.closure = closure;
    fwrite((char*)&pline, 3, 1, DXB);
  }
  void write_layer
  (FILE*DXB, char*layer)
  {
  unsigned char id;
    id = 129;
    fwrite((char*)&id, 1, 1, DXB);
    fwrite(layer, strlen(layer)+1, 1, DXB);
  }
  void write_vertex
  (FILE*DXB, long x, long y)
  {
  struct
  {
    unsigned char id;
    double dx, dy;
  } vertex;
    vertex.id = 20;
    vertex.dx = (double)x;
    vertex.dy = (double)y;
    fwrite((char*)&vertex, 17, 1, DXB);
  }
  void write_seqend
  (FILE*DXB)
  {
  unsigned char id;
    id = 17;
    fwrite((char*)&id, 1, 1, DXB);
  }
  void
  Dxb_Ld_Image_Maker
  (char closure, char*s)
  {
  long L;
  unsigned char id;
    if(ZLDLIM==0)
    {
    if(ERRFIL)id = 0,
    fwrite((char*)&id, 1, 1, ERRFIL), fclose(ERRFIL);
    return;
    }
    if(ZLDLIM<=1) return;
    if(!ERRFIL)
    {
    ERRFIL=Fopen(ERRNAM, "wb");
    
    write_header(ERRFIL);
    set_double(ERRFIL);
    }
    if(s) write_layer(ERRFIL, s);
    write_pline(ERRFIL, (short)closure);

    for(L = 0; L<ZLDLIM; ++L)
    {
    write_vertex(ERRFIL, ZLDCO0[L], ZLDCO1[L]);
    }
    write_seqend(ERRFIL);
  }
  void
  Unload_LV_Polygons(long Xg, long Yg)
  {
    long I;
    ZZ_DELTA_X = -ZXgCO0[Xg-1];
    ZZ_DELTA_Y = -ZYgCO0[Yg-1];

    if(ZXgCO0[Xg]<=CXMIN)return;
    if(ZYgCO0[Yg]<=CYMIN)return;

    if(ZXgCO0[Xg-1]>=CXMAX)return;
    if(ZYgCO0[Yg-1]>=CYMAX)return;

    if(Out_of_Bound)
    {
    if(Out_of_Bound_Xmin)--Xg;
    if(Out_of_Bound_Ymin)--Yg;
    }
    Z_Fragment =
    (Xg-1)*YBCNT + Yg-1;

    for(I = 1;I<ZLBLIM; ++I)
    {
    if(ZLBCO3[I]==0)continue;
    Unload_Lv_Polygon(I);

    if(STATUS)Dix_output();
    }
  }
  void
  DETERMINEGRIDVECTOR(long Xg, long Yg)
  {
    long VT;
    long gV;
    long gB;
    long IX;
    long IY;
    long JY;
    long JX;

    long IY0;
    long IX1;
    long IY1;

    IX1 = ZXgCO0[Xg];
    IY1 = ZYgCO0[Yg], IY0 = ZYgCO0[Yg-1];

    IX = SP_XSTA;
    IY = SP_YSTA;

    if(!SP_SX) JX = IX, JY = YSECOND<IY1 ? YSECOND : IY1;
    else
    if(!SP_SY) JY = IY, JX = XSECOND<IX1 ? XSECOND : IX1;
    else
    {
    if(IX1<XSECOND) JX = IX1, JY = EVALUATEY(JX);
    else JX = XSECOND, JY = YSECOND;

    if(SP_SY==+1)
    {
    if(JY>IY1) JY = IY1, JX = EVALUATEX(JY);
    }
    else
    if(JY<IY0) JY = IY0, JX = EVALUATEX(JY);
    }
    SP_XSTA = JX, SP_YSTA = JY;

    if(JX==IX&&JY==IY)
    {
    return;
    }
    VT = VTMATCH;
    if(JX!=XSECOND||JY!=YSECOND)
    {
    VTMATCH = SPLITVT(VTMATCH, IPOINT(JX, JY));
    }
    if(SP_SWIT)
    {
    VT = ZVTCO6[VT];
    }
    if(IX==JX&&JX==IX1&&Xg!=XgCNT)
    {
    Xg += XROUND;
    }
    gV = ZgVNEXT(), gB = (Xg-1)*YgCNT+Yg-1;

    ZgVCO2[gV] = ZVTCO1[VT];
    ZgVCO3[gV] = ZVTCO2[VT];
    ZgVCO1[gV] = ZgACO2[gB];
    ZgACO2[gB] = gV;
  }
  void
  Set_Ag_Flags(long Xg)
  {
    long Yg;
    long LP;
    long SI;

    if(SP_XFIR==XSECOND) SP_SX = 0;
    else SP_SX =+1;
    if(SP_YFIR<YSECOND) SP_SY =+1;
    else if(SP_YFIR>YSECOND) SP_SY =-1;
    else SP_SY = 0;

    if(!SP_SX&&!SP_SY) return;

    SI = SP_YBEg<SP_YEND? +1: -1;
    LP = (SI*(SP_YEND-SP_YBEg))+1;

    for(Yg=SP_YBEg; LP; --LP, Yg+=SI)
    {
    DETERMINEGRIDVECTOR(Xg, Yg);
    }
  }
  typedef
  void S_gV(long);
  S_gV * SPLIT_gVECTOR;
  void
  SPLIT_gVECTOR_1(long LV)
  {
    long X1, X2, Y1, Y2, S2, DX, DY;
    long Xg, IX, IY, Xg1, Xg2, Yg1, Yg2;

    X1 = ZPTCO1[ZLVCO5[LV]];
    Y1 = ZPTCO2[ZLVCO5[LV]];
    Y2 = ZPTCO2[ZLVCO6[LV]];
    X2 = ZPTCO1[ZLVCO6[LV]];
    DX = X2-X1;
    DY = Y2-Y1;
    XROUND = 0;
    if(!DX) /*X1-Eg-X2*/
    {
    YROUND = 0;

    if(Y1>Y2) S2 =-STATUS, ZSWAB(&Y1, &Y2);
    else S2 = STATUS;
    if(S2==+1) Xg1 = ((X1-CXMIN)/XgDIV)+1;
    else Xg1 = ((X1-CXMIN-1)/XgDIV)+1;

    Xg2 = Xg1;
    Yg1 = ((Y1-CYMIN)/YgDIV)+1;
    Yg2 = ((Y2-CYMIN-1)/YgDIV)+1;
    }
    else /*X1-NE-X2*/
    {
    if(X1>X2) S2 =-STATUS, ZSWAB(&X1, &X2), ZSWAB(&Y1, &Y2);
    else S2 = STATUS;

    Xg1 = ((X1-CXMIN)/XgDIV)+1;
    Xg2 = ((X2-CXMIN-1)/XgDIV)+1;

    YROUND = S2==+1? -1: 0;
    if(!DY) /*Y1-Eg-Y2*/
    {
    if(S2==+1) Yg1 = ((Y1-CYMIN-1)/YgDIV)+1;
    else Yg1 = ((Y1-CYMIN)/YgDIV)+1;
    Yg2 = Yg1;
    }
    else /*Y1-NE-Y2-(ALSO-X1-NE-X2)*/
    {
    if(Y2>Y1) /*POSITIVE-SLOPE*/
    {
    Yg1 = ((Y1-CYMIN)/YgDIV)+1;
    Yg2 = ((Y2-CYMIN-1)/YgDIV)+1;
    XROUND = S2==+1? +1: 0;
    }
    else /*NEGATIVE-SLOPE*/
    {
    Yg1 = ((Y1-CYMIN-1)/YgDIV)+1;
    Yg2 = ((Y2-CYMIN)/YgDIV)+1;
    XROUND = S2==+1? 0: +1;
    }
    } /*END-Y1-NE-Y2*/
    } /*END-X1-NE-X2*/

    if(Xg1<SP_XMIN) SP_XMIN = Xg1;
    if(Yg1<SP_YMIN) SP_YMIN = Yg1;
    if(Yg2>SP_YMAX) SP_YMAX = Yg2;
    if(Yg2<SP_YMIN) SP_YMIN = Yg2;
    if(Yg1>SP_YMAX) SP_YMAX = Yg1;
    if(Xg2>SP_XMAX) SP_XMAX = Xg2;

    SP_XFIR = SP_XSTA = X1;
    SP_YFIR = SP_YSTA = Y1;

    XSECOND = X2;
    YSECOND = Y2;

    SP_SWIT = S2!=STATUS;

    VTMATCH = SP_SWIT? ZVTCO6[ZLVCO2[LV]]: ZLVCO2[LV];
    SP_SLOP = DX? (DY? ((double)DY)/DX: 0): MAXLONG;

    /*FOR-EACH-BUT-THE-LAST-Xg-VALUE*/

    SP_YEND = SP_YBEg = Yg1;

    if(Yg1==Yg2)
    for(Xg = Xg1; Xg<Xg2; ++Xg)
    Set_Ag_Flags(Xg);

    else
    for(Xg = Xg1; Xg<Xg2; ++Xg)
    {
    IX = ZXgCO0[Xg];
    IY = floor(SP_SLOP*(IX-X1)+Y1 +0.5);

    SP_YEND = (IY-CYMIN+YROUND)/YgDIV+1;
    Set_Ag_Flags(Xg);
    SP_YBEg = SP_YEND;
    }
    /*NOW-FOR-THE-LAST-Xg-VALUE*/

    Xg = Xg2;
    SP_YEND = Yg2;

    Set_Ag_Flags(Xg);
  }
  void
  SPLIT_gVECTOR_2(long LV)
  {
    char SW;
    long X1, X2, Y1, Y2, S2, DX, DY;
    long Xg, IX, IY, Xg1, Xg2, Yg1, Yg2;
    long XR, YR, XB, YB;

    X1 = ZPTCO1[ZLVCO5[LV]];
    Y1 = ZPTCO2[ZLVCO5[LV]];
    Y2 = ZPTCO2[ZLVCO6[LV]];
    X2 = ZPTCO1[ZLVCO6[LV]];
    DX = X2-X1;
    DY = Y2-Y1;
    SW = 0;
    YROUND = XROUND = 0;
    if(!DX) /*X1-Eg-X2*/
    {
    if(Y1>Y2) S2 =-STATUS, ZSWAB(&Y1, &Y2);
    else S2 = STATUS;
    XR = S2==+1;
    YR = 1;
    }
    else /*X1-NE-X2*/
    {
    if(X1>X2) S2 =-STATUS, ZSWAB(&X1, &X2), ZSWAB(&Y1, &Y2);
    else S2 = STATUS;
    XR = 1;
    if(!DY) /*Y1-Eg-Y2*/ YR = S2==-1;
    else /*Y1-NE-Y2-(ALSO-X1-NE-X2)*/
    {
    YR = 1;
    if(Y2<Y1) /*NEGATIVE-SLOPE*/
    {
    ZSWAB(&Y1, &Y2);
    SW = 1;
    XROUND = S2==+1? 0: +1;
    }
    else XROUND = S2==+1? +1: 0;
    } /*END-Y1-NE-Y2*/
    } /*END-X1-NE-X2*/
    YB = ZYgCO0[1];
    XB = ZXgCO0[1];
    Yg1 = 1;
    while(Y1>YB)
    YB = ZYgCO0[++Yg1];

    if(YR&&YB==Y1)
    YB = ZYgCO0[++Yg1];

    Yg2 = Yg1;
    while(Y2>YB)
    YB = ZYgCO0[++Yg2];

    Xg1 = 1;
    while(X1>XB)
    XB = ZXgCO0[++Xg1];

    if(XR&&X1==XB)
    XB = ZXgCO0[++Xg1];

    Xg2 = Xg1;
    while(X2>XB)
    XB = ZXgCO0[++Xg2];

    if(SW) ZSWAB(&Y1, &Y2), ZSWAB(&Yg1, &Yg2);

    if(Xg1<SP_XMIN) SP_XMIN = Xg1;
    if(Yg1<SP_YMIN) SP_YMIN = Yg1;
    if(Yg2>SP_YMAX) SP_YMAX = Yg2;
    if(Yg2<SP_YMIN) SP_YMIN = Yg2;
    if(Yg1>SP_YMAX) SP_YMAX = Yg1;
    if(Xg2>SP_XMAX) SP_XMAX = Xg2;

    SP_XFIR = SP_XSTA = X1;
    SP_YFIR = SP_YSTA = Y1;

    XSECOND = X2;
    YSECOND = Y2;

    SP_SWIT = S2!=STATUS;

    VTMATCH = SP_SWIT? ZVTCO6[ZLVCO2[LV]]: ZLVCO2[LV];
    SP_SLOP = DX? (DY? ((double)DY)/DX: 0): MAXLONG;

    /*FOR-EACH-BUT-THE-LAST-Xg-VALUE*/

    SP_YEND = SP_YBEg = Yg1;
    if(Yg1==Yg2)
    for(Xg=Xg1; Xg<Xg2; ++Xg) Set_Ag_Flags(Xg);

    else
    for(Xg=Xg1; Xg<Xg2; ++Xg)
    {
    IX = ZXgCO0[Xg];
    IY = floor(SP_SLOP*(IX-X1)+Y1+0.5);
    if(SW) /*NEGATIVE-SLOPE*/
    {
    YB = ZYgCO0[SP_YEND-1];
    while(IY<YB) YB = ZYgCO0[--SP_YEND-1];
    if(IY==YB&&S2==+1) --SP_YEND;
    }
    else
    {
    YB = ZYgCO0[SP_YEND];
    while(IY>YB) YB = ZYgCO0[++SP_YEND];
    if(IY==YB&&S2==-1) ++SP_YEND;
    }
    Set_Ag_Flags(Xg);
    SP_YBEg = SP_YEND;
    }
    /*NOW-FOR-THE-LAST-Xg-VALUE*/

    Xg = Xg2;
    SP_YEND = Yg2;

    Set_Ag_Flags(Xg);
  }
  void
  DEFINELBGRIDDATA(long LB)
  {
  long LE, LV, LN;
    LE = LV = ZLBCO3[LB];
    if(LE) do
    {
    LN = ZLVCO1[LV];
    SPLIT_gVECTOR(LV);
    LV = LN;
    }
    while(LV!=LE);
  }
  long ZB_YUP, ZB_YLO, ZB_XRI, ZB_XLE;
  void
  LOADGRIDBOUNDARY(long Xg, long Yg)
  /*Xg-RIGHT-BOUNDARY; Yg-UPPER-BOUNDARY*/
  {
    ZLDLIM = 5;
    ZB_YUP=ZLDCO1[1]=ZLDCO1[2]=ZYgCO0[Yg]; /*UPPER*/
    ZB_YLO=ZLDCO1[0]=ZLDCO1[3]=ZYgCO0[Yg-1]; /*LOWER*/
    ZB_XRI=ZLDCO0[2]=ZLDCO0[3]=ZXgCO0[Xg]; /*RIGHT*/
    ZB_XLE=ZLDCO0[0]=ZLDCO0[1]=ZXgCO0[Xg-1]; /*LEFT*/
    ZLDCO0[4] = ZLDCO0[0];
    ZLDCO1[4] = ZLDCO1[0];
  }
  void
  GRIDBLOCKGEN(long Xg, long Yg)
  {
    long S = STATUS;
    LOADGRIDBOUNDARY(Xg, Yg);
    Z_Fragment = (Xg-1)*YgCNT+(Yg-1);

    ZZ_DELTA_X = -ZB_XLE;
    ZZ_DELTA_Y = -ZB_YLO;

    STATUS = 1;
    Dix_output();
    STATUS = S;
  }
  long SETGRIDMODE(long Xg)
  /*Xg-RIGHT-BOUNDARY*/
  {
  long IS, LB, LV, LE, X1, X2, XB;
    XB = ZXgCO0[Xg];
    for(LB = 1; LB<ZLBLIM; ++LB)
    {
      if((LV = LE = ZLBCO3[LB])!=0)
      {
	X1 = ZPTCO1[ZLVCO5[LV]];
	do
	{
	X2 = ZPTCO1[ZLVCO6[LV]];
	IS = (X1==XB)&&(X1==X2);
	if(IS&&!ZVTCO4[ZLVCO2[LV]]) return(1);
	LV = ZLVCO1[LV];
	X1 = X2;
	}
	while(LE!=LV);
      }
    }
    return(0);
  }
  void
  LOADGRIDVECTORS(long gB)
  {
  long gV, P1, P2, P3, P4, V3, V4, LS, RS;
  long X1, Y1, X2, Y2;
    AUXLIM = 0;
    RS = STATUS==+1? 1: 0;
    LS = STATUS==+1? 0: 1;
    P3 = P4 = 0;
    for(gV = ZgACO2[gB]; gV; gV = ZgVCO1[gV])
    {
      P1 = ZgVCO2[gV];
      P2 = ZgVCO3[gV];

      X1 = ZPTCO1[P1];
      X2 = ZPTCO1[P2];

      if(AUXLIM<AUXMAX&&P3!=P1&&P4!=P1)
      {
      Y1 = ZPTCO2[P1];
      if(X1==ZB_XLE||
	 X1==ZB_XRI||
	 Y1==ZB_YUP||
	 Y1==ZB_YLO)
      ZPTAUX[AUXLIM++] = P1;

      ZPTCO3[P1] = 0;
      }
      if(AUXLIM<AUXMAX&&P3!=P2&&P4!=P2)
      {
      Y2 = ZPTCO2[P2];
      if(X2==ZB_XLE||
	 X2==ZB_XRI||
	 Y2==ZB_YUP||
	 Y2==ZB_YLO)
      ZPTAUX[AUXLIM++] = P2;

      ZPTCO3[P2] = 0;
      }
      P3 = P1, P4 = P2;

      V3 = ZVTLIM++;
      V4 = ZVTLIM++;
      if(ZVTLIM>=ZVTMAX)ZOUTABORT();

      if(X1>X2)ZSWAB(&V3, &V4);

      ZVTCO5[V3] = ZVTCO5[V4] = 0;
      ZVTCO6[V3] = V4;
      ZVTCO6[V4] = V3;
      ZVTCO2[V4] = ZVTCO1[V3] = P1;
      ZVTCO1[V4] = ZVTCO2[V3] = P2;
      ZVTCO4[V3] = RS;
      ZVTCO4[V4] = LS;
    } /*END-FOR-EACH-GRID-VECTOR*/
  }
  void GRID_INTERSECTION(void)
  {
  long A, V, E, P, T, X, Y, V3, V4;
  long p1, p2, x1, x2, y1, y2;
  char horizontal;
    V = E = ZLBCO3[1L];
    do
    {
      p1 = ZLVCO5[V];
      p2 = ZLVCO6[V];

      x1 = ZPTCO1[p1];
      x2 = ZPTCO1[p2];
      y1 = ZPTCO2[p1];
      y2 = ZPTCO2[p2];

      if(y1==y2) horizontal = 1;
      else horizontal = 0;
      for(A = 0; A<AUXLIM; ++A)
      {
      P = ZPTAUX[A];

      if(!P) continue;

      X = ZPTCO1[P];
      Y = ZPTCO2[P];

      if(horizontal)
      {
      if(y1!=Y) continue;
      if(x1>=X&&x2>=X) continue;
      if(x1<=X&&x2<=X) continue;
      }
      else
      {
      if(x1!=X) continue;
      if(y1>=Y&&y2>=Y) continue;
      if(y1<=Y&&y2<=Y) continue;
      }
      T = ZLVLIM++;
      if(ZLVLIM>=ZLVMAX)ZOUTABORT();

      ZLVCO3[T] = 0;
      ZLVCO1[T] = ZLVCO1[V];
      ZLVCO1[V] = T;
      ZLVCO7[T] = 1;
      ZLVCO6[T] = ZLVCO6[V];
      ZLVCO6[V] = P;
      ZLVCO5[T] = P;

      ZPTAUX[A] = 0;

      p2 = P;

      x2 = ZPTCO1[p2];
      y2 = ZPTCO2[p2];
      }
      V3 = ZVTLIM++;
      V4 = ZVTLIM++;
      if(ZVTLIM>=ZVTMAX)ZOUTABORT();

      ZVTCO5[V3] = V, ZVTCO5[V4] = 0;
      ZVTCO6[V3] = V4;
      ZVTCO6[V4] = V3;
      ZVTCO2[V4] = ZVTCO1[V3] = p1;
      ZVTCO1[V4] = ZVTCO2[V3] = p2;
      ZVTCO4[V3] = ZVTCO4[V4] = 0L;

      V = ZLVCO1[V];
    }
    while(V!=E);
  }
  void REBUILD_GRIDTABLE(void)
  {
  long Y, X, L;
    for(Y = SP_YMIN; Y<=SP_YMAX; ++Y)
    for(X = SP_XMIN; X<=SP_XMAX; ++X)
    {
    ZgACO2[(X-1)*YgCNT+(Y-1)] = 0;
    }
    FORCE_C_POLYGONS();

    SP_XMIN=XgCNT, SP_XMAX=0;
    SP_YMIN=YgCNT, SP_YMAX=0;
    for(ZgVLIM = L = 1; L<ZLBLIM; ++L)
    {
    if(ZLBCO3[L]<1) continue;
    DUMMYJUNCTIONANALYSIS(L);
    DEFINELBGRIDDATA(L);
    }
    STATUS = +1;
  }
  void REMOVE_GRID_POINT(long P)
  {
  register long B, x, y, p, Y, X;
    X = ZPTCO1[P];
    Y = ZPTCO2[P];
    y = ((Y-PYMIN)/YPDIV)+1;
    x = ((X-PXMIN)/XPDIV)+1;
    /* THIS CORRECTION IS NEEDED FOR GRIDBLOCK-INSERT ONLY */
    if(x<1) x = 1;
    else if(x>PXCNT) x = PXCNT;
    if(y<1) y = 1;
    else if(y>PXCNT) y = PYCNT;

    p = ZPBCOR[B = (--x)*PYCNT+(--y)];

    if(p==P)
    {
    ZPBCOR[B] = ZPTCO5[P];
    return;
    }
    while(p&&ZPTCO5[p]!=P)
    {
    p = ZPTCO5[p];
    }
    if(p) ZPTCO5[p] = ZPTCO5[P];
    else zabort();
  }
  void CLEAR_PV_POINTERS(long L)
  {
    long V;
    long E;
    V = E = ZLBCO3[L];
    if(!E) return;
    do
    {
    ZPTCO3[ZLVCO5[V]] = 0;
    V = ZLVCO1[V];
    }
    while(V!=E);
  }
  long FULLANALYSIS(long X, long Y)
  {
  long B, M, S, P;
    ZLBLIM=ZLVLIM=1;
    ZVTLIM = 2;
    S_Free = 1;
    LOADGRIDBOUNDARY(X, Y);

    B = (X-1)*YgCNT+(Y-1);
    LOADGRIDVECTORS(B);

    S = STATUS;
    P = ZPTLIM;
    STATUS = 1;

    Z_FEval_Storage();
    CLEAR_PV_POINTERS(1L);

    if(AUXLIM<AUXMAX)
    GRID_INTERSECTION();
    else
    zabort();

    POINT_VECTOR_ANALYSIS(2);
    FORCE_C_POLYGONS();
    Unload_LV_Polygons(X, Y);

    M = SETGRIDMODE(X);

    S_Free = 0;
    STATUS = S;

    S = P;
    if(!is_ipoint0)
    while(P!=ZPTLIM) REMOVE_GRID_POINT(P++);
    ZPTLIM = S;

    return(M);
  }
  void
  INSERT_VECTORS(long L)
  {
  long E, V;
    V = E = ZLBCO3[L];
    do
    {
    INSERTV(ZLVCO5[V], ZLVCO6[V], V);
    V = ZLVCO1[V];
    }
    while(V!=E);
  }
  void
  SPLIT_POLYGON(void)
  {
    long X;
    long Y;
    long B;
    long M;
    long S;
    long E;
    ZLBLIM=ZLVLIM=ZPTLIM=ZYPLIM=ZgVLIM=1;
    ZVTLIM = S = 2;
    STATUS = 1;

    SP_XMIN=XgCNT, SP_XMAX=0;
    SP_YMIN=YgCNT, SP_YMAX=0;

    if(!Out_of_Bound)
    {
    X = (PXMIN-CXMIN)/XgDIV;
    Y = (PYMIN-CYMIN)/YgDIV;
    B = X*YgCNT+Y;

    X = (PXMAX-CXMIN-1)/XgDIV;
    Y = (PYMAX-CYMIN-1)/YgDIV;
    if(B==(X*YgCNT+Y))
    {
    Z_Fragment = B;
    ZZ_DELTA_X = -ZXgCO0[X];
    ZZ_DELTA_Y = -ZYgCO0[Y];

    Dix_output();
    return;
    }
    }
    Z_FEval_Storage();
    INSERT_VECTORS(1);

    POINT_VECTOR_ANALYSIS(S);
    S = ZVTLIM;
    DEFINELBGRIDDATA(1);

    if(SP_XMIN==SP_XMAX&&SP_YMIN==SP_YMAX)
    {
    B = (SP_XMIN-1)*YgCNT+(SP_YMIN-1);
    ZgACO2[B] = 0;

    Z_Fragment = B;
    ZZ_DELTA_X = -ZXgCO0[SP_XMIN-1];
    ZZ_DELTA_Y = -ZYgCO0[SP_YMIN-1];

    STATUS = 1;
    if(!Out_of_Bound)
    Dix_output();
    return;
    }
    E = 0;
    POINT_VECTOR_ANALYSIS(S);

    if(PV_Error)
    {
    POINT_VECTOR_CLASS(1);
    E |= SI_Error;
    }
    if(E)REBUILD_GRIDTABLE();

    for(Y = SP_YMIN; Y<=SP_YMAX; ++Y)
    {
    M = 0;
    for(X = SP_XMIN; X<=SP_XMAX; ++X)
    {
    B = (X-1)*YgCNT+(Y-1);
    if(ZgACO2[B])
    {
    M = FULLANALYSIS(X, Y);
    ZgACO2[B] = 0;
    }
    else
    if(M) GRIDBLOCKGEN(X, Y);
    } /*END-LOOP-OVER-Xg*/
    } /*END-LOOP-OVER-Yg*/
  }
  void
  dontworry(void)
  {
    long T;
    if(ZLDLIM)
    {
    if(Dxb_Output_Pleas)
    Dxb_Ld_Image_Maker(1, Z_Layer[0].Name);
    T = ++Total_OPoly;
    }
    else T = 100;
    if(!(T-(T/100)*100))
  fprintf(stderr, "\rINPUT: KBYTES=%ld, POLYGONS=%ld; OUTPUT: POLYGONS=%ld;", ZZ_RP_KB/1024, Total_IPoly, Total_OPoly);
  }
  void
  SET_Xg_Yg(void)
  {
    long Z;
    long X;
    long Y;
    long x;
    long y;
    long A;

    long F;

    Z_XBCNT = Z_Layer[0].LX_S.XBCNT;
    Z_YBCNT = Z_Layer[0].LX_S.YBCNT;
    Z_XBSIZ = Z_Layer[0].LX_S.XBSIZ;
    Z_YBSIZ = Z_Layer[0].LX_S.YBSIZ;
    Z_CXMIN = Z_Layer[0].LX_S.CXMIN;
    Z_CXMAX = Z_Layer[0].LX_S.CXMAX;
    Z_CYMIN = Z_Layer[0].LX_S.CYMIN;
    Z_CYMAX = Z_Layer[0].LX_S.CYMAX;

    XgDIV = XBSIZ;
    YgDIV = YBSIZ;

    if(Z_XBCNT==XBCNT&&Z_YBCNT==YBCNT)
    if(Z_CXMIN>=CXMIN&&Z_CXMAX<=CXMAX)
    if(Z_CYMIN>=CYMIN&&Z_CYMAX<=CYMAX)
    {
    fprintf(stderr, "\nIS OK!");
    if(O_Layer.File.Fil)
    {
    fclose(O_Layer.File.Fil);
    Delete_File(O_Layer.PdbN);
    }
    exit(0);
    }
    Z = 0;
    if(Z_CXMIN<CXMIN)Z|=0x1;
    if(Z_CXMAX>CXMAX)Z|=0x2;
    if(Z_CYMIN<CYMIN)Z|=0x4;
    if(Z_CYMAX>CYMAX)Z|=0x8;

    Out_of_Bound_Xmin = Z&0x1;
    Out_of_Bound_Xmax = Z&0x2;
    Out_of_Bound_Ymin = Z&0x4;
    Out_of_Bound_Ymax = Z&0x8;

    X = XBCNT+1;
    Y = YBCNT+1;

    if(Z&0x1)++X;
    if(Z&0x2)++X;
    if(Z&0x4)++Y;
    if(Z&0x8)++Y;

    XgCNT_2 = X-1;
    YgCNT_2 = Y-1;

    ZALLOCATE((void**)&ZXgCO1, X*4);
    ZALLOCATE((void**)&ZYgCO1, Y*4);

    gA_Core_Size = 0;
    gA_Core_Size+= X*4;
    gA_Core_Size+= Y*4;

    A = (X-1)*(Y-1);

    ZXgCO2 = ZXgCO1;
    ZYgCO2 = ZYgCO1;

    if(Z&0x1)ZXgCO2 += 1;
    if(Z&0x4)ZYgCO2 += 1;
    X = 0;
    x = CXMIN;
    while(X<=XBCNT) ZXgCO2[X++] = x, x += XBSIZ;
    Y = 0;
    y = CYMIN;
    while(Y<=YBCNT) ZYgCO2[Y++] = y, y += YBSIZ;

    if(Z&0x1)ZXgCO1[0] = Z_CXMIN;
    if(Z&0x2)ZXgCO2[XBCNT+1] = Z_CXMAX;

    if(Z&0x4)ZYgCO1[0] = Z_CYMIN;
    if(Z&0x8)ZYgCO2[YBCNT+1] = Z_CYMAX;

    ZALLOCATE((void**)&ZgACO2, A*2);
    for(X = 0; X<A; ++X) ZgACO2[X] = 0;

    gA_Core_Size+= A*2;
  }
  void
  SPLITPOLYGONS(void)
  {
    long I;
    STATUS = 1;

    Zd_File = Z_Layer[0].File.Fil;

    Zd_File_Buf = Z_Layer[0].File.Buf;

    Zd_File_Ptr = Z_Layer[0].File.Buf_Pos;
    Zd_File_Eof = Z_Layer[0].File.Buf_Eof;
    Zd_File_Lim = Z_Layer[0].File.Buf_Len;

    Zd_Delta_X = Z_Layer[0].Delta_X-CXMIN;
    Zd_Delta_Y = Z_Layer[0].Delta_Y-CYMIN;

    Zd_Fragment = &Z_Layer[0].Fragment;

    Z_Fragment = 0;
    DIX_Fragment = -1;
    while(Zd_Fragment[0]!=LONG_MAX)
    {
    Z_Read_Polygon();
    if(ZLDLIM==0)
    {
    long XB;
    long YB;
    Z_Fragment = Zd_Fragment[0];

    if(Z_Fragment!=LONG_MAX)
    {
    Zd_Delta_X = Z_Layer[0].Delta_X-CXMIN;
    Zd_Delta_Y = Z_Layer[0].Delta_Y-CYMIN;

    XB = Z_Fragment/Z_YBCNT;
    Zd_Delta_X -= XB*Z_XBSIZ;

    YB = Z_Fragment - XB*Z_YBCNT;
    Zd_Delta_Y -= YB*Z_YBSIZ;
    }
    continue;
    }
    Z_Check_Closure();

    PXMAX = PXMIN = ZLDCO0[0];
    PYMAX = PYMIN = ZLDCO1[0];

    for(I = 1; I<ZLDLIM; ++I)
    {
    if(PXMIN>ZLDCO0[I])PXMIN = ZLDCO0[I];
    if(PXMAX<ZLDCO0[I])PXMAX = ZLDCO0[I];
    if(PYMIN>ZLDCO1[I])PYMIN = ZLDCO1[I];
    if(PYMAX<ZLDCO1[I])PYMAX = ZLDCO1[I];
    }
    if(ZLDLIM<7)
    {
    IPOINT = IPOINT0;
    is_ipoint0 = 1;
    }
    else
    {
    Determine_Point_Base();
    IPOINT = IPOINT3;
    is_ipoint0 = 0;
    }
Total_IPoly += 1;

    if(PXMAX<=CXMIN)continue;
    if(PXMIN>=CXMAX)continue;
    if(PYMAX<=CYMIN)continue;
    if(PYMIN>=CYMAX)continue;

    I = 0;
    if(PYMIN<CYMIN||PYMAX>CYMAX)++I;
    if(PXMIN<CXMIN||PXMAX>CXMAX)++I;

    if(I)SPLIT_gVECTOR = SPLIT_gVECTOR_2;
    else SPLIT_gVECTOR = SPLIT_gVECTOR_1;

    if(I)ZXgCO0 = ZXgCO1, ZYgCO0 = ZYgCO1;
    else ZXgCO0 = ZXgCO2, ZYgCO0 = ZYgCO2;

    if(I)XgCNT = XgCNT_2, YgCNT = YgCNT_2;
    else XgCNT = XBCNT, YgCNT = YBCNT;

    Out_of_Bound = I;

    SPLIT_POLYGON();
    Z_Fragment = Zd_Fragment[0];
    }
  }
  void 
  Com_Line_Scan(short N, char*A[])
  {
    long I;
    long M;
    char D = 0;
    char L = 0;
    long J;
    long K;
    char ERR = 0;
    char S[100];
    for(I = 1; I<N; ++I)
    {
    for(K = 0; A[I][K]; ++K)
    if(islower(A[I][K])) A[I][K] = toupper(A[I][K]);

    M = A[I][1];

    if(A[I][0]=='-') /*OPTIONAL-PARAMETER*/
    {
    switch(M)
    {
    case 'D': /*OUTPUT TO DXB*/
    K = strlen(A[I]+2)+2;
    if(K>2)
    {
    for(J = 2; A[I][J]; ++J)
    if(!isdigit(A[I][J])&&!Isalpha(A[I][J]))break;
    if(A[I][J]){ ERR = 1; break; }

    ZALLOCATE((void**)&ERRNAM,  K+4);
    strncpy(ERRNAM, A[I]+2, K);
    strncat(ERRNAM, ".DXB", 5);
    }
    if(D) ERR = 2;
    D = 1;
    break;

    default: ERR = 1;
    }
    if(ERR) break;
    }
    /*End Switch*/
    else
    /*Layer Name*/
    {
    K = strlen(A[I]);
    if(!K||K>=20){ERR = 1; break;}

    for(J = 0; J<K; ++J)
    if(!isdigit(A[I][J])&&!Isalpha(A[I][J]))break;
    if(J<K){ERR = 1; break;}

    if(L){ERR = 3; break;}
    L = 1;
    strncpy(Z_Layer[0].Name, A[I], 20);
    }
    /*End Layer*/
    }
    /*End Parse*/
    if(ERR==3)
    fprintf(stderr, "\nOnly One Layer Can Be Processed");
    if(ERR==2)
    fprintf(stderr, "\nAmbiguous Parameter %s", A[I]);
    if(ERR==1)
    fprintf(stderr, "\nStrange Parameter %s", A[I]);
    ERR = L==0;
    if(ERR)
    zabort();

    Dxb_Output_Pleas = D;

    strncpy(O_Layer.Name, Z_Layer[0].Name, 20);

    if(ERRNAM==NULL)
    ERRNAM = "F-Ierr.dxb";
    
    return;
  }
  void
  Initial_Setup_3(void)
  {
    long Sz;

    PXCNT = 32;
    PYCNT = 32;
    PBLIM = PXCNT*PYCNT;
    ZPBCOR = malloc(PBLIM*2);

    LF_LIM = 64;

    ZPTAUX = malloc(1024*2);
    AUXMAX = 1024;

    Z_Layers_Cnt = 1;

    Find_ILayer();
    INIT_ILayer(&Z_Layer[0], 0);

    INIT_OLayer(&O_Layer);

    SET_Xg_Yg();

#ifdef __BORLANDC__
    Sz = coreleft() -20000;
#else
    Sz = LZ_S.EMSIZ*1024 + 300000L - gA_Core_Size;
#endif

    if(Sz<1024)zabort();
    Sz /= Z_LD_Sz + Z_LB_Sz + Z_LV_Sz + Z_VT_Sz + Z_PT_Sz + Z_gV_Sz;

    ZLDALLOC((long)(Sz*Z_LD_Wt));
    ZLBALLOC((long)(Sz*Z_LB_Wt));
    ZLVALLOC((long)(Sz*Z_LV_Wt));
    ZVTALLOC((long)(Sz*Z_VT_Wt));
    ZPTALLOC((long)(Sz*Z_PT_Wt));
    ZgVALLOC((long)(Sz*Z_gV_Wt));

    return;
  }
  void
  Initial_Setup_4(void)
  {
    free(ZPBCOR);
    free(ZPTAUX);
    free(ZXgCO1);
    free(ZYgCO1);
    free(ZgACO2);
    fclose(Z_Layer[0].File.Fil);
    free(Z_Layer[0].File.Buf);
    Dix_close();
    free(O_Layer.File.Buf);

    ZXXFREE((void***)LLDCOR);
    ZXXFREE((void***)ILBCOR);
    ZXXFREE((void***)CLBCOR);
    ZXXFREE((void***)ILVCOR);
    ZXXFREE((void***)IVTCOR);
    ZXXFREE((void***)CVTCOR);
    ZXXFREE((void***)LPTCOR);
    ZXXFREE((void***)IPTCOR);
    ZXXFREE((void***)IgVCOR);
  }
  void
  main(short Narguments, char*Arguments[])
  {
    if(Narguments<2)
    {
    fprintf(stderr, "\nCommand Line must be: F-init Layer\n");
    zabort();
    }
    Com_Line_Scan(Narguments, Arguments);

    Initial_Setup_1();
    Initial_Setup_2();
    Initial_Setup_3();

    fprintf(stderr, "\nDB-INIT FOR LAYER %s STARTED\n", Z_Layer[0].Name);

    SPLITPOLYGONS();
    ZLDLIM = 0, dontworry();
Dxb_Ld_Image_Maker(0, NULL);

    fprintf(stderr, "\nSPLIT FINISHED NORMALLY\n\n");
    Initial_Setup_4();

    strncpy(O_Layer.PdbN,
    mg_sort(O_Layer.PdbN), 15);

    renameoutput();
    if(LZ_S_Changed)zabort();

    fclose(LZ_S_FILE);
    fclose(LX_S_FILE);

    fprintf(stderr, "\nDB-INIT FINISHED NORMALLY");
    exit(0);
  }
