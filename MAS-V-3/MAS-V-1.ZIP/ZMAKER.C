#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include <IO.H>
#ifdef __BORLANDC__
#include<dir.h>
#else
#include<dos.h>
#endif
#include<math.h>
#include<CTYPE.H>
#include<STRING.H>
/**/
#ifdef __BORLANDC__
#include<VALUES.H>
#endif
/**/
#include<LIMITS.H>
#include<PROCESS.H>
/*
REDEFINITION OF MALLOC, CORELEFT.
*/
#ifndef DOS386
	#define malloc farmalloc
	#define calloc farcalloc
	#define free farfree
	#ifdef __ZTC__
		#define coreleft farcoreleft
	#endif
#else
	#define coreleft _x386_coreleft
#endif
  /**/
  #define CHAR unsigned char
  #define SHORT unsigned short
  /**/
  typedef struct
  {
  char Id_String[32];

  long Delta_X; /*In Units*/
  long Delta_Y; /*In Units*/
  } FP_Struct;
  typedef struct
  {
  long EMSIZ; /*In PAGES BY 1K*/
  long UN001; /*Units_Per_Micron*/
  long UN003; /*Delta Window In Units*/
  long CXMIN; /*In Units*/
  long CXMAX; /*In Units*/
  long CYMIN; /*In Units*/
  long CYMAX; /*In Units*/
  long XBSIZ; /*In Units*/
  long YBSIZ; /*In Units*/
  long XBCNT;
  long YBCNT;
  long LVCNT;
  long FiLID;
  char FileP[4];
  char Err1P[4];
  char PlotP[4];
  char TempP[4];
  } LZ_Struct;
  /**/
  typedef struct
  {
  long STATUS;

  long CXMIN;
  long CXMAX;
  long CYMIN;
  long CYMAX;

  long XBCNT;
  long YBCNT;
  long XBSIZ;
  long YBSIZ;

  long ER1I;
  long PLTI;
  long BDBI;
  long PDBI;
  } LX_Struct;
  typedef struct
  {
  FILE*Fil;
  char*Buf;
  long Buf_Len;
  long Buf_Pos;
  char Buf_Eof;
  } LF_Struct;
  typedef struct
  {
  long Fragment;

  LX_Struct LX_S;
  LF_Struct File;

  char Name[20];
  char PdbN[20];
  char BdbN[20];
  char Er1N[20];
  char PltN[20];

  long Delta_X;
  long Delta_Y;

  long Lcode;
  long Lmask;

  char Exist;

  FILE*ER1;
  FILE*ER2;
  } FX_Struct;

  LZ_Struct LZ_S;
  LX_Struct LX_S;

  FP_Struct FP_S = {"Mascot V2.0 Internal Storage\n", 0, 0};

  long FPOS_1 = sizeof(LZ_S)+sizeof(FP_S);
  long FPOS_2 = sizeof(FP_S);
  long FPOS_3;

  FILE*LZ_S_FILE;
  FILE*LX_S_FILE;
  char*LZ_S_NAME;
  char*LX_S_NAME;
  /**/
  void zabort(void)
  {
  fprintf(stderr, "\nFATAL!ERRORS WERE DETECTED");
  exit(1);
  }
  FILE*Fopen(char*Name, char*Mode)
  {
  FILE*File;
  File = fopen(Name, Mode);
  if(File==NULL)
  {
  fprintf(stderr, "\n\nFile %s Open ERROR\n", Name);
  zabort();
  }
  return(File);
  }
  void Make_File_Name(char*Sd, long Id)
  {
  long Ij;
  static char*Sp = "abcxzjps";

  sprintf(Sd, "%08ld", Id);

  for(Ij = 0; Sp[Ij]!=0; ++Ij)
  {
  if(Sd[Ij]== 0 )continue;
  if(Sd[Ij]=='0')Sd[Ij] = Sp[Ij];
  if(Sd[Ij]=='1')Sd[Ij] = 'e';
  }
  memcpy(Sd, LZ_S.FileP, 3);

  strncat(Sd, ".xzq", 5);
  }
  void Com_Line_Scan(long N, char*A[])
  {
    char S[100];
    long L;
    long I;
    long K;
    char D;
    char U;
    char W;
    char E;

    char ERR = 0;
    L = D = U = W = E = 0;

    for(I = 1; I<N; ++I)
    {
    for(K = 0; A[I][K]; ++K)
    if(islower(A[I][K])) A[I][K] = toupper(A[I][K]);

    if(A[I][0]=='-')
    switch(A[I][1])
    {
    case 'L': /*LV Count on One Block without EMS*/
	K = sscanf(&A[I][2], "%ld%s", &LZ_S.LVCNT, S);
	ERR = K!=1? 1: L? 2:0;
	L = 1;
	break;
    case 'U': /*Units Per Micron*/
	K = sscanf(&A[I][2], "%ld%s", &LZ_S.UN001, S);
	ERR = K!=1? 1: U? 2:0;
	U = 1;
	break;
    case 'E': /*Ems Size*/
	K = sscanf(&A[I][2], "%ld%s", &LZ_S.EMSIZ, S);
	ERR = K!=1? 1: E? 2:0;
	E = 1;
	break;
    case 'X': /*Xrange Yrange*/
	K = sscanf(&A[I][2], "%ld,%ldY%ld,%ld%s",
	&LZ_S.CXMIN, &LZ_S.CXMAX, &LZ_S.CYMIN, &LZ_S.CYMAX, S);
	ERR = K!=4? 1: W? 2:0;
	W = 1;
	break;
    case 'Y': /*Yrange Xrange*/
	K = sscanf(&A[I][2], "%ld,%ldX%ld,%ld%s",
	&LZ_S.CYMIN, &LZ_S.CYMAX, &LZ_S.CXMIN, &LZ_S.CXMAX, S);
	ERR = K!=4? 1: W? 2:0;
	W = 1;
	break;
    case 'D': /*Delta-Window*/
	K = sscanf(&A[I][2], "%ld%s", &LZ_S.UN003, S);
	ERR = K!=1? 1: D? 2:0;
	D = 1;
	break;
    default: ERR = 1;
    }
    else ERR = 1;
    if(ERR)break;
    }
    /*End LOOP*/
    if(ERR)
    {
    if(ERR==1)
    fprintf(stderr, "\n\nStrange Parameter %s\n", A[I]);
    else
    fprintf(stderr, "\n\nAmbiguous Parameter %s\n", A[I]);
    zabort();
    }
    if(L)
    {
	if(LZ_S.LVCNT<100||LZ_S.LVCNT>10000)
	{
	fprintf(stderr,
	"\n\nLV Count Can Be From 100 To 10000 items\n");
	zabort();
	}
    }
    if(E)
    {
	if(LZ_S.EMSIZ<300||LZ_S.EMSIZ>4000)
	{
	fprintf(stderr,
	"\n\nEms Size Can Be From 300 To 4000 PAGES by 1K\n");
	zabort();
	}
    }
    if(U)
    {
	if(LZ_S.UN001<1||LZ_S.UN001>10000)
	{
	fprintf(stderr,
	"\n\nUnits Per Micron Can Be From 1 To 10000\n");
	zabort();
	}
    }
    if(W)
    {
	LZ_S.CXMIN-= LZ_S.UN003;
	LZ_S.CXMAX+= LZ_S.UN003;
	LZ_S.CYMIN-= LZ_S.UN003;
	LZ_S.CYMAX+= LZ_S.UN003;
	LZ_S.UN003 = 0;
	if(LZ_S.CXMIN>=LZ_S.CXMAX||LZ_S.CYMIN>=LZ_S.CYMAX)
	{
	fprintf(stderr, "\n\nInvalid Boundary: X%ld,%ld Y%ld,%ld\n",
	LZ_S.CXMIN, LZ_S.CXMAX, LZ_S.CYMIN, LZ_S.CYMAX);
	zabort();
	}
    }
  }
void Delete_Files(char*Name)
{
	long done;
#ifdef __BORLANDC__
	struct ffblk ffblk;
	done = findfirst(Name, &ffblk, 0);
	while (!done)
	{
		if(unlink(ffblk.ff_name))
		fprintf(stderr, "\nFile %s Delete Error\n", ffblk.ff_name),
		zabort();
		else
		fprintf(stderr, "\nFile %s Deleted", ffblk.ff_name);

		done = findnext(&ffblk);
	}
#else
	struct find_t findt;
	done = _dos_findfirst(Name, 0, &findt);
	while (!done)
	{
		if(unlink(findt.name))
		fprintf(stderr, "\nFile %s Delete Error\n", findt.name),
		zabort();
		else
		fprintf(stderr, "\nFile %s Deleted", findt.name);

		done = _dos_findnext(&findt);
	}
#endif
}
  void main(int Narguments, char*Arguments[])
  {
    LZ_S.LVCNT = 2000;
#ifndef DOS386
    LZ_S.EMSIZ = 900;
#else
    LZ_S.EMSIZ = ((coreleft()-300000)/1024)-333;
    if(LZ_S.EMSIZ<300)LZ_S.EMSIZ=300;
#endif
    LZ_S.UN001 = 1;
    LZ_S.FiLID = 2;
    Com_Line_Scan(Narguments, Arguments);

    Delete_Files("M2$*.xzq");
    Delete_Files("M2$*.xzb");
    Delete_Files("M2$*.xzp");

    LZ_S_NAME = malloc(20);
    LX_S_NAME = malloc(20);

    memcpy(LZ_S.FileP, "M2$\n", 4);
    memcpy(LZ_S.Err1P, "E1$\n", 4);
    memcpy(LZ_S.PlotP, "PT$\n", 4);
    memcpy(LZ_S.TempP, "TM$\n", 4);

    Make_File_Name(LZ_S_NAME, 0);
    Make_File_Name(LX_S_NAME, 1);

    LZ_S_FILE = Fopen(LZ_S_NAME, "wb");
    LX_S_FILE = Fopen(LX_S_NAME, "wb");

    LZ_S.CXMIN*= LZ_S.UN001;
    LZ_S.CXMAX*= LZ_S.UN001;
    LZ_S.CYMIN*= LZ_S.UN001;
    LZ_S.CYMAX*= LZ_S.UN001;
    LZ_S.UN003*= LZ_S.UN001;

    fwrite(&FP_S, sizeof(FP_S), 1, LZ_S_FILE);
    fwrite(&FP_S, sizeof(FP_S), 1, LX_S_FILE);
    fwrite(&LZ_S, sizeof(LZ_S), 1, LZ_S_FILE);

    fclose(LZ_S_FILE);
    fclose(LX_S_FILE);

    exit(0);
  }
