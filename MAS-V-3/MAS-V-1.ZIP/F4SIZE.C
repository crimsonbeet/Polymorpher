  #define F_SIZE_MODULE
  /**/
  #include<DOS.H>
  #include<MATH.H>
  #include<STDIO.H>
  /**/
  #ifdef __BORLANDC__
  #include<DIR.H>
  #include<ALLOC.H>
  #endif
  /**/
  #include<STDLIB.H>
  #include<CTYPE.H>
  #include<STRING.H>
  /**/
  #ifdef __BORLANDC__
  #include<VALUES.H>
  #endif
  /**/
  #include<LIMITS.H>
  #include<PROCESS.H>
  /**/
  /*DXB-FORMAT-SECTION*/
  extern FILE*ERRFIL;
  extern char*ERRNAM;
  /**/
  extern FILE*Fopen(char*, char*);
  /**/
  extern double STSIZ;
  /**/
  extern long ZLDLIM;
  extern long*ZLDCO0;
  extern long*ZLDCO1;
  /**/
  void write_header(FILE*DXB)
  {
  char header[40];
  strncpy(header, "AutoCAD DXB 1.0\r\n\x1a", 40);
  fwrite(header, strlen(header)+1, 1, DXB);
  return;
  }
  void set_double(FILE*DXB)
  {
  unsigned char id;
  short mode;
  id = 135; /*ITEM-IS-NUMBER-MODE*/
  mode = 1; /*DOUBLE-MODE-FOLLOWS*/
  fwrite((char*)&id, 1, 1, DXB);
  fwrite((char*)&mode, 2, 1, DXB);
  }
  void write_pline
  (FILE*DXB, short closure)
  {
  struct
  {
  unsigned char id;
  short closure;
  } pline;
    pline.id = 19;
    pline.closure = closure;
    fwrite((char*)&pline, 3, 1, DXB);
  }
  void write_layer
  (FILE*DXB, char*layer)
  {
  unsigned char id;
  id = 129;
  fwrite((char*)&id, 1, 1, DXB);
  fwrite(layer, strlen(layer)+1, 1, DXB);
  }
  void write_vertex
  (FILE*DXB, long x, long y)
  {
  struct
  {
    unsigned char id;
    double dx, dy;
  } vertex;
    vertex.id = 20;
    vertex.dx = ((double)x * STSIZ) /1000.0;
    vertex.dy = ((double)y * STSIZ) /1000.0;
    fwrite((char*)&vertex, 17, 1, DXB);
  }
  void write_seqend
  (FILE*DXB)
  {
  unsigned char id;
  id = 17;
  fwrite((char*)&id, 1, 1, DXB);
  }
  void
  Dxb_Ld_Image_Maker
  (char closure, char*s)
  {
    static char*N;
    long L;
    unsigned char id;
    if(ZLDLIM==0)
    {
    id = 0;
    if(ERRFIL) fwrite((char*)&id, 1, 1, ERRFIL), fclose(ERRFIL);
    return;
    }
    if(ZLDLIM<=1) return;
    if(!ERRFIL)
    {
    if(!strlen(ERRNAM))
    ERRNAM = "F-Serr.dxb";
    ERRFIL = Fopen(ERRNAM, "wb");
    write_header(ERRFIL);
    set_double(ERRFIL);
    N = s;
    if(s) write_layer(ERRFIL, s);
    }
    if((N!=s)&&s)
    {
    write_layer(ERRFIL, s);
    N = s;
    }
    write_pline(ERRFIL, (short)closure);

    for(L = 0; L<ZLDLIM; ++L)
    {
    write_vertex(ERRFIL, ZLDCO0[L], ZLDCO1[L]);
    }
    write_seqend(ERRFIL);
  }
