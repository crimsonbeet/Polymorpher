  #define F_INIT_MODULE
  /**/
  #include<DOS.H>
  #include<MATH.H>
  #include<STDIO.H>
  /**/
  #ifdef __BORLANDC__
  #include<DIR.H>
  #include<ALLOC.H>
  #endif
  /**/
  #include<STDLIB.H>
  #include<CTYPE.H>
  #include<STRING.H>
  /**/
  #ifdef __BORLANDC__
  #include<VALUES.H>
  #endif
  /**/
  #include<LIMITS.H>
  #include<PROCESS.H>
  /**/
  #ifndef DOS386
  #define malloc farmalloc
  #define free farfree
  #endif
  /**/
#ifndef __BORLANDC__
#define huge
#define far
#endif
  /**/
  typedef struct
  {
  char Id_String[32];

  long Delta_X; /*In Units*/
  long Delta_Y; /*In Units*/
  } FP_Struct;
  extern FP_Struct FP_S;
  /**/
  extern long EMSIZ;
  FILE*Fopen(char*Name, char*Mode);
/*-----------------------------------------*/
  #define zSnum 7
  #define zswab(n,m,w) ((w)=chnl[(n)], chnl[(n)]=chnl[(m)], chnl[(m)]=(w))
  #define gt(A,B) ((A)>(B))
  #define ge(A,B) ((A)>=(B))
/*-----------------------------------------*/
  struct sequence
  {
    char nam[15];
    long eof;
    long zfa;
    long zfd;
    long bfs;
    long pos;
    long run;
    long ele;
    long gbl;
    long len;
    char huge*buf;
    FILE*fil;
  };
  struct SEQUENCE
  {
    char nam[15];
    long eof;
    long bfs;
    long run;
    long pos;
    long cnt;
    long ele;
    long gbl;
    long LPP;
    long LNS;
    long QBL;
    FILE*fil;
    long huge*buf;
  } SQ;
/*--------------------------------------*/
  struct sequence f[zSnum];
/*--------------------------------------*/
  long*chnl; /* INDEX OF PLINE */
  long cmax;
  long BMAX;
  void zAbort(void)
  {
  int i;
    if(SQ.fil != NULL)
    {
    fclose(SQ.fil);
    unlink(SQ.nam);
    }
    for(i = 0; i <= zSnum-1; ++i)
    {
    if(f[i].fil != NULL) fclose(f[i].fil);
    unlink(f[i].nam);
    }
    fprintf(stderr, "\nFATAL!EXITING BY ERRORS");
    exit(1);
  }
#ifdef __BORLANDC__
  char*XXALLOC(long l)
  {
  char*p;
    p = farmalloc(l);
    if(!p)fprintf(stderr, "FAILED DUE TO INIT WORK BUFFER\r\n"), zAbort();
    return(p);
  }
  void ZIBUFER(void)
  {
  long bmax; bmax = coreleft();
  
    chnl = (long far*)XXALLOC((cmax = 15000l)*4l);    
    bmax -= cmax*4l+10000L;
    
#ifdef Huge_Pointer_not_allowed
    if(bmax>0XFFFFL) bmax = 0XFFFFL;
#endif

    SQ.buf = (long huge*)XXALLOC(bmax);
    SQ.bfs = (bmax/4)-1;
  }
  void
  destroybufer(void)
  {
    farfree((long far*)chnl);

    farfree((long far*)SQ.buf);
    cmax = SQ.bfs = 0;
    chnl = NULL;
    SQ.buf = NULL;
  }
#else
  char*XXALLOC(long l)
  {
  char*p;
    p = malloc(l);
    if(!p)fprintf(stderr, "FAILED DUE TO INIT WORK BUFFER\r\n"), zAbort();
    return(p);
  }
  void
  ZIBUFER(void)
  {
    long bmax;
    bmax = (100000l+EMSIZ*1024)/4;
    cmax = bmax/7-1;
    chnl = (long*)XXALLOC(cmax*4);

    bmax = bmax-cmax;
    SQ.buf = (long*)XXALLOC(bmax*4);
    SQ.bfs = bmax-1;
  }
  void
  destroybufer(void)
  {
    free(chnl);
    free(SQ.buf);
    cmax = SQ.bfs = 0;
    chnl = SQ.buf = 0;
  }
#endif
  void
  z_close(struct sequence *s)
  {
  long err;
    s->eof = 1;
    if(s->fil!=NULL)
    {
    err = fclose(s->fil);
    s->fil = NULL;

    if(err)zAbort();
    }
  }
  void
  put_next(struct sequence *s, char *b, long l)
  {
    if(s->pos+l>=s->bfs)
    {
      char huge*buf;
      long len;

      buf = s->buf;
      while(s->pos)
      {
      if(s->pos>/*0X7FFFL*/512) len = /*0X7FFFL*/512;
      else len = s->pos;

      fwrite((char far*)buf, 1, len, s->fil);
      s->pos -= len;
      buf += len;
      }
      s->pos = 0;
      if(ferror(s->fil))zAbort();
    }
    memcpy(&s->buf[s->pos], b, l);
    s->pos += l;
  }
  void
  Set_Next(struct sequence *s)
  {
    if(++s->pos>=s->bfs)
    {
    long len;
    long bfs;
    long LEN;
    long BFS;
    char huge*buf;

    len = s->bfs;
    buf = s->buf;

    buf[bfs = 0] = 0;

    while(len)
    {
    if(len>/*0X7FFFL*/512) LEN = /*0X7FFFL*/512;
    else LEN = len;

    BFS  = fread((char far*)buf, 1, LEN, s->fil);
    if(BFS<=0) break;

    bfs += BFS;
    buf += LEN;
    len -= LEN;
    }
    s->bfs = bfs;
    s->eof = s->bfs<=0;
    s->pos = 0;
    if(ferror(s->fil))zAbort();
    }
  }
  void
  set_next(struct sequence *s, char*b, long l)
  {
    if(s->pos+l>=s->bfs)
    {
    long i;
    for(i = 0; i<l; ++i)
    {
    b[i] = s->buf[s->pos];
    Set_Next(s);
    }
    }
    else if(l)
    {
    memcpy(b, &s->buf[s->pos], l);
    s->pos += l;
    }
  }
  void
  pospoly(struct sequence *s)
  {
    if(s->eof) return;

    while(s->buf[s->pos]==0)
    {
      long l;

      Set_Next(s);
      l = (long)s->buf[s->pos];
      Set_Next(s);

      if(s->eof) break;

      s->gbl = 0;
      set_next(s, (char*)&s->gbl, l);
    }
    s->eof = 0;
  }
  void
  zsmove(struct sequence *d, struct sequence *s)
  {
    long D;
    long Z;
    if(d->gbl!=s->gbl)
    {
      D = 0;
      put_next(d, (char*)&D, 1);

      Z = d->gbl = s->gbl;
      if(d->gbl<(0XFFL+1))          D = 1;
      else if(d->gbl<(0XFFFFL+1))   D = 2;
      else if(d->gbl<(0XFFFFFFL+1)) D = 3;
      else                          D = 4;

      put_next(d, (char*)&D, 1);
      put_next(d, (char*)&Z, D);
    }
    D = (long)s->buf[s->pos];
    Set_Next(s);

    if(s->eof) return;

    while(D!=0)
    {
      put_next(d, (char*)&D, 1);
      D &= 07;

      set_next(s, (char*)&Z, D);
      put_next(d, (char*)&Z, D);

      D = (long)s->buf[s->pos];
      Set_Next(s);
    }
    put_next(d, (char*)&D, 1);
    d->ele+= 1;

    pospoly(s);
  }
  void
  unload_buf(struct sequence *s)
  {
    if(s->pos>0)
    {
      char huge*buf;
      long len;

      buf = s->buf;
      while(s->pos)
      {
	if(s->pos>/*0X7FFFL*/512) len = /*0X7FFFL*/512;
	else len = s->pos;
	fwrite((char far*)buf, 1, len, s->fil);
	s->pos -= len;
	buf += len;
      }
      s->pos = 0;
      if(ferror(s->fil))zAbort();
    }
  }
  void
  startread(struct sequence *s)
  {
    z_close(s);
    s->fil = Fopen(s->nam, "rb");

    fread(&FP_S, sizeof(FP_S), 1, s->fil);

    s->ele = 0;
    s->gbl = 0;

    s->pos = s->bfs;
    Set_Next(s);

    pospoly(s);
  }
  void
  startwrite(struct sequence *s)
  {
    if(s->fil!=NULL) fclose (s->fil);
    s->fil = Fopen(s->nam, "wb");

    fwrite(&FP_S, sizeof(FP_S), 1, s->fil);

    s->eof = 1;
    s->run = 0;
    s->ele = 0;
    s->gbl =-1;

    s->bfs = BMAX;
  }
  void
  quicksort(long sl, long sr)
  {
  long k, j;
  static long w, x;
    if(sr-sl < 20) while(sl<sr)
    {
      for(j=sr, k=sr; sl<j; j--)
      if(gt(SQ.buf[chnl[j-1]], SQ.buf[chnl[j]]))
      {
	x = chnl[j];
	do (chnl[j] = chnl[j-1]), j--;
	while(sl<j && gt(SQ.buf[chnl[j-1]], SQ.buf[x]));
	chnl[j] = x;
	k = j;
      }
      sl = k+1;
      for(j =sl; j<sr; j++)
      if(gt(SQ.buf[chnl[j]], SQ.buf[chnl[j+1]]))
      {
	x = chnl[j];
	do (chnl[j] = chnl[j+1]), j++;
	while(j<sr && gt(SQ.buf[x], SQ.buf[chnl[j+1]]));
	chnl[j] = x;
	k = j;
      }
      sr = k-1;
    }
    else
    {
      x = (sl + sr)/2 ;
      if(gt (SQ.buf[chnl[sl]], SQ.buf[chnl[x]])) zswab (sl, x, w);
      if(gt (SQ.buf[chnl[x]], SQ.buf[chnl[sr]])) zswab (sr, x, w);
      if(gt (SQ.buf[chnl[sl]], SQ.buf[chnl[x]])) zswab (sl, x, w);
      x = chnl[x];
      for(k =sl+1, j =sr-1; k < j;)
      {
	while(gt (SQ.buf[x], SQ.buf[chnl[k]])) k += 1;
	while(gt (SQ.buf[chnl[j]], SQ.buf[x])) j -= 1;
	if(k<j)
	{
	  zswab (k, j, w);
	  k++; j--;
	}
      }
      if(sl<j) quicksort(sl, j);
      if(k<sr) quicksort(k, sr);
    }
  }
  void
  ReadPolygon(void)
  {
    char far * B;
    long P;
    long L;
    long Z = 0;
    fread(&Z, 1, 1, SQ.fil);

    if(feof(SQ.fil))return;

    while(!Z)
    {
    fread(&Z, 1, 1, SQ.fil);

    SQ.gbl = 0;
    fread(&SQ.gbl, 1, Z, SQ.fil);

    Z = 0;
    fread(&Z, 1, 1, SQ.fil);

    if(feof(SQ.fil))return;
    }
    chnl[SQ.cnt++] = SQ.pos;
    SQ.LPP = SQ.pos;

    SQ.buf[SQ.pos++] = SQ.gbl;

    P = 0;
    L = (SQ.bfs-(SQ.pos+1))*4 - 1;
    B = (char far*)(SQ.buf+SQ.pos+1);

    while(Z)
    {
    B[P++] = Z;

    Z &= 7;
    if(P+Z>=L)
    {
    SQ.pos = SQ.bfs;
    SQ.LNS = P;
    return;
    }
    fread(&B[P], 1, Z, SQ.fil);
    P+= Z;
    Z = 0;
    fread(&Z, 1, 1, SQ.fil);
    }
    B[P++] = 0;

    SQ.buf[SQ.pos++] = P;

    SQ.pos += P/4;
    if(P%4)SQ.pos++;

    if(ferror(SQ.fil))zAbort();
  }
  void
  READRUN(void)
  {
    char end = 0;

    SQ.eof = 1;
    SQ.pos = 0;
    SQ.cnt = 0;
    SQ.LNS =-1;
    do
    {
    ReadPolygon();
    end = (SQ.pos+3>=SQ.bfs);
    }
    while(!feof(SQ.fil)&&!end&&SQ.cnt<cmax);

    if(SQ.cnt>1)
fprintf(stderr, "1 QUICKSORT STARTED ON %6ld ELEMENTS\r\n", SQ.cnt),
    quicksort(0, SQ.cnt-1);

    SQ.eof = SQ.pos<1;
    SQ.QBL = SQ.buf[chnl[0]];
    if(!SQ.eof) SQ.ele += SQ.cnt;
    if(ferror(SQ.fil))zAbort();
  }
  void STARTREAD(void)
  {
    SQ.gbl = 0;
    SQ.ele = 0;
    SQ.run = 0;
    SQ.fil = Fopen(SQ.nam, "rb");

    fread(&FP_S, sizeof(FP_S), 1, SQ.fil);

    ZIBUFER();
    READRUN();
  }
  void
  ZSMOVE(struct sequence *s, long i)
  {
    long p;
    long d;
    char z;
    char far * c;
    p = chnl[i];

    if(s->gbl!=SQ.buf[p])
    {
    d = 0;
    fwrite(&d, 1, 1, s->fil);

    s->gbl = SQ.buf[p];
    if(s->gbl<(0XFFL+1))          d = 1;
    else if(s->gbl<(0XFFFFL+1))   d = 2;
    else if(s->gbl<(0XFFFFFFL+1)) d = 3;
    else                          d = 4;

    fwrite(&d, 1, 1, s->fil);
    fwrite(&s->gbl, 1, (size_t)d, s->fil);
    }
    c = (char far*)(SQ.buf+p+2);

    s->ele +=1;

    if(p==SQ.LPP)
    if(SQ.LNS>=0)
    {
    fwrite(c, 1, SQ.LNS, s->fil);

    d = 0;
    d = c[SQ.LNS-1];

    while(d)
    {
    z = d & 07;
    fread(&d, 1, z, SQ.fil);
    fwrite(&d, 1, z, s->fil);
    d = 0;
    fread(&d, 1, 1, SQ.fil);
    fwrite(&d, 1, 1, s->fil);
    }
    return;
    }
    d = SQ.buf[p+1];
    fwrite(c, 1, (size_t)d, s->fil);
  }
  void copyrun(struct sequence *s)
  {
  long i = 0;
    while(i<SQ.cnt) ZSMOVE(s, i++);

    READRUN();
  }
  long
  polysort(long N)
  {
  long level =1;
  int i, j;
    for(i = 0; i <N; ++i)
    f[i].zfa = f[i].zfd = 1;
    f[N].zfa = f[N].zfd = 0;

    FP_S.Delta_X = 0;
    FP_S.Delta_Y = 0;
    for(i = 0; i <N; ++i)startwrite(f+i);
    STARTREAD();
    for(i = 0; i <N && !SQ.eof; ++i)
    {
      copyrun(f+i);
      while(!SQ.eof && ge(SQ.QBL, f[i].gbl)) copyrun(f+i);
      SQ.run += 1;
      f[i].zfd -= 1;
      f[i].run += 1;
    }
fprintf(stderr, "0 RUNS %6ld ELEMENTS %6ld\r\n", SQ.run, SQ.ele);
    if(!SQ.eof)
    {
      level += 1;
      for(i = 0; i <N; ++i) (f[i].zfd = 1), f[i].zfa = 2;
      f[N-1].zfd -= 1;
      f[N-1].zfa -= 1;
    }
    for(j = 0; !SQ.eof;)
    {
      if(f[j].zfd < f[j+1].zfd) ++j;
      else
      {
	if(f[j].zfd == 0)
	{
	long z = f[0].zfa;
	  level += 1;
	  for(i = 0; i < N; ++i)
	  {
	    f[i].zfd = z + f[i+1].zfa - f[i].zfa;
	    f[i].zfa = z + f[i+1].zfa;
	  }
	}
	j = 0;
      }
      if(ge(SQ.QBL, f[j].gbl))
      {
	copyrun(f+j);
	while(!SQ.eof && ge(SQ.QBL, f[j].gbl)) copyrun(f+j);
      }
      if(!SQ.eof)
      {
	copyrun(f+j);
	while(!SQ.eof && ge(SQ.QBL, f[j].gbl)) copyrun(f+j);
	f[j].zfd -= 1;
	f[j].run += 1;
	SQ.run += 1;
      }
fprintf(stderr, "0 RUNS %6ld ELEMENTS %6ld\r\n", SQ.run, SQ.ele);
    }
    fclose(SQ.fil);
    unlink(SQ.nam); SQ.fil = NULL;

    destroybufer();
    for(i = 0; i <= N; i++)z_close(f+i);
/* MERGE RUNS FROM SEQUENCES */
    {
    int t[zSnum+1], a[zSnum+1];
    long bmax;
#ifdef __BORLANDC__
      bmax = coreleft()-20000-((N+1)*1000L);
#else
      bmax = 250000+EMSIZ*1024-((N+1)*1000L);
#endif
      bmax = bmax/(N+1);
#ifdef Huge_Pointer_not_allowed
      if(bmax>=0xFFFFL)bmax = 0xFFFFL;
#endif
      for(i = 0; i <=N; ++i)
      {
	f[i].bfs = bmax-1;
	f[i].buf = (char huge*)XXALLOC(bmax);
      }
      BMAX = bmax-1;
      for(i = 0; i <=N; ++i) t[i] = i;
      if(SQ.run >1)
      for(i = 0; i <N; ++i)startread(f+i);
      if(SQ.run >1) while(level)
      {
      int k = -1;
      long z = f[t[N-1]].zfa;
	f[t[N]].zfd = 0;
	startwrite(f+t[N]);
	while(z != 0)
	{
	  for(i = 0; i <N; ++i)
	  {
	    if(f[t[i]].zfd > 0) --f[t[i]].zfd;
	    else a[++k] = t[i];
	  }
	  if(k == -1) ++f[t[N]].zfd;
	  else
	  {
	  int m;
	    while(k != -1)
	    {
	      for(i=1, m=0; i<=k; ++i) if(f[a[m]].gbl>f[a[i]].gbl) m =i;
	      zsmove(f+t[N], f+a[m]);
	      if(f[a[m]].eof || gt(f[t[N]].gbl, f[a[m]].gbl))
	      {
		f[a[m]].run -= 1;
		a[m] = a[k];
		k -= 1;
	      }
	    }
	    f[t[N]].run += 1;
	  }
	  z -= 1;
	}
	unload_buf(f+t[N]);
	if(level!=1)
	startread(f+t[N]);
	{
	int tn = t[N], dn = f[t[N]].zfd;
	  for(i = N, z = f[t[N-1]].zfa; i > 0; --i)
	  {
	    t[i] = t[i-1];
	    f[t[i]].zfa -= z;
	  }
	  t[0] = tn;
	  f[tn].zfd = dn;
	  f[tn].zfa = z;
	}
fprintf(stderr, "0 LEVEL %ld COMPLETED\r\n", level);
	level -= 1;
      } /*END-FOR-EACH-LEVEL*/
fprintf(stderr, "TOTAL %ld ELEMENTS SORTED\n", f[t[0]].ele);
      unload_buf(f+t[0]);
      for(i = 0; i <= N; i++)z_close(f+i);

      for(i = 0; i <=N; ++i)
      {
	f[i].bfs = 0;
#ifdef __BORLANDC__
	farfree(f[i].buf);
#else
	free(f[i].buf);
#endif
      }
      return(t[0]);
    } /*END-OF-MERGE*/
  }
  char*
  mg_sort(char*fnam)
  {
    long i;
    long k;
    SQ.fil = NULL;
    SQ.buf = chnl = NULL;
    strncpy(SQ.nam, fnam, 15);
    for(i = 0; i<zSnum; ++i)
    {
    sprintf(f[i].nam, "$TMP%d", i);
    f[i].fil = NULL;
    }
    k = polysort(zSnum-1);
fprintf(stderr, "DELETING TEMP-FILES\n");
    for(i = 0; i<zSnum; ++i)
    {
    if(i!=k)
    unlink(f[i].nam),
    f[i].fil = NULL;
    }
    fprintf(stderr, "\nSORT FINISHED NORMALLY\n");
    return(f[k].nam);
  }
