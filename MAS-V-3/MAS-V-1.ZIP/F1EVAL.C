  #define F_EVAL_MODULE
  /**/
  #include<DOS.H>
  #include<MATH.H>
  #include<STDIO.H>
  /**/
  #ifdef __BORLANDC__
  #include<DIR.H>
  #include<ALLOC.H>
  #endif
  /**/
  #include<STDLIB.H>
  #include<CTYPE.H>
  /**/
  #include<STRING.H>
  #ifndef stricmp
  #define stricmp strcmp
  #endif
  /**/
  #ifdef __BORLANDC__
  #include<VALUES.H>
  #else
  #include<FLOAT.H>
  #endif
  /**/
  #include<LIMITS.H>
  #include<PROCESS.H>
  /**/
  #ifndef DOS386
  #define malloc farmalloc
  #define free farfree
  #endif
  /**/
  #include"F0EVAL.C"
