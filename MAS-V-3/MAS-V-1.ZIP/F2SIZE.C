  #define F_SIZE_MODULE
  /**/
  #include<DOS.H>
  #include<MATH.H>
  #include<STDIO.H>
  /**/
  #ifdef __BORLANDC__
  #include<DIR.H>
  #include<ALLOC.H>
  #endif
  /**/
  #include<STDLIB.H>
  #include<CTYPE.H>
  #include<STRING.H>
  /**/
  #ifdef __BORLANDC__
  #include<VALUES.H>
  #endif
  /**/
  #include<LIMITS.H>
  #include<PROCESS.H>
  /**/
  #include "F0EVAL.H"
  /**/
  extern long Delta_X_2;
  extern long Delta_Y_2;
  /**/
  extern char Dix_Rewrite_FP_S;
  extern long Total_Collar;
  extern long Total_Shapes;
  extern char B_S_Lv_Only;
  extern long DIX_OpenS;

  extern long*PLDCO0;
  extern long*PLDCO1;
  extern long PLDLIM;
  extern long PLDMAX;

  extern double Size_Width;

  double NXFROM;
  double NYFROM;
  double XELBOW;
  double YELBOW;

  double X_C[9];
  double Y_C[9];

  char F_C;
  char F_C_OLD;
  char S_C_F_S;

  char Lead_In_Exists;

  char NO_CONT_1;
  char NO_CONT_2;
  long
  PLDNEXT(void);
  void
  Dxb_Ld_Image_Maker
  (char, char*);
  void
  Print_Normal_Finish(void);
  void
  ZDREAD_P(void);
  long
  Back_Scale_0(void);
  void
  Spline_Polygon(long LB)
  {
  long LE;
  long LV;
  long LN;

  double A1;
  double A2;

  /*Only After Force_C_Polygonc and*/
  /*Dummyjunctionanalysis an S_FACTOR!=0.*/

  LE = ZLBCO3[LB];
  LN = ZLVCO1[LE];

  LV = LE;

  A1 = COMPLVANGLE(LV);
  do
  {
  A2 = COMPLVANGLE(LN);

  if(ENVEQ(A1, A2, 0.1))
  {
  B_S_Lv_Only = 1;

  REMOVE_FROM_VT_CHAIN(LN);
  REMOVE_FROM_VT_CHAIN(LV);

  ZLVCO7[LN] = 0;
  ZLVCO2[LV] = 0;

  ZLBCO3[LB] = LV;

  ZLVCO6[LV] = ZLVCO6[LN];
  ZLVCO1[LV] = ZLVCO1[LN];

  A1 = COMPLVANGLE(LV);

  if(LN==LE)return;
  }
  else LV = LN, A1 = A2;
  LN = ZLVCO1[LV];
  }
  while(LV!=LE);
  }
  void
  OV_EL_SEGMENTS(void)
  {
  long I;
  long K;
  ZVTLIM = 2;

  INTERSECTION_ANALYSIS();
  POINT_VECTOR_ANALYSIS(2);

  for(I = 1; I<ZLBLIM; ++I)
  {
  if(ZLBCO3[I])
  DUMMYJUNCTIONANALYSIS(I);
  }
  if(Lead_In_Exists)
  {
  K = 2;
  True_Stat = AND_NOT;

  POINT_VECTOR_CLASS(1, 8, 8);
  }
  else K = 1;

  for(I = K; I<ZLBLIM; ++I)
  {
  if(ZLBCO3[I])ZZ_SET_RSTAT(I);
  }
  FORCE_C_POLYGONS();

  K = !Lead_In_Exists&&Without_Scale;

  if(K)K = ZLBLIM;
  else K = 1;

  for(I = K; I<ZLBLIM; ++I)
  {
  if(ZLBCO3[I])
  DUMMYJUNCTIONANALYSIS(I);
  }
  B_S_Lv_Only = 0;

  if(Lead_In_Exists)
  for(I = 1; I<ZLBLIM; ++I)
  {
  if(ZLBCO3[I])
  Spline_Polygon(I);
  }
  True_Stat = O_R;
  Lead_In_Exists = 0;
  }
  void
  dontworry_2(void)
  {
  long T;
  T = ZLDLIM? ++Total_Collar: 17;

  if(!(T-(T/17)*17))
  fprintf(stderr, "\rINPUT: KBYTES=%ld, SHAPES=%ld; OUTPUT: COLLARS=%ld;",
  ZZ_RP_KB/1024, Total_Shapes, Total_Collar);
  }
  void
  ZZ_Collar_Output(void)
  {
  long I;
  long J;
  Total_Shapes += 1;

  if(Lead_In_Exists)J = 2;
  else J = 1;

  for(I = J; I<ZLBLIM; ++I)
  {
  if(ZLBCO3[I]==0)continue;

  Unload_Lv_Polygon(I);
  if(!STATUS)continue;

  for(J = 0; J<ZLDLIM; ++J)
  {
  ZLDCO0[J] += Delta_X_2;
  ZLDCO1[J] += Delta_Y_2;
  }
  DIX_OpenS = Z_Open_Shape;
  Dix_output();

  Dxb_Ld_Image_Maker(1, NULL);
  dontworry_2();
  }
  }
  void
  ZZ_Read_Shape(void)
  {
  long*zldco0 = ZLDCO0;
  long*zldco1 = ZLDCO1;

  ZLDCO0 = PLDCO0+1;
  ZLDCO1 = PLDCO1+1;

  ZDREAD_P();

  if(ZLDLIM)
  if(!Z_Open_Shape)Z_Check_Closure();

  PLDLIM = ZLDLIM+1;

  ZLDCO0 = zldco0;
  ZLDCO1 = zldco1;
  }
  double
  DEFINE_CSLOPE(long K, long I, long J)
  {
  double X;
  double Y;
  double A;
  X = PLDCO0[J]-PLDCO0[I];
  Y = PLDCO1[J]-PLDCO1[I];
  A = Eval_Angle(X, Y);
  X = PLDCO0[K]-PLDCO0[I];
  Y = PLDCO1[K]-PLDCO1[I];
  A = A + 360-Eval_Angle(X, Y);
  if(A>360) A-=360;
  return(A);
  }
  long
  SPLINE_TYPE(double A)
  {
  long T;
  if(ENVEQ(A, 180, 0.1)) T = 0;
  else
  if(A<=245) T =+1;
  else
  if(ENVEQ(A, 360, 5.0)) T = 2;
  else T = 3;
  return(T);
  }
  void
  DEFINE_DISPLACE(long I, long K, double*X, double*Y)
  {
  X[0] = X[2]*Size_Width+PLDCO0[I];
  Y[0] = Y[2]*Size_Width+PLDCO1[I];
  X[1] = X[2]*Size_Width+PLDCO0[K];
  Y[1] = Y[2]*Size_Width+PLDCO1[K];
  }
  void DEFINE_NORMALFROM(long I, long K)
  {
  double SZ;
  double DX;
  double DY;
  double NX;
  double NY;
  DX = PLDCO0[K]-PLDCO0[I];
  DY = PLDCO1[K]-PLDCO1[I];
  NX =+DY;
  NY =-DX;
  SZ = sqrt(DX*DX+DY*DY);
  NX = NX/SZ;
  NY = NY/SZ;
  NXFROM = NX;
  NYFROM = NY;
  }
  char
  DEFINE_INTERSECTION
  (double*X1, double*Y1, double*X2, double*Y2, double*X, double*Y)
  {
  double DL, A1, B1, C1, A2, B2, C2;
  A1 = Y1[0]-Y1[1];
  B1 = X1[1]-X1[0];
  C1 = X1[0]*Y1[1]-X1[1]*Y1[0];

  A2 = Y2[0]-Y2[1];
  B2 = X2[1]-X2[0];
  C2 = X2[0]*Y2[1]-X2[1]*Y2[0];

  DL = A1*B2 - B1*A2;
  if(ENVEQ(DL, 0, 1E-7))return(0);

  X[0] = (B1*C2-B2*C1)/DL;
  Y[0] = (A2*C1-A1*C2)/DL;
  if(X[0]>LONG_MAX||Y[0]>LONG_MAX)return(0);
  return(1);
  }
  void
  DEFINE_ELBOW
  (double*X1, double*Y1, long I)
  {
  X1[5] = XELBOW + PLDCO0[I];
  Y1[5] = YELBOW + PLDCO1[I];
  X1[6] = PLDCO0[I] - XELBOW;
  Y1[6] = PLDCO1[I] - YELBOW;
  }
  long
  POINTONSEGMENT
  (double*X1, double*Y1, double X, double Y)
  {
  double XMIN, YMIN, XMAX, YMAX;
  XMIN = X1[1];
  YMIN = Y1[1];
  if(XMIN>X1[0]) XMAX = XMIN, XMIN = X1[0];
  else XMAX = X1[0];
  if(YMIN>Y1[0]) YMAX = YMIN, YMIN = Y1[0];
  else YMAX = Y1[0];
  XMIN -= 0.5;
  XMAX += 0.5;
  YMIN -= 0.5;
  YMAX += 0.5;
  return((X>=XMIN&&X<=XMAX)&&(Y>=YMIN&&Y<=YMAX));
  }
  void Unl_ToIntlayStandart(void)
  {
    long I;
    long J;

    J = ZLDLIM;
    if(J==0)return;

    while(J--)
    {
    I = ZLDNEXT();
    ZLDCO0[I] = ZLDCO2[J];
    ZLDCO1[I] = ZLDCO3[J];
    }
    STATUS = 1;

    Z_Check_Closure();
    Z_FEval_Storage();
  }
  void UNL_TOINTLAYSTANDART(double*X, double*Y)
  {
    long J;
    long I;
    long s;

    long*Zldco0 = ZLDCO0;
    long*Zldco1 = ZLDCO1;
    long Zldlim = ZLDLIM;

    long x[5];
    long y[5];

    long *X0 = ZLDCO0;
    long *X1 = ZLDCO2;
    long *Y0 = ZLDCO1;
    long *Y1 = ZLDCO3;

    s = 1L<<S_FACTOR;

    ZLDCO0 = x;
    ZLDCO1 = y;
    ZLDLIM = 0;
    for(J = 4; J<9; ++J)
    {
    I = ZLDNEXT();
    x[I] = floor(X[J]*s+0.5);
    y[I] = floor(Y[J]*s+0.5);
    }
    J = DETERMINE_STAT_1();

    if(J==0)
    {
    DEFINE_INTERSECTION(X+5, Y+5, X+7, Y+7, X, Y);
    x[2] = floor(X[0]*s+0.5);
    y[2] = floor(Y[0]*s+0.5);
    x[3] = x[2];
    y[3] = y[2];

    J = DETERMINE_STAT_1();
    }
    ZLDLIM = Zldlim;
    ZLDCO0 = Zldco0;
    ZLDCO1 = Zldco1;

    if(J!=0)
    {
    if(J!=1)
    {
    long *X2 = X0;
    long *Y2 = Y0;
    X0 = X1, X1 = X2;
    Y0 = Y1, Y1 = Y2;
    }
    if(ZLDLIM!=0)
    {
    I = ZLDLIM-1;
    J = X0[I]!=x[0]||X1[I]!=x[3]||Y0[I]!=y[0]||Y1[I]!=y[3];

    if(J||NO_CONT_2)
    Unl_ToIntlayStandart(), ZLDLIM = 0;
    }
    if(ZLDLIM==0)
    {
    I = ZLDNEXT();

    X0[I] = x[0];
    X1[I] = x[3];
    Y0[I] = y[0];
    Y1[I] = y[3];
    }
    I = ZLDNEXT();

    X0[I] = x[1];
    X1[I] = x[2];
    Y0[I] = y[1];
    Y1[I] = y[2];

    STATUS = 0;
    }
  }
  void
  Dswab(double*A, double*B)
  {
  double T = *A; *A = *B, *B = T;
  }
  void
  DEFINE_SEGMENT(char S, long J, long I, long K)
  {
  double IX, IY, X1[9], X2[3], Y1[9], Y2[3], CAN, MAN;
  /*[0]-FIRST-DISPLACE-POINT!*/
  /*[1]-SECOND-DISP-POINT!*/
  /*[2]-NORMAL*/

  static double CAN_OLD;

  long SW0, SW1, SW2, SW3, SPT;/*SPECIAL-FLAGS*/

  static long SW4;
    NO_CONT_1 = 0;
    if(S==0)CAN_OLD = 0;

    X1[2] = NXFROM;
    Y1[2] = NYFROM;
    DEFINE_NORMALFROM(I, K);
    X2[2] = NXFROM;
    Y2[2] = NYFROM;
    CAN = DEFINE_CSLOPE(J, I, K);
    if(CAN<180)
    {
    X1[2] =-X1[2], Y1[2] =-Y1[2];
    X2[2] =-X2[2], Y2[2] =-Y2[2];

    XELBOW =-XELBOW;
    YELBOW =-YELBOW;

    MAN = 360-CAN;
    SW0 = 1;
    }
    else MAN = CAN, SW0 = 0;

    SPT = 0;
    F_C = 0;

    if(!SPT) SPT = SPLINE_TYPE(MAN);

    DEFINE_DISPLACE(J, I, X1, Y1);
    DEFINE_DISPLACE(I, K, X2, Y2);

    if(SPT>0)
    {
    SW3 = DEFINE_INTERSECTION(X1, Y1, X2, Y2, &IX, &IY);
    if(!SW3) SPT = 0;
    else
    IX -= PLDCO0[I],
    IY -= PLDCO1[I];
    }
    X1[4] = XELBOW +PLDCO0[J];
    Y1[4] = YELBOW +PLDCO1[J];
    X1[7] = PLDCO0[J] -XELBOW;
    Y1[7] = PLDCO1[J] -YELBOW;
    X1[5] = X1[1];
    Y1[5] = Y1[1];
    X1[6] = 2.0*PLDCO0[I]-X1[1];
    Y1[6] = 2.0*PLDCO1[I]-Y1[1];
    switch(SPT)
    {
    case 0: /*GORIZONTAL!NEEDED-BOX-GENERATING*/
    SW1 = SW2 = 1;
    XELBOW = X1[2]*Size_Width;
    YELBOW = Y1[2]*Size_Width;

    if(SW0)
    XELBOW =-XELBOW, YELBOW =-YELBOW;

    if(SW4)
    {
    Dswab(X1+4, X1+7);
    Dswab(Y1+4, Y1+7);
    Dswab(X1+5, X1+6);
    Dswab(Y1+5, Y1+6);
    }
    break;
    case 1: /*NOT-ACUTE-ANGLE*/
    SW1 =-1, SW2 =+1;

    XELBOW = IX;
    YELBOW = IY;
    DEFINE_ELBOW(X1, Y1, I);

    if(SW0)
    XELBOW =-XELBOW, YELBOW =-YELBOW;

    if(SW4&&!SW0)CAN_OLD -= 360;
    if(!SW4&&SW0)CAN_OLD *=-1.0;

    if(!F_C_OLD)
    if((MAN+CAN_OLD)<0)
    {
    Dswab(X1+4, X1+7);
    Dswab(Y1+4, Y1+7);
    Dswab(X1+5, X1+6);
    Dswab(Y1+5, Y1+6);
    }
    break;
    case 2: /*ACUTE-ANGLE*/
    case 3:
    /*Mirror Normals*/
    X1[2] =-X1[2];
    Y1[2] =-Y1[2];
    X2[2] =-X2[2];
    Y2[2] =-Y2[2];

    /*Insisde Edges*/
    DEFINE_DISPLACE(J, I, X1, Y1);
    DEFINE_DISPLACE(I, K, X2, Y2);

    /*Check For Cover Making*/
    SW3 = DEFINE_INTERSECTION(X1, Y1, X2, Y2, X1+3, Y1+3);
    if(!SW3)zabort();
    SW1 = POINTONSEGMENT(X1, Y1, X1[3], Y1[3]);
    SW2 = POINTONSEGMENT(X2, Y2, X1[3], Y1[3]);
    if(SW1&&SW2&&SPT!=2)
    {
    XELBOW = IX;
    YELBOW = IY;
    DEFINE_ELBOW(X1, Y1, I);

    if(SW0)
    XELBOW =-XELBOW, YELBOW =-YELBOW;

    if(SW4&&!SW0)CAN_OLD -= 360;
    if(!SW4&&SW0)CAN_OLD *=-1.0;

    if(!F_C_OLD)
    if((MAN+CAN_OLD)<0)
    {
    Dswab(X1+4, X1+7);
    Dswab(Y1+4, Y1+7);
    Dswab(X1+5, X1+6);
    Dswab(Y1+5, Y1+6);
    }
    break;
    }
    NO_CONT_1 = 1;

    X2[2] =-X2[2];
    Y2[2] =-Y2[2];

    XELBOW = X2[2]*Size_Width;
    YELBOW = Y2[2]*Size_Width;

    X_C[5] = X1[5]+XELBOW;
    Y_C[5] = Y1[5]+YELBOW;

    X_C[6] = PLDCO0[I]+XELBOW;
    Y_C[6] = PLDCO1[I]+YELBOW;

    X_C[7] = PLDCO0[I];
    Y_C[7] = PLDCO1[I];

    X_C[8] = X_C[4] = X1[5];
    Y_C[8] = Y_C[4] = Y1[5];

    if(SW0)
    XELBOW =-XELBOW, YELBOW =-YELBOW;

    if(SW4!=SW0)
    {
    Dswab(X1+4, X1+7);
    Dswab(Y1+4, Y1+7);
    Dswab(X1+5, X1+6);
    Dswab(Y1+5, Y1+6);
    }
    F_C = 1;
    break;
    default: zabort();
    }
    X1[8] = X1[4];
    Y1[8] = Y1[4];

    if(S)
    UNL_TOINTLAYSTANDART(X1, Y1);

    SW4 = SW0;
    F_C_OLD = F_C;
    CAN_OLD = CAN;
    NO_CONT_2 = NO_CONT_1;
  }
  void
  Shapes_Collar_Generater(void)
  {
    long S;
    long K;
    long T;
    long I;
    long J;
    long Q;
    long Z;

    if(PLDLIM<2)
    {
    return;
    }
    PXMIN = PYMIN = LONG_MAX;
    PXMAX = PYMAX =-LONG_MAX;

    for(I = 1; I<PLDLIM; ++I)
    {
    if(PXMIN>PLDCO0[I]) PXMIN = PLDCO0[I];
    if(PXMAX<PLDCO0[I]) PXMAX = PLDCO0[I];
    if(PYMIN>PLDCO1[I]) PYMIN = PLDCO1[I];
    if(PYMAX<PLDCO1[I]) PYMAX = PLDCO1[I];
    }
    Delta_X_2 = PXMIN -= Size_Width;
    Delta_Y_2 = PYMIN -= Size_Width;

    PXMAX += Size_Width;
    PYMAX += Size_Width;

    for(I = 1; I<PLDLIM; ++I)
    {
    PLDCO0[I] -= PXMIN;
    PLDCO1[I] -= PYMIN;
    }
    PXMAX -= PXMIN;
    PYMAX -= PYMIN;

    PXMIN = PYMIN = 0;
    Determine_Point_Base();

    if(!Z_Open_Shape)
    {
    /*LAST POINT .EQ. FIRST POINT ALWAYS.*/
    /*DUPLICATE POINTS NEVER TAKES PLACE.*/

    K = PLDLIM -2;

    PLDCO0[0] = PLDCO0[K];
    PLDCO1[0] = PLDCO1[K];

    Q = 0;
    S = 1;
    T = 2;

    I = PLDNEXT();

    PLDCO0[I] = PLDCO0[T];
    PLDCO1[I] = PLDCO1[T];
    }
    else
    {
    Q = 1;
    S = 2;
    T = 3;
    }
    Z = S;
    /*SCALE POINTS*/

    J = PYMAX>PXMAX? PYMAX: PXMAX;

    S_FACTOR = 0;
    do
    {
    ++S_FACTOR;
    }
    while(((J<<S_FACTOR)>>S_FACTOR)==J);
    S_FACTOR--;
    if(S_FACTOR<0)S_FACTOR = 0;
    if(S_FACTOR>9)S_FACTOR = 9;

    Without_Scale = S_FACTOR==0;

    XPDIV <<= S_FACTOR;
    YPDIV <<= S_FACTOR;
    PXMAX <<= S_FACTOR;
    PYMAX <<= S_FACTOR;
    PXMIN <<= S_FACTOR;
    PYMIN <<= S_FACTOR;

    DEFINE_NORMALFROM(Q, Z);

    XELBOW = NXFROM*Size_Width;
    YELBOW = NYFROM*Size_Width;

    ZLBLIM = 1;
    ZLVLIM = 1;
    ZPTLIM = 1;
    ZVTLIM = 2;
    ZLDLIM = 0;
    Lead_In_Exists = 0;

    J = Z_Open_Shape!=0;

    S_C_F_S = J; /*First Segment*/
    C_Layer = J;

    DEFINE_SEGMENT(J, S-1, S, T);

    NO_CONT_2 = 1;

    if(S_C_F_S)
    {
    if(ZLDLIM)Lead_In_Exists = 1;

    Unl_ToIntlayStandart(), ZLDLIM = 0;

    if(F_C)
    UNL_TOINTLAYSTANDART(X_C, Y_C);
    }
    C_Layer = 0;
    S_C_F_S = 0; /*Not First Segment*/

    K = S, S = T, ++T;

    F_C_OLD = 0;

    while(T<PLDLIM)
    {
    DEFINE_SEGMENT(1, K, S, T);

    if(F_C)
    {
    NO_CONT_2 = 1;
    UNL_TOINTLAYSTANDART(X_C, Y_C);
    }
    K = S, S = T, ++T;
    }
    Unl_ToIntlayStandart();

    if(J)I = ZLBLIM>3;
    else I = ZLBLIM>2;

    Zptlim_After_Loadmaster = ZPTLIM;

    if(I)OV_EL_SEGMENTS();

    I = Back_Scale_0();

    if(B_S_Lv_Only)
    {
    ZVTLIM = 2;
    B_S_Lv_Only = 0;
    memset(ZLVCO2, 0, ZLVLIM*sizeof(ZLVCO2[0]));
    }
    Without_Scale = 1; S_FACTOR = 0;

    if(I)OV_EL_SEGMENTS();

    ZVTCO6[0] = 0;
    ZVTCO5[0] = 0;

    ZZ_Collar_Output();
    return;
  }
  void
  Check_Bound_Loc(void)
  {
  long Z = 1;

  Z&= CXMIN>=LZ_S.CXMIN;
  Z&= CXMAX<=LZ_S.CXMAX;
  Z&= CYMIN>=LZ_S.CYMIN;
  Z&= CYMAX<=LZ_S.CYMAX;

  if(Z==0)
  fprintf(stderr, "\nWarning! Data Out of Boundary.\nOver Sizing'll be Incorrect.");
  }
  #define O_L O_Layer
  void
  Db_Collars_Generater(void)
  {
    fprintf(stderr, "\nCollars Data Base Generater Started on %s\n",
    Z_Layer[0].Name);
    fprintf(stderr, "\nOutput Layer will be %s\n", O_Layer.Name);

    ZLDLIM = 0; dontworry_2();
    for
    (ZZ_Read_Shape(); !Zd_File_Eof; ZZ_Read_Shape())
    {
    if(PLDLIM>1)
    Shapes_Collar_Generater();
    }
    ZLDLIM = 0; dontworry_2();

    Check_Bound_Loc();

    if(CXMIN==+LONG_MAX)CXMIN = 0;
    if(CYMIN==+LONG_MAX)CYMIN = 0;
    if(CXMAX==-LONG_MAX)CXMAX = 0;
    if(CYMAX==-LONG_MAX)CYMAX = 0;

    FP_S.Delta_X = 0;
    FP_S.Delta_Y = 0;

    O_L.LX_S.CXMIN = CXMIN;
    O_L.LX_S.CXMAX = CXMAX;
    O_L.LX_S.CYMIN = CYMIN;
    O_L.LX_S.CYMAX = CYMAX;

    O_L.LX_S.XBCNT = 1;
    O_L.LX_S.YBCNT = 1;
    O_L.LX_S.XBSIZ = CXMAX-CXMIN;
    O_L.LX_S.YBSIZ = CYMAX-CYMIN;

    Dix_Rewrite_FP_S = 1;

    Dix_close();
    renameoutput();

    Dix_Rewrite_FP_S = 0;

    Print_Normal_Finish();
  }
